<?php
/**
 * Official PDF Certificate Generator (TCPDF + built-in QR)
 * Only available for Completed / Released requests.
 */
require 'includes/config.php';

// Allow both resident (own request) and personnel
$isAdmin = isset($_SESSION['admin_id']);
$isResident = isset($_SESSION['resident_id']);
if (!$isAdmin && !$isResident) {
    header('Location: login.php');
    exit;
}

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    http_response_code(400);
    die('Invalid request.');
}

$sql = "SELECT r.*, s.service_name, s.description
        FROM tblrequests r
        JOIN tblservices s ON s.service_id = r.service_id
        WHERE r.request_id = ?";
if ($isResident && !$isAdmin) {
    $sql .= " AND r.resident_id = " . (int)$_SESSION['resident_id'];
}
$st = $conn->prepare($sql);
$st->bind_param('i', $id);
$st->execute();
$r = $st->get_result()->fetch_assoc();
$st->close();

if (!$r) {
    http_response_code(404);
    die('Request not found.');
}

if (!in_array($r['status'], ['Completed', 'Released'], true)) {
    http_response_code(403);
    die('Certificate can only be generated for Completed or Released requests.');
}

require_once __DIR__ . '/assets/libs/tcpdf/tcpdf.php';

$fullName = trim(preg_replace('/\s+/', ' ',
    ($r['request_first_name'] ?? '') . ' ' .
    ($r['request_middle_name'] ?? '') . ' ' .
    ($r['request_last_name'] ?? '')
));
$queueNo   = queue_number($r['request_id']);
$docType   = $r['service_name'];
$purpose   = $r['purpose'];
$address   = $r['request_address'];
$issuedOn  = date('F d, Y');
$year      = date('Y');

// QR payload (Level H for official certificate)
$qrPayload = json_encode([
    'type'      => 'BB_CERT',
    'queue'     => $queueNo,
    'request_id'=> (int)$r['request_id'],
    'document'  => $docType,
    'name'      => $fullName,
    'status'    => $r['status'],
    'issued'    => date('Y-m-d'),
    'barangay'  => 'Barangay Babaran, Echague, Isabela',
], JSON_UNESCAPED_UNICODE);

// Custom TCPDF class for header/footer
class BabaranCertificatePDF extends TCPDF
{
    public function Header() {}
    public function Footer()
    {
        $this->SetY(-18);
        $this->SetFont('helvetica', 'I', 8);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 8, 'Barangay Babaran Document Request System  •  This is a computer-generated official certificate.', 0, 0, 'C');
    }
}

$pdf = new BabaranCertificatePDF('P', 'mm', 'A4', true, 'UTF-8', false);
$pdf->SetCreator('Barangay Babaran System');
$pdf->SetAuthor('Barangay Babaran, Echague, Isabela');
$pdf->SetTitle($docType . ' — ' . $queueNo);
$pdf->SetMargins(18, 18, 18);
$pdf->SetAutoPageBreak(true, 22);
$pdf->AddPage();

// Green border
$pdf->SetDrawColor(31, 122, 58);
$pdf->SetLineWidth(1.2);
$pdf->Rect(10, 10, 190, 277);

// Logo
$logoPath = __DIR__ . '/assets/img/barangay-babaran-logo.png';
if (is_file($logoPath)) {
    $pdf->Image($logoPath, 22, 18, 22, 22, 'PNG');
}

// Header text
$pdf->SetFont('helvetica', 'B', 10);
$pdf->SetTextColor(31, 122, 58);
$pdf->SetXY(48, 18);
$pdf->Cell(120, 5, 'REPUBLIC OF THE PHILIPPINES', 0, 1, 'C');
$pdf->SetX(48);
$pdf->SetFont('helvetica', '', 9);
$pdf->Cell(120, 4.5, 'Province of Isabela  •  Municipality of Echague', 0, 1, 'C');
$pdf->SetX(48);
$pdf->SetFont('helvetica', 'B', 14);
$pdf->Cell(120, 6, 'BARANGAY BABARAN', 0, 1, 'C');
$pdf->SetX(48);
$pdf->SetFont('helvetica', '', 8);
$pdf->Cell(120, 4, 'Office of the Punong Barangay', 0, 1, 'C');

// Horizontal line
$pdf->SetDrawColor(46, 158, 79);
$pdf->SetLineWidth(0.6);
$pdf->Line(22, 46, 188, 46);

// Document title
$pdf->Ln(14);
$pdf->SetFont('helvetica', 'B', 16);
$pdf->SetTextColor(31, 122, 58);
$pdf->Cell(0, 8, strtoupper($docType), 0, 1, 'C');
$pdf->SetFont('helvetica', '', 9);
$pdf->SetTextColor(80, 80, 80);
$pdf->Cell(0, 5, 'Reference No. ' . $queueNo, 0, 1, 'C');

// Body
$pdf->Ln(8);
$pdf->SetFont('helvetica', '', 11);
$pdf->SetTextColor(30, 30, 30);
$pdf->MultiCell(0, 6, 'TO WHOM IT MAY CONCERN:', 0, 'L');

$pdf->Ln(4);
$body = "This is to certify that <b>{$fullName}</b>, of legal age, and a bona fide resident of <b>{$address}</b>, Barangay Babaran, Echague, Isabela, has requested and been issued this <b>{$docType}</b> for the purpose of <b>{$purpose}</b>.";
$pdf->writeHTMLCell(0, 0, '', '', $body, 0, 1, false, true, 'J');

$pdf->Ln(4);
$pdf->MultiCell(0, 6, 'This certification is issued upon the request of the above-named person for whatever legal purpose it may serve.', 0, 'J');

$pdf->Ln(4);
$pdf->MultiCell(0, 6, 'Issued this ' . $issuedOn . ' at Barangay Babaran, Echague, Isabela, Philippines.', 0, 'J');

// Signature area
$pdf->Ln(18);
$pdf->SetFont('helvetica', 'B', 11);
$pdf->Cell(0, 5, '_______________________________', 0, 1, 'R');
$pdf->SetFont('helvetica', 'B', 10);
$pdf->Cell(0, 5, 'PUNONG BARANGAY', 0, 1, 'R');
$pdf->SetFont('helvetica', '', 9);
$pdf->Cell(0, 4, 'Barangay Babaran, Echague, Isabela', 0, 1, 'R');

// QR Code (Error Correction Level H)
$pdf->write2DBarcode($qrPayload, 'QRCODE,H', 22, 230, 32, 32, [
    'border' => false,
    'padding' => 1,
    'fgcolor' => [31, 122, 58],
    'bgcolor' => false,
], 'N');
$pdf->SetFont('helvetica', '', 7);
$pdf->SetXY(22, 263);
$pdf->SetTextColor(80, 80, 80);
$pdf->Cell(32, 4, 'Scan to verify', 0, 0, 'C');

// Status stamp
$pdf->SetFont('helvetica', 'B', 9);
$pdf->SetTextColor(46, 158, 79);
$pdf->SetXY(140, 240);
$pdf->Cell(50, 5, 'Status: ' . strtoupper($r['status']), 0, 1, 'R');
$pdf->SetXY(140, 245);
$pdf->SetFont('helvetica', '', 8);
$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 4, 'Generated: ' . date('Y-m-d H:i'), 0, 1, 'R');

$filename = 'BB_Certificate_' . $queueNo . '.pdf';
$pdf->Output($filename, 'D'); // Force download
exit;
