<?php
require 'includes/config.php'; require_resident(); $pageTitle='New Document Request'; $error='';
$residentId=(int)$_SESSION['resident_id'];
$st=$conn->prepare('SELECT * FROM tblresidents WHERE resident_id=?');$st->bind_param('i',$residentId);$st->execute();$resident=$st->get_result()->fetch_assoc();
if($_SERVER['REQUEST_METHOD']==='POST'){
  verify_csrf();
  $first=trim($_POST['first_name']??'');$middle=trim($_POST['middle_name']??'');$last=trim($_POST['last_name']??'');$address=trim($_POST['address']??'');$contact=trim($_POST['contact_no']??'');$email=trim($_POST['email']??'');$service=(int)($_POST['service_id']??0);$purpose=trim($_POST['purpose']??'');$date=$_POST['preferred_date']??'';$time=$_POST['preferred_time']??'';$signature='';
  if(!$first||!$last||!$address||!$service||!$purpose||!$date||!$time){$error='Please complete all required request fields.';}
  elseif(strtotime($date)<strtotime(date('Y-m-d'))){$error='Preferred date cannot be in the past.';}
  else{
    $email=($email==='')?null:strtolower($email); $contact=($contact==='')?null:$contact;
    $svc=$conn->prepare('SELECT service_id FROM tblservices WHERE service_id=? AND is_active=1 LIMIT 1');$svc->bind_param('i',$service);$svc->execute();
    if(!$svc->get_result()->fetch_assoc()){$error='The selected document type is not available.';}
    $dup=$conn->prepare("SELECT resident_id FROM tblresidents WHERE resident_id<>? AND ((contact_no=? AND contact_no IS NOT NULL) OR (email=? AND email IS NOT NULL)) LIMIT 1");$dup->bind_param('iss',$residentId,$contact,$email);$dup->execute();
    if(!$error&&$dup->get_result()->fetch_assoc()){$error='The contact number or email is already registered to another resident.';}
    if(!$error){
      $st=$conn->prepare('UPDATE tblresidents SET first_name=?,middle_name=?,last_name=?,address=?,contact_no=?,email=? WHERE resident_id=?');$st->bind_param('ssssssi',$first,$middle,$last,$address,$contact,$email,$residentId);
      if(!$st->execute()){$error='Unable to update your resident information.';}
    }
    if(!$error){$st=$conn->prepare("INSERT INTO tblrequests(resident_id,service_id,request_first_name,request_middle_name,request_last_name,request_address,request_contact,request_email,purpose,preferred_date,preferred_time,status,resident_signature,resident_signed_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,'Draft',?,NOW())");$st->bind_param('iissssssssss',$residentId,$service,$first,$middle,$last,$address,$contact,$email,$purpose,$date,$time,$signature);
    if($st->execute()){header('Location: request_review.php?id='.$st->insert_id);exit;} $error='Unable to save the request.';
  }
  }
}
$services=$conn->query('SELECT * FROM tblservices WHERE is_active=1 ORDER BY service_name');
include 'includes/header.php';
?>
<div class="request-shell"><div class="stepper"><div class="step-item active"><div class="step-circle">1</div><div><strong>Fill-up Form</strong><span>Provide resident details</span></div></div><div class="step-item"><div class="step-circle">2</div><div><strong>Document Request</strong><span>Select document requested</span></div></div><div class="step-item"><div class="step-circle">3</div><div><strong>Edit / Review</strong><span>Check your request details</span></div></div><div class="step-item"><div class="step-circle">4</div><div><strong>Confirmation</strong><span>Track your request</span></div></div></div>
<div class="request-card"><div class="request-section-title">Step 1 of 4</div><h2>Resident Information</h2><p class="muted small">Please provide the information for this document request. You will review and sign it on the next step before final submission.</p>
<?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?>
<form method="post" id="requestForm"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><div class="queue-banner"><div class="queue-number">BB-AUTO</div><div class="small">Queue number will be generated automatically after you submit the request.</div></div><br>
<div class="form-grid"><div class="form-group"><label>First Name *</label><input class="form-control" name="first_name" value="<?=e($resident['first_name'])?>" required></div><div class="form-group"><label>Middle Name</label><input class="form-control" name="middle_name" value="<?=e($resident['middle_name'])?>"></div><div class="form-group"><label>Last Name *</label><input class="form-control" name="last_name" value="<?=e($resident['last_name'])?>" required></div><div class="form-group"><label>Contact Number</label><input class="form-control" name="contact_no" value="<?=e($resident['contact_no'])?>"></div><div class="form-group full"><label>Complete Address *</label><input class="form-control" name="address" value="<?=e($resident['address'])?>" required></div><div class="form-group"><label>Email Address (Optional)</label><input type="email" class="form-control" name="email" value="<?=e($resident['email'])?>"></div><div class="form-group"><label>Purpose of Request *</label><input class="form-control" name="purpose" value="<?=e($_POST['purpose']??'')?>" required placeholder="e.g. Employment, School Requirement"></div><div class="form-group"><label>Preferred Date *</label><input type="date" class="form-control" name="preferred_date" min="<?=date('Y-m-d')?>" value="<?=e($_POST['preferred_date']??'')?>" required></div><div class="form-group"><label>Preferred Time *</label><input type="time" class="form-control" name="preferred_time" value="<?=e($_POST['preferred_time']??'')?>" required></div>
<div class="form-group full"><label>Document Type *</label><select class="form-select" name="service_id" required><option value="">Select document requested</option><?php while($s=$services->fetch_assoc()):?><option value="<?=$s['service_id']?>" <?=($_POST['service_id']??'')==$s['service_id']?'selected':''?>><?=e($s['service_name'])?></option><?php endwhile;?></select></div>
<div class="info-banner"><strong>Reminder:</strong> Please make sure all information is accurate and complete. You may correct the form before final submission. Once submitted, the request will be sent to barangay personnel for review.</div><div class="request-actions"><a class="btn btn-outline" href="dashboard.php"><i class="bi bi-arrow-left"></i> Back to Dashboard</a><button class="btn btn-primary" type="submit">Next: Review &amp; Submit →</button></div></form></div></div>

<?php include 'includes/footer.php'; ?>
