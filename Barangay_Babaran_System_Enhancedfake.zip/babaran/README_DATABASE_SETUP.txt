BARANGAY BABARAN SYSTEM - DATABASE SETUP

Database:
  Name: babaran_db
  Host: localhost
  Username: root
  Password: (blank by default in XAMPP)

FRESH INSTALL (recommended):
1. Start Apache and MySQL in XAMPP.
2. Open http://localhost/phpmyadmin/
3. Click Import.
4. Import database.sql from this folder.
5. Open http://localhost/Barangay_Babaran_System/

The current database.sql already contains:
- Role-based personnel access: Punong Barangay / Secretary + active status
- Audit trail table
- Password reset table
- Scheduling table + synchronization triggers
- Application-level schedule date/time protection against double-booking

UPGRADE OF AN EXISTING babaran_db:
- Back up the database first.
- Run schema_changes.sql in phpMyAdmin.
- Do NOT run database.sql on an existing database unless you intentionally want to recreate it; database.sql drops existing tables.

DEFAULT PERSONNEL LOGIN:
Username: admin
Password: admin1234
Role: Punong Barangay

Change the default password after first login.

IMPORTANT:
- The application is configured for XAMPP: localhost / root / blank password.

IMPORTANT SECURITY NOTE:
For this school/demo build, tblresidents.password_plain stores the original password so it is visible in phpMyAdmin. Authentication still uses the secure password hash in tblresidents.password. Never deploy password_plain storage to a public/production system.

----------------------------------------------------------------
SERVICES / DOCUMENT TYPES UPDATE
----------------------------------------------------------------
Fresh install : import database.sql (already contains the updated document list).
Existing DB   : run update_services_v2.sql in phpMyAdmin (safe to re-run).
                It deactivates Tree-Cutting, Piggery and Poultry permits and adds
                Cedula, Certificate of Good Moral Character and SK Certification.
Document list : Barangay Clearance, Certificate of Indigency, Certificate of Residency,
                Business Permit Endorsement, Cedula (Community Tax Certificate),
                Certificate of Good Moral Character, Sangguniang Kabataan (SK)
                Certification, Other Special Permit.
