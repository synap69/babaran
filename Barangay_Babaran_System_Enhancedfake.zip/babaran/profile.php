<?php
require 'includes/config.php';
require_resident();
$pageTitle = 'Resident Profile';
$residentId = (int)$_SESSION['resident_id'];
$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    verify_csrf();
    if ($action === 'profile') {
        $first = trim($_POST['first_name'] ?? '');
        $middle = trim($_POST['middle_name'] ?? '');
        $last = trim($_POST['last_name'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $contact = trim($_POST['contact_no'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $contact = ($contact === '') ? null : $contact;
        $email = ($email === '') ? null : strtolower($email);

        if ($first === '' || $last === '' || $address === '') $errors[] = 'First name, last name, and address are required.';
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid email address.';

        if (!$errors) {
            $check = $conn->prepare("SELECT resident_id FROM tblresidents WHERE (contact_no=? AND contact_no IS NOT NULL) OR (email=? AND email IS NOT NULL) LIMIT 1");
            $check->bind_param('ss', $contact, $email);
            $check->execute();
            $existing = $check->get_result()->fetch_assoc();
            if ($existing && (int)$existing['resident_id'] !== $residentId) {
                $errors[] = 'The contact number or email is already registered to another resident.';
            } else {
                $st = $conn->prepare('UPDATE tblresidents SET first_name=?, middle_name=?, last_name=?, address=?, contact_no=?, email=? WHERE resident_id=?');
                $st->bind_param('ssssssi', $first, $middle, $last, $address, $contact, $email, $residentId);
                if ($st->execute()) {
                    $_SESSION['first_name'] = $first;
                    $_SESSION['last_name'] = $last;
                    $success = 'Your profile has been updated successfully.';
                } else {
                    $errors[] = 'Unable to update your profile. Please try again.';
                }
            }
        }
    } elseif ($action === 'photo') {
        if (!isset($_FILES['profile_photo']) || $_FILES['profile_photo']['error'] === UPLOAD_ERR_NO_FILE) {
            $errors[] = 'Please choose a photo to upload.';
        } else {
            $file = $_FILES['profile_photo'];
            $maxBytes = 2 * 1024 * 1024;
            $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
            if ($file['error'] !== UPLOAD_ERR_OK) {
                $errors[] = 'The photo upload failed. Please try again.';
            } elseif ((int)$file['size'] > $maxBytes) {
                $errors[] = 'Photo must be 2 MB or smaller.';
            } elseif (!is_uploaded_file($file['tmp_name'])) {
                $errors[] = 'Invalid photo upload.';
            } else {
                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $mime = $finfo->file($file['tmp_name']);
                $imageInfo = @getimagesize($file['tmp_name']);
                if (!isset($allowed[$mime]) || $imageInfo === false) {
                    $errors[] = 'Only JPG, PNG, or WEBP image files are allowed.';
                } else {
                    $dir = __DIR__ . '/uploads/profile';
                    if (!is_dir($dir)) mkdir($dir, 0755, true);
                    $old = resident_profile_photo_file($residentId);
                    $filename = 'resident_' . $residentId . '_' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
                    $destination = $dir . '/' . $filename;
                    if (move_uploaded_file($file['tmp_name'], $destination)) {
                        if ($old && is_file($old)) @unlink($old);
                        $success = 'Profile photo uploaded successfully.';
                    } else {
                        $errors[] = 'Unable to save the profile photo. Please try again.';
                    }
                }
            }
        }
    } elseif ($action === 'remove_photo') {
        $old = resident_profile_photo_file($residentId);
        if ($old && is_file($old) && @unlink($old)) {
            $success = 'Profile photo removed successfully.';
        } else {
            $errors[] = 'No profile photo was found to remove.';
        }
    } elseif ($action === 'password') {
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        $st = $conn->prepare('SELECT password FROM tblresidents WHERE resident_id=?');
        $st->bind_param('i', $residentId); $st->execute();
        $row = $st->get_result()->fetch_assoc();
        if (!$row || !password_verify($current, $row['password'])) $errors[] = 'Current password is incorrect.';
        if (strlen($new) < 8) $errors[] = 'New password must be at least 8 characters.';
        if ($new !== $confirm) $errors[] = 'New password and confirmation do not match.';
        if (!$errors) {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $up = $conn->prepare('UPDATE tblresidents SET password=?, password_plain=? WHERE resident_id=?');
            $up->bind_param('ssi', $hash, $new, $residentId);
            if ($up->execute()) $success = 'Your password has been changed successfully.';
            else $errors[] = 'Unable to change your password. Please try again.';
        }
    }
}

$st = $conn->prepare('SELECT resident_id,first_name,middle_name,last_name,address,contact_no,email,date_registered FROM tblresidents WHERE resident_id=?');
$st->bind_param('i', $residentId); $st->execute();
$resident = $st->get_result()->fetch_assoc();
if (!$resident) { session_destroy(); header('Location: login.php'); exit; }
$profilePhotoUrl = resident_profile_photo_url($residentId);
include 'includes/header.php';
?>
<div class="dashboard-grid">
  <div class="page-head">
    <div><h1>My Profile</h1><div class="muted">View and manage your resident account information.</div></div>
    <a class="btn btn-outline" href="dashboard.php"><i class="bi bi-arrow-left"></i> Back to Dashboard</a>
  </div>

  <?php if ($success): ?><div class="alert alert-success"><?=e($success)?></div><?php endif; ?>
  <?php if ($errors): ?><div class="alert alert-danger"><ul style="margin:0;padding-left:20px"><?php foreach ($errors as $error): ?><li><?=e($error)?></li><?php endforeach; ?></ul></div><?php endif; ?>

  <div class="dashboard-two">
    <section class="card profile-photo-card">
      <div class="section-head"><div><h3>Profile Photo</h3><p class="muted">Add a photo so your account is easy to recognize.</p></div></div>
      <div class="profile-photo-wrap">
        <?php if ($profilePhotoUrl): ?>
          <img class="profile-photo" src="<?=e($profilePhotoUrl)?>" alt="Resident profile photo">
        <?php else: ?>
          <div class="profile-photo profile-photo-placeholder">👤</div>
        <?php endif; ?>
        <div class="profile-photo-actions">
          <form method="post" enctype="multipart/form-data" class="photo-form">
            <input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
            <input type="hidden" name="action" value="photo">
            <label class="btn btn-primary photo-upload-label">Choose Photo
              <input type="file" name="profile_photo" accept="image/jpeg,image/png,image/webp" required onchange="this.form.submit()" hidden>
            </label>
            <small class="muted">JPG, PNG or WEBP • Maximum 2 MB</small>
          </form>
          <?php if ($profilePhotoUrl): ?>
            <form method="post" onsubmit="return confirm('Remove your profile photo?');">
              <input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
              <input type="hidden" name="action" value="remove_photo">
              <button class="btn btn-outline btn-small" type="submit">Remove Photo</button>
            </form>
          <?php endif; ?>
        </div>
      </div>
    </section>
    <section class="card">
      <div class="section-head"><div><h3>Personal Information</h3><p class="muted">Keep your information updated for document requests.</p></div></div>
      <form method="post" class="form-grid">
        <input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
        <input type="hidden" name="action" value="profile">
        <div class="form-group"><label>First Name *</label><input type="text" name="first_name" value="<?=e($resident['first_name'])?>" required></div>
        <div class="form-group"><label>Middle Name</label><input type="text" name="middle_name" value="<?=e($resident['middle_name'] ?? '')?>"></div>
        <div class="form-group"><label>Last Name *</label><input type="text" name="last_name" value="<?=e($resident['last_name'])?>" required></div>
        <div class="form-group form-full"><label>Address *</label><textarea name="address" rows="3" required><?=e($resident['address'])?></textarea></div>
        <div class="form-group"><label>Contact Number</label><input type="text" name="contact_no" value="<?=e($resident['contact_no'] ?? '')?>" placeholder="09XXXXXXXXX"></div>
        <div class="form-group"><label>Email Address</label><input type="email" name="email" value="<?=e($resident['email'] ?? '')?>" placeholder="you@example.com"></div>
        <div class="form-full"><button class="btn btn-primary" type="submit">Save Profile Changes</button></div>
      </form>
    </section>

    <section class="card">
      <div class="section-head"><div><h3>Account Details</h3><p class="muted">Your resident account information.</p></div></div>
      <div class="profile-details">
        <div><small>Resident ID</small><strong>#<?=str_pad((string)$resident['resident_id'],5,'0',STR_PAD_LEFT)?></strong></div>
        <div><small>Account Name</small><strong><?=e(trim($resident['first_name'].' '.($resident['middle_name'] ?? '').' '.$resident['last_name']))?></strong></div>
        <div><small>Date Registered</small><strong><?=date('M d, Y',strtotime($resident['date_registered']))?></strong></div>
        <div><small>Account Role</small><strong>Resident</strong></div>
      </div>
      <div class="profile-note">Use accurate contact information so the barangay can reach you about your document requests and schedules.</div>
    </section>
  </div>

  <section class="card">
    <div class="section-head"><div><h3>Change Password</h3><p class="muted">For security, use a strong password with at least 8 characters.</p></div></div>
    <form method="post" class="form-grid">
      <input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
      <input type="hidden" name="action" value="password">
      <div class="form-group"><label>Current Password *</label><div class="password-wrap"><input type="password" id="profileCurrentPassword" class="form-control" name="current_password" required autocomplete="current-password"><button type="button" class="password-toggle" data-toggle-target="profileCurrentPassword" aria-label="Show password" title="Show password"><i class="bi bi-eye password-eye-icon"></i></button></div></div>
      <div class="form-group"><label>New Password *</label><div class="password-wrap"><input type="password" id="profileNewPassword" class="form-control" name="new_password" minlength="8" required autocomplete="new-password"><button type="button" class="password-toggle" data-toggle-target="profileNewPassword" aria-label="Show password" title="Show password"><i class="bi bi-eye password-eye-icon"></i></button></div></div>
      <div class="form-group"><label>Confirm New Password *</label><div class="password-wrap"><input type="password" id="profileConfirmPassword" class="form-control" name="confirm_password" minlength="8" required autocomplete="new-password"><button type="button" class="password-toggle" data-toggle-target="profileConfirmPassword" aria-label="Show password" title="Show password"><i class="bi bi-eye password-eye-icon"></i></button></div></div>
      <div class="form-full"><button class="btn btn-primary" type="submit">Change Password</button></div>
    </form>
  </section>
</div>
<?php include 'includes/footer.php'; ?>
