<?php
require 'includes/config.php';
require_resident();
$filter = $_GET['status'] ?? 'All';
$pageTitle = ($filter === 'All' ? 'My Requests' : $filter . ' Requests');
$allowed = ['Pending', 'Scheduled', 'Processing', 'Completed', 'Released', 'Rejected'];
$residentId = (int)$_SESSION['resident_id'];
$sql = "SELECT r.*,s.service_name FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE r.resident_id=? AND r.status<>'Draft'";
if (in_array($filter, $allowed, true)) {
    $sql .= " AND r.status='" . $conn->real_escape_string($filter) . "'";
}
$sql .= ' ORDER BY r.date_requested DESC';
$st = $conn->prepare($sql);
$st->bind_param('i', $residentId);
$st->execute();
$rows = $st->get_result();
include 'includes/header.php';
?>
<div class="dashboard-grid">
  <div class="page-head">
    <div>
      <h1><?= e($pageTitle) ?></h1>
      <div class="muted">Track your document requests and schedules. Electronic signature is optional.</div>
    </div>
    <a class="btn btn-primary" href="new_request.php"><i class="bi bi-plus-lg"></i> New Document Request</a>
  </div>
  <section class="card">
    <div class="section-head">
      <h3>Request Records</h3>
      <div style="display:flex;gap:6px;flex-wrap:wrap">
        <a class="btn btn-small btn-outline" href="requests.php">All</a>
        <?php foreach ($allowed as $x): ?>
          <a class="btn btn-small btn-outline<?= $filter === $x ? ' active' : '' ?>" href="requests.php?status=<?= $x ?>"><?= e($x) ?></a>
        <?php endforeach; ?>
      </div>
    </div>
    <?php if (!$rows->num_rows): ?>
      <div class="empty">No requests found.</div>
    <?php else: ?>
      <div class="table-wrap">
        <table class="table">
          <thead>
            <tr>
              <th>Queue No.</th>
              <th>Document</th>
              <th>Preferred Schedule</th>
              <th>Assigned Schedule</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php while ($r = $rows->fetch_assoc()): ?>
              <tr>
                <td><strong><?= e(queue_number($r['request_id'])) ?></strong></td>
                <td><?= e($r['service_name']) ?><br><span class="small muted"><?= e($r['purpose']) ?></span></td>
                <td><?= date('M d, Y', strtotime($r['preferred_date'])) ?><br><?= date('h:i A', strtotime($r['preferred_time'])) ?></td>
                <td>
                  <?php if ($r['scheduled_date']): ?>
                    <?= date('M d, Y', strtotime($r['scheduled_date'])) ?><br><?= date('h:i A', strtotime($r['scheduled_time'])) ?>
                  <?php else: ?>
                    —
                  <?php endif; ?>
                </td>
                <td>
                  <span class="badge badge-<?= strtolower($r['status']) ?>"><?= e($r['status']) ?></span>
                  <?php if ($r['remarks']): ?><br><span class="small muted"><?= e($r['remarks']) ?></span><?php endif; ?>
                </td>
                <td style="white-space:nowrap">
                  <?php if (in_array($r['status'], ['Pending', 'Rejected'], true)): ?>
                    <a class="btn btn-outline btn-small" href="edit_request.php?id=<?= $r['request_id'] ?>">Edit</a>
                  <?php endif; ?>
                  <a class="btn btn-outline btn-small" href="request_slip.php?id=<?= $r['request_id'] ?>">Slip</a>
                  <?php if (in_array($r['status'], ['Completed', 'Released'], true)): ?>
                    <a class="btn btn-primary btn-small" href="generate_certificate.php?id=<?= $r['request_id'] ?>" target="_blank" title="Download Official PDF Certificate">PDF</a>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </section>
</div>
<?php include 'includes/footer.php'; ?>
