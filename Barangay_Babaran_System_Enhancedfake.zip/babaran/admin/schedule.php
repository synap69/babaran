<?php
require '../includes/config.php'; require_admin();
$pageTitle='Assign Schedule'; $error=''; $id=(int)($_GET['id']??0);
if(!$id){ header('Location: dashboard.php?status=Pending'); exit; }
$st=$conn->prepare("SELECT r.*,s.service_name,res.contact_no FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id JOIN tblresidents res ON res.resident_id=r.resident_id WHERE r.request_id=?");
$st->bind_param('i',$id); $st->execute(); $r=$st->get_result()->fetch_assoc(); if(!$r){http_response_code(404);die('Request not found.');}
if($_SERVER['REQUEST_METHOD']==='POST'){ verify_csrf();
 $date=$_POST['scheduled_date']??''; $time=$_POST['scheduled_time']??'';
 if(!$date||!$time) $error='Please select a date and time slot.';
 elseif(strtotime($date)<strtotime(date('Y-m-d'))) $error='Schedule date cannot be in the past.';
 else {
   // Prevent double-booking of the same barangay time slot.
   $check=$conn->prepare("SELECT request_id FROM tblrequests WHERE scheduled_date=? AND scheduled_time=? AND request_id<>? AND status IN ('Scheduled','Processing') LIMIT 1");
   $check->bind_param('ssi',$date,$time,$id); $check->execute();
   $conflict=$check->get_result()->fetch_assoc();
   if($conflict){ $error='That date and time slot is already assigned to another request. Please choose another slot.'; }
   else {
     $remarks=trim($_POST['remarks']??'');
     $st=$conn->prepare("UPDATE tblrequests SET status='Scheduled',scheduled_date=?,scheduled_time=?,remarks=? WHERE request_id=?");
     $st->bind_param('sssi',$date,$time,$remarks,$id);
     if($st->execute()){
       // Explicitly upsert the schedule record so scheduling remains functional even without DB triggers.
       $schedStatus='Scheduled';
       $su=$conn->prepare("INSERT INTO tblschedules(request_id,scheduled_date,scheduled_time,status,remarks) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE scheduled_date=VALUES(scheduled_date),scheduled_time=VALUES(scheduled_time),status='Scheduled',remarks=VALUES(remarks)");
       $su->bind_param('issss',$id,$date,$time,$schedStatus,$remarks); $su->execute(); $su->close();
       log_audit($conn,'admin',$_SESSION['admin_id'],$_SESSION['admin_name']??'Admin','Assigned Schedule','tblrequests',$id,$date.' '.$time);
       header('Location: dashboard.php?status=Scheduled'); exit;
     }
     $error='Unable to save the schedule. Please try again.';
   }
 }
}
$slots=['08:00:00'=>'8:00 AM - 9:00 AM','09:00:00'=>'9:00 AM - 10:00 AM','10:00:00'=>'10:00 AM - 11:00 AM','11:00:00'=>'11:00 AM - 12:00 PM','13:00:00'=>'1:00 PM - 2:00 PM','14:00:00'=>'2:00 PM - 3:00 PM','15:00:00'=>'3:00 PM - 4:00 PM','16:00:00'=>'4:00 PM - 5:00 PM'];
include '../includes/header.php';
?>
<div class="request-shell">
<div class="stepper"><div class="step-item active"><div class="step-circle">1</div><div><strong>Assign Schedule</strong><span>Select date and time</span></div></div><div class="step-item"><div class="step-circle">2</div><div><strong>Schedule Saved</strong><span>Confirmation</span></div></div></div>
<div class="request-card">
<div class="request-section-title">Request Details</div><div class="queue-banner"><div><small>Queue Number</small><div class="queue-number"><?=e(queue_number($id))?></div></div><div><strong><?=e(trim($r['request_first_name'].' '.$r['request_last_name']))?></strong><br><span class="small muted"><?=e($r['service_name'])?> · <?=e($r['request_contact']?:'No contact number')?></span></div></div>
<?php if($error):?><div class="alert alert-danger" style="margin-top:14px"><?=e($error)?></div><?php endif;?>
<form method="post"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
<h3 style="margin-top:20px">Assign Schedule</h3><p class="muted small">Please select the preferred date and time for the resident's transaction.</p>
<div class="form-grid"><div class="form-group"><label>Preferred Date *</label><input class="form-control" type="date" name="scheduled_date" min="<?=date('Y-m-d')?>" value="<?=e($r['scheduled_date']?:date('Y-m-d'))?>" required></div><div class="form-group"><label>Time Slot *</label><select class="form-select" name="scheduled_time" required><?php foreach($slots as $v=>$label):?><option value="<?=$v?>" <?=($r['scheduled_time']===$v?'selected':'')?>><?=$label?></option><?php endforeach;?></select></div></div>
<div class="info-banner"><strong>Available Time Slots:</strong> <?=e(implode(' · ',$slots))?></div>
<div class="form-grid"><div class="form-group full"><label>Remarks</label><textarea class="form-control" name="remarks" rows="3" placeholder="Optional scheduling notes..."><?=e($r['remarks'])?></textarea></div></div>
<div class="request-actions"><a class="btn btn-outline" href="dashboard.php?status=Pending">Cancel</a><button class="btn btn-primary" type="submit">Save Schedule</button></div>
</form></div></div>
<?php include '../includes/footer.php'; ?>
