<?php
require '../includes/config.php'; require_admin(); require_role(['Punong Barangay']); verify_csrf();
$pageTitle='Personnel Accounts'; $error=''; $msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $action=$_POST['action']??''; $id=(int)($_POST['admin_id']??0); $username=trim($_POST['username']??''); $fullName=trim($_POST['full_name']??''); $role=$_POST['role']??'Secretary'; $password=$_POST['password']??'';
 if(!in_array($role,['Punong Barangay','Secretary'],true)) $role='Secretary';
 if($action==='save'){
  if(!$username||!$fullName) $error='Username and full name are required.';
  elseif($id){
   $currentAccountQ=$conn->prepare('SELECT username FROM tbladmin WHERE admin_id=? LIMIT 1'); $currentAccountQ->bind_param('i',$id); $currentAccountQ->execute(); $currentAccount=$currentAccountQ->get_result()->fetch_assoc(); $currentUsername=$currentAccount['username']??'';
   if(in_array($currentUsername,['admin','secretary'],true) && $username!==$currentUsername){ $error='The standard Punong Barangay and Secretary usernames cannot be changed because they are used for role-based access.'; }
   elseif($currentUsername==='admin' && $role!=='Punong Barangay'){ $error='The admin account must remain the Punong Barangay account.'; }
   elseif($currentUsername==='secretary' && $role!=='Secretary'){ $error='The secretary account must remain the Barangay Secretary account.'; }
   elseif($id===(int)$_SESSION['admin_id'] && $role!=='Punong Barangay'){ $error='You cannot remove your own Punong Barangay role.'; }
   else{
    if($password!==''){
     if(strlen($password)<8){ $error='Password must be at least 8 characters.'; }
     else {
      $hash=password_hash($password,PASSWORD_DEFAULT);
      $st=$conn->prepare('UPDATE tbladmin SET username=?,full_name=?,role=?,password=?,password_plain=? WHERE admin_id=?');
      $st->bind_param('sssssi',$username,$fullName,$role,$hash,$password,$id);
      if($st->execute()){
       // The standard Punong Barangay and Secretary accounts intentionally share one personnel password.
       $sync=$conn->prepare("UPDATE tbladmin SET password=?,password_plain=? WHERE username IN ('admin','secretary')");
       $sync->bind_param('ss',$hash,$password); $sync->execute(); $sync->close();
       $msg='Account updated successfully. The standard Punong Barangay and Secretary password is synchronized.';
       log_audit($conn,'admin',$_SESSION['admin_id'],$_SESSION['admin_name']??'Admin','Updated Personnel Account','tbladmin',$id,$fullName.' ('.$role.')');
      } else $error='Username already exists.';
     }
    } else {
     $st=$conn->prepare('UPDATE tbladmin SET username=?,full_name=?,role=? WHERE admin_id=?');
     $st->bind_param('sssi',$username,$fullName,$role,$id);
     if($st->execute()){ $msg='Account updated successfully.'; log_audit($conn,'admin',$_SESSION['admin_id'],$_SESSION['admin_name']??'Admin','Updated Personnel Account','tbladmin',$id,$fullName.' ('.$role.')'); }
     else $error='Username already exists.';
    }
   }
  } else {
   if($password==='' || strlen($password)<8){ $error='Password is required and must be at least 8 characters for a new account.'; }
   else{
    $hash=password_hash($password,PASSWORD_DEFAULT);
    $st=$conn->prepare('INSERT INTO tbladmin(username,password,full_name,role,password_plain) VALUES(?,?,?,?,?)');
    $st->bind_param('sssss',$username,$hash,$fullName,$role,$password);
    if($st->execute()){ $msg='Account created successfully.'; log_audit($conn,'admin',$_SESSION['admin_id'],$_SESSION['admin_name']??'Admin','Created Personnel Account','tbladmin',$conn->insert_id,$fullName.' ('.$role.')'); }
    else $error='Username already exists.';
   }
  }
 } elseif($action==='toggle'&&$id){
  if($id===(int)$_SESSION['admin_id']){ $error='You cannot deactivate your own account.'; }
  else{
   $st=$conn->prepare('UPDATE tbladmin SET is_active=1-is_active WHERE admin_id=?'); $st->bind_param('i',$id); $st->execute();
   $msg='Account status updated.'; log_audit($conn,'admin',$_SESSION['admin_id'],$_SESSION['admin_name']??'Admin','Toggled Personnel Account Status','tbladmin',$id,null);
  }
 }
}
$edit=null; if(isset($_GET['edit'])){ $id=(int)$_GET['edit']; $st=$conn->prepare('SELECT * FROM tbladmin WHERE admin_id=?'); $st->bind_param('i',$id); $st->execute(); $edit=$st->get_result()->fetch_assoc(); }
$rows=$conn->query('SELECT * FROM tbladmin ORDER BY is_active DESC, role, full_name');
include '../includes/header.php';
?><div class="dashboard-grid"><div class="page-head"><div><h1>Personnel Accounts</h1><div class="muted">Manage Punong Barangay and Secretary accounts and their access level.</div></div></div>
<?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?><?php if($msg):?><div class="alert alert-success"><?=e($msg)?></div><?php endif;?>
<div class="dashboard-two">
<section class="card"><h3><?= $edit?'Edit Account':'Add Account'?></h3>
<form method="post"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="save"><input type="hidden" name="admin_id" value="<?=$edit?(int)$edit['admin_id']:0?>">
<div class="form-group"><label>Full Name *</label><input class="form-control" name="full_name" value="<?=e($edit['full_name']??'')?>" required></div><br>
<div class="form-group"><label>Username *</label><input class="form-control" name="username" value="<?=e($edit['username']??'')?>" required></div><br>
<div class="form-group"><label>Role *</label><select class="form-select" name="role" required><option value="Secretary" <?=($edit['role']??'')==='Secretary'?'selected':''?>>Secretary</option><option value="Punong Barangay" <?=($edit['role']??'')==='Punong Barangay'?'selected':''?>>Punong Barangay</option></select></div><br>
<div class="form-group"><label>Password <?= $edit?'(leave blank to keep current)':'*' ?></label><input type="password" class="form-control" name="password" placeholder="<?= $edit?'Leave blank to keep current password':'Minimum 8 characters' ?>"><small class="muted">For the standard Punong Barangay and Secretary accounts, use the same personnel password.</small></div><br>
<button class="btn btn-primary">Save Account</button><?php if($edit):?> <a class="btn btn-outline" href="accounts.php">Cancel</a><?php endif;?>
</form></section>
<section class="card"><div class="section-head"><h3>Personnel Accounts</h3></div><div class="table-wrap"><table class="table"><thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php while($a=$rows->fetch_assoc()):?>
<tr><td><strong><?=e($a['full_name'])?></strong><?= $a['admin_id']==$_SESSION['admin_id']?' <span class="small muted">(You)</span>':'' ?></td><td><?=e($a['username'])?></td><td><?=e($a['role'])?></td><td><span class="badge badge-<?= $a['is_active']?'scheduled':'rejected' ?>"><?= $a['is_active']?'Active':'Inactive'?></span></td><td><a class="btn btn-outline btn-small" href="accounts.php?edit=<?=$a['admin_id']?>">Edit</a> <?php if($a['admin_id']!=$_SESSION['admin_id']):?><form method="post" style="display:inline"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="admin_id" value="<?=$a['admin_id']?>"><button class="btn btn-outline btn-small"><?= $a['is_active']?'Deactivate':'Activate'?></button></form><?php endif;?></td></tr>
<?php endwhile;?>
</tbody></table></div></section>
</div></div><?php include '../includes/footer.php'; ?>
