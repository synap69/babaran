<?php
require '../includes/config.php';require_admin();$pageTitle='Personnel Dashboard';$msg='';$error='';$allowed=['Pending','Scheduled','Processing','Completed','Released','Rejected'];
if(isset($_GET['updated'])) $msg='Request updated successfully.';

$counts=$conn->query("SELECT status,COUNT(*) c FROM tblrequests GROUP BY status");$stat=array_fill_keys($allowed,0);while($c=$counts->fetch_assoc())$stat[$c['status']]=(int)$c['c'];
$totalRequestsRow=$conn->query("SELECT COUNT(*) c FROM tblrequests WHERE status<>'Draft'")->fetch_assoc();$totalRequests=(int)($totalRequestsRow['c']??0);
$totalResidentsRow=$conn->query("SELECT COUNT(*) c FROM tblresidents")->fetch_assoc();$totalResidents=(int)($totalResidentsRow['c']??0);

$filter=$_GET['status']??'All';
$search=trim($_GET['q']??'');
$from=trim($_GET['from']??'');
$to=trim($_GET['to']??'');
if($from && (!preg_match('/^\d{4}-\d{2}-\d{2}$/',$from) || !strtotime($from))) $from='';
if($to && (!preg_match('/^\d{4}-\d{2}-\d{2}$/',$to) || !strtotime($to))) $to='';
if($from && $to && $from>$to){ [$from,$to]=[$to,$from]; }

$sql="SELECT r.*,s.service_name,CONCAT(r.request_first_name,' ',COALESCE(r.request_middle_name,''),' ',r.request_last_name) resident_name FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE r.status<>'Draft'";
if(in_array($filter,$allowed,true))$sql.=" AND r.status='".$conn->real_escape_string($filter)."'";
if($search!==''){ $esc=$conn->real_escape_string($search); $sql.=" AND (CONCAT(r.request_first_name,' ',COALESCE(r.request_middle_name,''),' ',r.request_last_name) LIKE '%$esc%' OR r.request_contact LIKE '%$esc%' OR CONCAT('BB-',LPAD(r.request_id,5,'0')) LIKE '%$esc%')"; }
if($from) $sql.=" AND DATE(r.date_requested)>='".$conn->real_escape_string($from)."'";
if($to) $sql.=" AND DATE(r.date_requested)<='".$conn->real_escape_string($to)."'";
$sql.=' ORDER BY r.date_requested DESC LIMIT 20';
$requests=$conn->query($sql);

// Requests waiting the longest need attention first.
$needsAttention=$conn->query("SELECT r.request_id,r.date_requested,s.service_name,CONCAT(r.request_first_name,' ',COALESCE(r.request_middle_name,''),' ',r.request_last_name) resident_name FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE r.status='Pending' AND r.date_requested < DATE_SUB(NOW(), INTERVAL 3 DAY) ORDER BY r.date_requested ASC LIMIT 5");
$needsAttentionCount=$conn->query("SELECT COUNT(*) c FROM tblrequests WHERE status='Pending' AND date_requested < DATE_SUB(NOW(), INTERVAL 3 DAY)")->fetch_assoc()['c']??0;

$today=$conn->query("SELECT r.*,s.service_name FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE r.status='Scheduled' AND r.scheduled_date=CURDATE() ORDER BY r.scheduled_time LIMIT 6");
$typeRes=$conn->query("SELECT s.service_name sname,COUNT(*) c FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE r.status<>'Draft' GROUP BY s.service_name ORDER BY c DESC");
$typeData=[];$typeTotal=0;while($t=$typeRes->fetch_assoc()){$cnt=(int)$t['c'];$typeData[]=['label'=>$t['sname'],'count'=>$cnt];$typeTotal+=$cnt;}
$mostRequested=$typeData[0]??['label'=>'—','count'=>0];$leastRequested=$typeData[count($typeData)-1]??['label'=>'—','count'=>0];
$loginStats=['resident'=>0,'admin'=>0,'total'=>0];$lr=$conn->query("SELECT actor_type,COUNT(*) c FROM tbl_login_history GROUP BY actor_type");while($x=$lr->fetch_assoc()){$k=$x['actor_type'];if(isset($loginStats[$k]))$loginStats[$k]=(int)$x['c'];}$loginStats['total']=$loginStats['resident']+$loginStats['admin'];
$loginRecent=$conn->query("SELECT COUNT(*) c FROM tbl_login_history WHERE login_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch_assoc();$loginStats['recent']=(int)($loginRecent['c']??0);
$typeColors=['#2E9E4F','#20a05a','#6DA41B','#ffbf45','#e45555','#1F7A3A','#17a2b8','#e67e22','#75B01D','#637A6B'];

// Single grouped query for the 7-day activity chart instead of one query per day.
$chartRes=$conn->query("SELECT DATE(date_requested) d, COUNT(*) c FROM tblrequests WHERE status<>'Draft' AND date_requested >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) GROUP BY DATE(date_requested)");
$chartByDay=[];while($cr=$chartRes->fetch_assoc()){ $chartByDay[$cr['d']]=(int)$cr['c']; }
$chartDays=[];for($i=6;$i>=0;$i--){$d=date('Y-m-d',strtotime("-$i days"));$chartDays[]=['label'=>date('M d',strtotime($d)),'count'=>$chartByDay[$d]??0];}
$maxChart=max(1,max(array_column($chartDays,'count')));


// --- Requests Overview (monthly trend, current year) + Status Distribution donut ---
$monthlyRes=$conn->query("SELECT DATE_FORMAT(date_requested,'%Y-%m') ym, status, COUNT(*) c FROM tblrequests WHERE status<>'Draft' AND YEAR(date_requested)=YEAR(CURDATE()) GROUP BY ym, status");
$monthlyRaw=[];while($mr=$monthlyRes->fetch_assoc()){$monthlyRaw[$mr['ym']][$mr['status']]=(int)$mr['c'];}
$monthLabels=[];$seriesTotal=[];$seriesCompleted=[];$seriesPending=[];$seriesProcessing=[];
for($mo=1;$mo<=12;$mo++){
    $ym=date('Y').'-'.str_pad((string)$mo,2,'0',STR_PAD_LEFT);
    $monthLabels[]=date('M',mktime(0,0,0,$mo,1));
    $row=$monthlyRaw[$ym]??[];
    $seriesTotal[]=array_sum($row);
    $seriesCompleted[]=($row['Completed']??0)+($row['Released']??0);
    $seriesPending[]=$row['Pending']??0;
    $seriesProcessing[]=$row['Processing']??0;
}
$overviewSeries=['Total'=>['data'=>$seriesTotal,'color'=>'#2E9E4F'],'Completed'=>['data'=>$seriesCompleted,'color'=>'#20a05a'],'Pending'=>['data'=>$seriesPending,'color'=>'#ffbf45'],'Processing'=>['data'=>$seriesProcessing,'color'=>'#e45555']];
function bb_line_points($data,$yMax,$padL,$padT,$plotW,$plotH){
    $n=count($data);$stepX=$n>1?$plotW/($n-1):0;$out=[];
    foreach($data as $i=>$v){$x=$padL+$i*$stepX;$y=$padT+$plotH-($yMax>0?($v/$yMax)*$plotH:0);$out[]=round($x,1).','.round($y,1);}
    return $out;
}
$overviewMax=1;foreach($overviewSeries as $s){$overviewMax=max($overviewMax,max($s['data']));}
$overviewYMax=max(5,(int)ceil($overviewMax/5)*5);
$chartW=680;$chartH=230;$padL=32;$padR=10;$padT=14;$padB=26;$plotW=$chartW-$padL-$padR;$plotH=$chartH-$padT-$padB;

$statusColors=['Pending'=>'#ffbf45','Scheduled'=>'#6DA41B','Processing'=>'#e67e22','Completed'=>'#20a05a','Released'=>'#17a2b8','Rejected'=>'#e45555'];
$statusTotal=array_sum($stat);

include '../includes/header.php';
$backParam=urlencode('dashboard.php'.($_SERVER['QUERY_STRING']?'?'.$_SERVER['QUERY_STRING']:''));
?>
<div class="dashboard-grid">
<div class="hero-banner"><div class="hero-left"><div class="hero-icon"><i class="bi bi-bank"></i></div><div><div class="hero-eyebrow">Republic of the Philippines</div><div class="hero-title">Barangay Babaran Management System</div><div class="hero-sub">Personnel Dashboard — Document Requests & Records Portal</div></div></div><div class="hero-date"><i class="bi bi-calendar-event"></i> <?=date('l, F j, Y')?></div></div>
<div class="page-head"><div><h1>Dashboard</h1><div class="muted">Welcome back, <?=e($_SESSION['admin_name'])?>!</div></div><a class="btn btn-outline" href="calendar.php"><i class="bi bi-calendar3"></i> View Calendar</a></div>
<?php if($msg):?><div class="alert alert-success"><?=e($msg)?></div><?php endif;?><?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?>
<div class="stat-grid"><a class="stat-card stat-card-featured" href="dashboard.php"><div><small>Total Requests</small><strong><?=$totalRequests?></strong><small>All submitted requests</small></div><div class="stat-icon"><i class="bi bi-arrow-up-right"></i></div></a><a class="stat-card" href="dashboard.php?status=Pending"><div><small>Pending Requests</small><strong><?=$stat['Pending']?></strong><small>View all →</small></div><div class="stat-icon"><i class="bi bi-arrow-up-right"></i></div></a><a class="stat-card" href="dashboard.php?status=Scheduled"><div><small>Scheduled Requests</small><strong><?=$stat['Scheduled']?></strong><small>View all →</small></div><div class="stat-icon"><i class="bi bi-arrow-up-right"></i></div></a><a class="stat-card" href="dashboard.php?status=Completed"><div><small>Completed Requests</small><strong><?=$stat['Completed']?></strong><small>View all →</small></div><div class="stat-icon"><i class="bi bi-arrow-up-right"></i></div></a><a class="stat-card" href="dashboard.php?status=Released"><div><small>Released Requests</small><strong><?=$stat['Released']?></strong><small>View all →</small></div><div class="stat-icon"><i class="bi bi-arrow-up-right"></i></div></a></div>

<div class="dashboard-two" style="grid-template-columns:1.7fr 1fr">
<section class="card">
  <div class="section-head"><div><h3>Requests Overview</h3><p class="muted" style="margin:2px 0 0;font-size:11px">Request activity throughout <?=date('Y')?></p></div></div>
  <div class="line-chart-legend" style="display:flex;gap:16px;flex-wrap:wrap;margin-bottom:10px">
    <?php foreach($overviewSeries as $name=>$s): $gid='series-'.strtolower($name); ?>
    <label class="legend-toggle" style="display:flex;align-items:center;gap:6px;font-size:11px;font-weight:700;cursor:pointer;user-select:none">
      <input type="checkbox" checked data-target="<?=$gid?>" onchange="document.getElementById('<?=$gid?>').style.display=this.checked?'':'none';this.nextElementSibling.style.opacity=this.checked?'1':'.35'" style="accent-color:<?=$s['color']?>">
      <span style="display:flex;align-items:center;gap:5px"><i style="width:9px;height:9px;border-radius:50%;background:<?=$s['color']?>;display:inline-block"></i><?=e($name)?></span>
    </label>
    <?php endforeach; ?>
  </div>
  <svg width="100%" viewBox="0 0 <?=$chartW?> <?=$chartH?>" preserveAspectRatio="xMidYMid meet" aria-label="Requests overview for <?=date('Y')?>">
    <?php for($g=0;$g<=4;$g++): $gy=$padT+$plotH-($g/4)*$plotH; $gv=round(($overviewYMax/4)*$g); ?>
    <line x1="<?=$padL?>" y1="<?=$gy?>" x2="<?=$padL+$plotW?>" y2="<?=$gy?>" stroke="#EFF6EE" stroke-width="1"/>
    <text x="2" y="<?=$gy+3?>" font-size="9" fill="#9FB0A5"><?=$gv?></text>
    <?php endfor; ?>
    <?php foreach($monthLabels as $i=>$lbl): $stepX=$plotW/11; ?>
    <text x="<?=round($padL+$i*$stepX,1)?>" y="<?=$chartH-8?>" font-size="9" fill="#9FB0A5" text-anchor="middle"><?=e($lbl)?></text>
    <?php endforeach; ?>
    <?php foreach($overviewSeries as $name=>$s): $gid='series-'.strtolower($name); $pts=bb_line_points($s['data'],$overviewYMax,$padL,$padT,$plotW,$plotH); ?>
    <g id="<?=$gid?>">
      <polyline points="<?=implode(' ',$pts)?>" fill="none" stroke="<?=$s['color']?>" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>
      <?php foreach($pts as $i=>$p): [$px,$py]=explode(',',$p); ?>
      <circle cx="<?=$px?>" cy="<?=$py?>" r="3" fill="<?=$s['color']?>"><title><?=e($name)?> · <?=e($monthLabels[$i])?>: <?=$s['data'][$i]?></title></circle>
      <?php endforeach; ?>
    </g>
    <?php endforeach; ?>
  </svg>
</section>
<section class="card donut-card">
  <div class="section-head"><h3>Status Distribution</h3><span class="muted small"><?=$statusTotal?> total</span></div>
  <?php if(!$statusTotal):?><div class="donut-empty muted">No requests yet.</div><?php else:
  $r=70;$sw=34;$circ=2*M_PI*$r;$offset=0;?>
  <div class="donut-body">
    <svg class="donut-svg" width="200" height="200" viewBox="0 0 200 200">
      <g transform="rotate(-90 100 100)">
        <?php foreach($stat as $sName=>$sCount): $portion=$statusTotal?($sCount/$statusTotal)*$circ:0; $color=$statusColors[$sName]??'#637A6B'; ?>
        <circle cx="100" cy="100" r="<?=$r?>" fill="none" stroke="<?=$color?>" stroke-width="<?=$sw?>" stroke-dasharray="<?=round($portion,2)?> <?=round($circ-$portion,2)?>" stroke-dashoffset="<?=round(-$offset,2)?>"><title><?=e($sName)?>: <?=$sCount?></title></circle>
        <?php $offset+=$portion; endforeach; ?>
      </g>
      <text x="100" y="95" text-anchor="middle" font-size="26" font-weight="800" fill="var(--text)"><?=$statusTotal?></text>
      <text x="100" y="115" text-anchor="middle" font-size="10" fill="var(--muted)">Total</text>
    </svg>
    <div class="donut-legend">
      <?php foreach($stat as $sName=>$sCount): $pct=$statusTotal?round(($sCount/$statusTotal)*100,1):0; $color=$statusColors[$sName]??'#637A6B'; ?>
      <div class="legend-row"><span class="legend-dot" style="background:<?=$color?>"></span><span class="legend-label"><?=e($sName)?></span><span class="legend-count"><?=$sCount?></span><span class="legend-pct"><?=$pct?>%</span></div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>
</section>
</div>

<div class="dashboard-two">
<section class="card" style="<?=$needsAttentionCount?'border-left:4px solid #e45555':''?>">
  <div class="section-head"><h3><i class="bi bi-exclamation-circle" style="color:#e45555"></i> Needs Attention</h3><?php if($needsAttentionCount>5):?><a href="dashboard.php?status=Pending">View All ›</a><?php endif;?></div>
  <?php if(!$needsAttentionCount):?><div class="empty muted">Nothing overdue — all pending requests are within 3 days.</div><?php else:?>
  <div class="activity-list"><?php while($n=$needsAttention->fetch_assoc()):
    $waitDays=(int)floor((time()-strtotime($n['date_requested']))/86400); ?>
    <div class="activity-item"><span><i class="bi bi-hourglass-split"></i></span><div><strong><?=e(preg_replace('/\s+/',' ',trim($n['resident_name'])))?> · <?=e($n['service_name'])?></strong><span>Waiting <?=$waitDays?> day<?=$waitDays===1?'':'s'?> · <a href="request_manage.php?id=<?=$n['request_id']?>&back=<?=$backParam?>">Manage now →</a></span></div></div>
  <?php endwhile;?></div>
  <?php endif;?>
</section>
<section class="card"><div class="section-head"><h3>Today's Schedule</h3><a href="calendar.php">View Calendar ›</a></div><?php if(!$today->num_rows):?><div class="empty muted">No scheduled requests for today.</div><?php else:?><div class="schedule-list"><?php while($t=$today->fetch_assoc()):?><div class="schedule-item"><div class="schedule-time"><?=date('h:i A',strtotime($t['scheduled_time']))?></div><div><strong><?=e(trim($t['request_first_name'].' '.$t['request_last_name']))?></strong><span><?=e($t['service_name'])?></span></div></div><?php endwhile;?></div><?php endif;?></section>
</div>

<div class="activity-card card"><div class="activity-head"><div><h3>Request Activity</h3><p class="muted">Submitted requests for the last 7 days</p></div><div class="activity-summary"><strong><?=$totalRequests?></strong><span>Total requests</span><strong><?=$totalResidents?></strong><span>Registered residents</span></div></div><div class="bar-chart" aria-label="Request activity for the last 7 days"><?php foreach($chartDays as $day): $height=$day['count']?max(12,round(($day['count']/$maxChart)*150)):6; ?><div class="bar-col"><div class="bar-value"><?=$day['count']?></div><div class="bar" style="height:<?=$height?>px"></div><div class="bar-label"><?=e($day['label'])?></div></div><?php endforeach;?></div></div>
<div class="card donut-card"><div class="section-head"><h3>Requests by Document Type</h3><span class="muted small"><?=$typeTotal?> total</span></div><?php if(!$typeTotal):?><div class="donut-empty muted">No requests yet.</div><?php else:
$r=70;$sw=34;$circ=2*M_PI*$r;$offset=0;?><div class="donut-body"><svg class="donut-svg" width="200" height="200" viewBox="0 0 200 200"><g transform="rotate(-90 100 100)"><?php foreach($typeData as $i=>$d): $portion=$typeTotal?($d['count']/$typeTotal)*$circ:0; $color=$typeColors[$i%count($typeColors)]; ?><circle cx="100" cy="100" r="<?=$r?>" fill="none" stroke="<?=$color?>" stroke-width="<?=$sw?>" stroke-dasharray="<?=round($portion,2)?> <?=round($circ-$portion,2)?>" stroke-dashoffset="<?=round(-$offset,2)?>"><title><?=e($d['label'])?>: <?=$d['count']?></title></circle><?php $offset+=$portion; endforeach; ?></g><text x="100" y="95" text-anchor="middle" font-size="26" font-weight="800" fill="var(--text)"><?=$typeTotal?></text><text x="100" y="115" text-anchor="middle" font-size="10" fill="var(--muted)">Total Requests</text></svg><div class="donut-legend"><div class="legend-row" style="font-weight:800;color:var(--blue);margin-bottom:2px"><i class="bi bi-star-fill"></i> Most requested: <?=e($mostRequested['label'])?> (<?=$mostRequested['count']?>)</div><div class="legend-row" style="font-weight:800;color:var(--muted);margin-bottom:8px"><i class="bi bi-arrow-down"></i> Least requested: <?=e($leastRequested['label'])?> (<?=$leastRequested['count']?>)</div><?php foreach($typeData as $i=>$d): $pct=$typeTotal?round(($d['count']/$typeTotal)*100):0; $color=$typeColors[$i%count($typeColors)]; ?><div class="legend-row"><span class="legend-dot" style="background:<?=$color?>"></span><span class="legend-label"><?=e($d['label'])?></span><span class="legend-count"><?=$d['count']?></span><span class="legend-pct"><?=$pct?>%</span></div><?php endforeach; ?></div></div><?php endif; ?></div>

<section class="card">
  <div class="section-head"><h3>Pending Requests<?=($filter!=='All'?' · '.e($filter):'')?></h3><a href="dashboard.php">Reset ›</a></div>
  <form method="get" class="form-grid" style="margin-bottom:14px;align-items:end">
    <input type="hidden" name="status" value="<?=e($filter)?>">
    <div class="form-group"><label>Search</label><input type="text" class="form-control" name="q" placeholder="Name, contact, or queue no." value="<?=e($search)?>"></div>
    <div class="form-group"><label>From</label><input type="date" class="form-control" name="from" value="<?=e($from)?>"></div>
    <div class="form-group"><label>To</label><input type="date" class="form-control" name="to" value="<?=e($to)?>"></div>
    <div class="form-group"><button class="btn btn-primary" style="width:100%">Filter</button></div>
  </form>
  <?php if(!$requests->num_rows):?><div class="empty muted">No requests found.</div><?php else:?><div class="table-wrap"><table class="table"><thead><tr><th>Queue No.</th><th>Resident Name</th><th>Document Type</th><th>Date Requested</th><th>Status</th><th>Action</th></tr></thead><tbody><?php while($rr=$requests->fetch_assoc()):?><tr><td><strong><?=e(queue_number($rr['request_id']))?></strong></td><td><?=e(preg_replace('/\s+/',' ',trim($rr['resident_name'])))?><br><span class="small muted"><?=e($rr['request_contact']?:'No contact')?></span></td><td><?=e($rr['service_name'])?></td><td><?=date('M d, Y',strtotime($rr['date_requested']))?><br><?=date('h:i A',strtotime($rr['date_requested']))?></td><td><span class="badge badge-<?=strtolower($rr['status'])?>"><?=e($rr['status'])?></span></td><td><a class="btn btn-outline btn-small" href="request_manage.php?id=<?=$rr['request_id']?>&back=<?=$backParam?>">Manage</a></td></tr><?php endwhile;?></tbody></table></div><?php endif;?>
</section>

<div class="dashboard-two" style="grid-template-columns:1fr"><section class="card"><div class="section-head"><div><h3>Login Activity</h3><p class="muted">Resident and admin logins recorded by the system</p></div><a href="login_history.php">View All ›</a></div><div class="stat-grid" style="margin-bottom:16px"><div class="stat-card stat-blue"><div><small>Total Logins</small><strong><?=$loginStats['total']?></strong><small>All recorded logins</small></div><div class="stat-icon blue"><i class="bi bi-arrow-repeat"></i></div></div><div class="stat-card stat-green"><div><small>Resident Logins</small><strong><?=$loginStats['resident']?></strong><small>All resident logins</small></div><div class="stat-icon green"><i class="bi bi-person"></i></div></div><div class="stat-card stat-purple"><div><small>Admin Logins</small><strong><?=$loginStats['admin']?></strong><small>All admin logins</small></div><div class="stat-icon purple"><i class="bi bi-gear"></i></div></div><div class="stat-card stat-yellow"><div><small>Last 7 Days</small><strong><?=$loginStats['recent']?></strong><small>Recent login activity</small></div><div class="stat-icon yellow"><i class="bi bi-calendar-week"></i></div></div></div><?php $history=$conn->query("SELECT h.*,CASE WHEN h.actor_type='admin' THEN a.full_name ELSE CONCAT(r.first_name,' ',COALESCE(r.middle_name,''),' ',r.last_name) END actor_name,CASE WHEN h.actor_type='admin' THEN 'Admin' ELSE 'Resident' END actor_role FROM tbl_login_history h LEFT JOIN tblresidents r ON r.resident_id=h.resident_id LEFT JOIN tbladmin a ON a.admin_id=h.admin_id ORDER BY h.login_at DESC LIMIT 10"); ?><?php if(!$history || !$history->num_rows):?><div class="empty muted">No resident login history yet.</div><?php else:?><div class="table-wrap"><table class="table"><thead><tr><th>User</th><th>Role</th><th>Login Used</th><th>Date</th><th>Time</th><th>IP Address</th></tr></thead><tbody><?php while($h=$history->fetch_assoc()):?><tr><td><strong><?=e(preg_replace('/\s+/',' ',trim($h['actor_name']?:'Unknown')))?></strong></td><td><?=e($h['actor_role'])?></td><td><?=e($h['login_identifier'])?></td><td><?=date('M d, Y',strtotime($h['login_at']))?></td><td><?=date('h:i A',strtotime($h['login_at']))?></td><td><?=e($h['ip_address']?:'N/A')?></td></tr><?php endwhile;?></tbody></table></div><?php endif;?></section></div>
<div class="dashboard-two" style="grid-template-columns:1fr"><section class="card"><div class="section-head"><h3>Quick Actions</h3></div><div class="quick-actions">
<a class="quick-action" href="dashboard.php?status=Pending"><div class="quick-icon yellow"><i class="bi bi-list-check"></i></div><div class="quick-body">Review Pending Requests<span>Approve, schedule, or reject queued requests</span></div><i class="bi bi-chevron-right quick-chevron"></i></a>
<a class="quick-action" href="calendar.php"><div class="quick-icon purple"><i class="bi bi-calendar3"></i></div><div class="quick-body">Manage Schedule<span>View and assign appointment slots</span></div><i class="bi bi-chevron-right quick-chevron"></i></a>
<a class="quick-action" href="dashboard.php?status=Processing"><div class="quick-icon blue"><i class="bi bi-arrow-repeat"></i></div><div class="quick-body">Processing Requests<span>Track requests currently being prepared</span></div><i class="bi bi-chevron-right quick-chevron"></i></a>
<a class="quick-action" href="dashboard.php?status=Completed"><div class="quick-icon green"><i class="bi bi-check-circle"></i></div><div class="quick-body">Completed Requests<span>Ready documents awaiting release</span></div><i class="bi bi-chevron-right quick-chevron"></i></a>
<a class="quick-action" href="dashboard.php?status=Released"><div class="quick-icon teal"><i class="bi bi-file-earmark-check"></i></div><div class="quick-body">Released Documents<span>Fully completed and released requests</span></div><i class="bi bi-chevron-right quick-chevron"></i></a>
</div></section></div></div>
<?php include '../includes/footer.php'; ?>
