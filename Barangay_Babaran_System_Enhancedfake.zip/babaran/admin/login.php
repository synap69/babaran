<?php
require '../includes/config.php';$pageTitle='Personnel Login';$error='';if(isset($_SESSION['admin_id'])){header('Location: dashboard.php');exit;}
if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();
    $u=trim($_POST['username']??'');
    $p=$_POST['password']??'';
    $role=$_POST['role']??'Punong Barangay';
    if(!in_array($role,['Punong Barangay','Secretary'],true)) $role='Punong Barangay';
    if($u===''||$p==='') $error='Please enter your username, password, and role.';
    else {
        $st=$conn->prepare('SELECT admin_id,username,password,full_name,role,is_active FROM tbladmin WHERE username=? AND role=? LIMIT 1');
        $st->bind_param('ss',$u,$role); $st->execute(); $row=$st->get_result()->fetch_assoc(); $st->close();
        if($row&&!(int)$row['is_active']) $error='This account has been deactivated. Contact the Punong Barangay.';
        elseif($row&&password_verify($p,$row['password'])){
            login_session('admin',$row['admin_id'],$row['full_name'],$row['role']);
            $ip=$_SERVER['REMOTE_ADDR']??null; $ua=substr($_SERVER['HTTP_USER_AGENT']??'',0,255);
            $lh=$conn->prepare("INSERT INTO tbl_login_history(actor_type,admin_id,login_identifier,ip_address,user_agent) VALUES('admin',?,?,?,?)");
            $lh->bind_param('isss',$row['admin_id'],$u,$ip,$ua); $lh->execute(); $lh->close();
            header('Location: dashboard.php'); exit;
        } else $error='Invalid '.$role.' username or password.';
    }
}
include '../includes/header.php';
?><div class="register-page"><div class="login-layout"><div class="login-card login-card-solo"><section class="login-form"><div class="register-card-toolbar"><a class="btn-back-in" href="../index.php"><i class="bi bi-arrow-left"></i> Back</a></div><div class="login-icon"><i class="bi bi-shield-lock"></i></div><h2>Personnel Sign In</h2><p>Authorized Barangay Babaran personnel only</p><?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><div class="form-group"><label>Role</label><select class="form-select" name="role" required><option value="Punong Barangay" <?=($_POST['role']??'Punong Barangay')==='Punong Barangay'?'selected':''?>>Punong Barangay</option><option value="Secretary" <?=($_POST['role']??'')==='Secretary'?'selected':''?>>Barangay Secretary</option></select></div><br><div class="form-group"><label>Username</label><input class="form-control" name="username" placeholder="Enter username" required></div><br><div class="form-group"><label>Password</label><div class="password-wrap"><input type="password" id="adminPassword" class="form-control" name="password" placeholder="Enter password" required><button type="button" class="password-toggle" data-toggle-target="adminPassword" aria-label="Show password" title="Show password"><i class="bi bi-eye password-eye-icon"></i></button></div></div><br><button class="btn btn-register" style="width:100%"><i class="bi bi-box-arrow-in-right"></i> &nbsp; SIGN IN</button></form><div class="login-bottom"><a href="../index.php" style="color:var(--blue)"><i class="bi bi-arrow-left"></i> Choose User Type</a></div></section></div></div></div><?php include '../includes/footer.php'; ?>
