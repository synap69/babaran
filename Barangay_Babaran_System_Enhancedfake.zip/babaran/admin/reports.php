<?php
require '../includes/config.php';require_admin();$pageTitle='Reports & Analysis';
$from=$_GET['from']??date('Y-m-01');
$to=$_GET['to']??date('Y-m-d');
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$from) || !strtotime($from))$from=date('Y-m-01');
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$to) || !strtotime($to))$to=date('Y-m-d');
if($from>$to){ [$from,$to]=[$to,$from]; }
$fromEsc=$conn->real_escape_string($from);
$toEsc=$conn->real_escape_string($to);
$range="r.status<>'Draft' AND DATE(r.date_requested) BETWEEN '$fromEsc' AND '$toEsc'";

$allowed=['Pending','Scheduled','Processing','Completed','Released','Rejected'];
$statusRes=$conn->query("SELECT r.status,COUNT(*) c FROM tblrequests r WHERE $range GROUP BY r.status");
$statusData=array_fill_keys($allowed,0);while($s=$statusRes->fetch_assoc())$statusData[$s['status']]=(int)$s['c'];
$totalInRange=array_sum($statusData);
$completionRate=$totalInRange?round(($statusData['Completed']/$totalInRange)*100):0;

$typeRes=$conn->query("SELECT s.service_name sname,COUNT(*) c FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE $range GROUP BY s.service_name ORDER BY c DESC");
$typeData=[];$typeTotal=0;while($t=$typeRes->fetch_assoc()){$cnt=(int)$t['c'];$typeData[]=['label'=>$t['sname'],'count'=>$cnt];$typeTotal+=$cnt;}
$typeColors=['#2E9E4F','#20a05a','#6DA41B','#ffbf45','#e45555','#1F7A3A','#17a2b8','#e67e22','#75B01D','#637A6B'];
$mostRequested=$typeData[0]??null;
$leastRequested=$typeData? $typeData[count($typeData)-1] : null;

$dailyRes=$conn->query("SELECT DATE(r.date_requested) d,COUNT(*) c FROM tblrequests r WHERE $range GROUP BY DATE(r.date_requested) ORDER BY d ASC");
$dailyData=[];while($d=$dailyRes->fetch_assoc())$dailyData[]=['label'=>date('M d',strtotime($d['d'])),'count'=>(int)$d['c']];
$dailyMax=max(1,$dailyData?max(array_column($dailyData,'count')):1);

$weeklyRes=$conn->query("SELECT YEAR(r.date_requested) yr,WEEK(r.date_requested,1) wk,COUNT(*) c,MIN(DATE(r.date_requested)) week_start,MAX(DATE(r.date_requested)) week_end FROM tblrequests r WHERE $range GROUP BY YEAR(r.date_requested),WEEK(r.date_requested,1) ORDER BY yr,wk ASC");
$weeklyData=[];while($w=$weeklyRes->fetch_assoc())$weeklyData[]=['label'=>'W'.$w['wk'].' '.date('Y',strtotime($w['week_start'])),'count'=>(int)$w['c'],'range'=>date('M d',strtotime($w['week_start'])).'–'.date('M d',strtotime($w['week_end']))];
$weeklyMax=max(1,$weeklyData?max(array_column($weeklyData,'count')):1);

$yearlyRes=$conn->query("SELECT YEAR(r.date_requested) yr,COUNT(*) c FROM tblrequests r WHERE $range GROUP BY YEAR(r.date_requested) ORDER BY yr ASC");
$yearlyData=[];while($y=$yearlyRes->fetch_assoc())$yearlyData[]=['label'=>$y['yr'],'count'=>(int)$y['c']];
$yearlyMax=max(1,$yearlyData?max(array_column($yearlyData,'count')):1);

$monthRes=$conn->query("SELECT DATE_FORMAT(r.date_requested,'%Y-%m') ym,COUNT(*) c FROM tblrequests r WHERE $range GROUP BY ym ORDER BY ym ASC");
$monthData=[];while($m=$monthRes->fetch_assoc())$monthData[]=['label'=>date('M Y',strtotime($m['ym'].'-01')),'count'=>(int)$m['c']];
$monthMax=max(1,$monthData?max(array_column($monthData,'count')):1);

include '../includes/header.php';
?>
<div class="dashboard-grid">
<div class="page-head"><div><h1>Reports & Analysis</h1><div class="muted">Document request analysis for the selected date range.</div></div><a class="btn btn-outline" href="dashboard.php"><i class="bi bi-arrow-left"></i> Back to Dashboard</a></div>

<section class="card"><form method="get" class="form-grid" style="align-items:end;grid-template-columns:1fr 1fr auto">
<div class="form-group"><label>From</label><input class="form-control" type="date" name="from" value="<?=e($from)?>"></div>
<div class="form-group"><label>To</label><input class="form-control" type="date" name="to" value="<?=e($to)?>"></div>
<div class="form-group"><button class="btn btn-primary">Apply Filter</button></div>
</form></section>

<div class="stat-grid">
<div class="stat-card"><div><small>Total Requests</small><strong><?=$totalInRange?></strong></div><div class="stat-icon blue"><i class="bi bi-file-earmark-text"></i></div></div>
<div class="stat-card"><div><small>Completed</small><strong><?=$statusData['Completed']?></strong></div><div class="stat-icon green"><i class="bi bi-check-circle-fill"></i></div></div>
<div class="stat-card"><div><small>Pending</small><strong><?=$statusData['Pending']?></strong></div><div class="stat-icon yellow"><i class="bi bi-hourglass"></i></div></div>
<div class="stat-card"><div><small>Completion Rate</small><strong><?=$completionRate?>%</strong></div><div class="stat-icon purple"><i class="bi bi-percent"></i></div></div>
</div>

<section class="card" style="margin-top:18px">
<div class="section-head"><h3>Most Requested Document</h3></div>
<?php if(!$mostRequested):?><div class="empty muted">No requests in this date range.</div><?php else:?>
<div class="schedule-item" style="border:0"><div class="schedule-time" style="background:#EDF8ED;color:var(--blue);border-radius:8px;padding:8px 14px;min-width:auto">#1</div><div><strong><?=e($mostRequested['label'])?></strong><span><?=$mostRequested['count']?> request<?=$mostRequested['count']==1?'':'s'?> in the selected range (<?=$typeTotal?round(round(($mostRequested['count']/$typeTotal)*100)):0?>% of total)</span></div></div>
<?php endif;?>
</section>

<div class="card donut-card" style="margin-top:18px"><div class="section-head"><h3>Document Request Analysis</h3><span class="muted small"><?=$typeTotal?> total</span></div><?php if(!$typeTotal):?><div class="donut-empty muted">No requests in this date range.</div><?php else:
$rad=70;$sw=34;$circ=2*M_PI*$rad;$offset=0;?><div class="donut-body"><svg class="donut-svg" width="200" height="200" viewBox="0 0 200 200"><g transform="rotate(-90 100 100)"><?php foreach($typeData as $i=>$d): $portion=$typeTotal?($d['count']/$typeTotal)*$circ:0; $color=$typeColors[$i%count($typeColors)]; ?><circle cx="100" cy="100" r="<?=$rad?>" fill="none" stroke="<?=$color?>" stroke-width="<?=$sw?>" stroke-dasharray="<?=round($portion,2)?> <?=round($circ-$portion,2)?>" stroke-dashoffset="<?=round(-$offset,2)?>"><title><?=e($d['label'])?>: <?=$d['count']?></title></circle><?php $offset+=$portion; endforeach; ?></g><text x="100" y="95" text-anchor="middle" font-size="26" font-weight="800" fill="var(--text)"><?=$typeTotal?></text><text x="100" y="115" text-anchor="middle" font-size="10" fill="var(--muted)">Total Requests</text></svg><div class="donut-legend"><?php foreach($typeData as $i=>$d): $pct=$typeTotal?round(($d['count']/$typeTotal)*100):0; $color=$typeColors[$i%count($typeColors)]; ?><div class="legend-row"><span class="legend-dot" style="background:<?=$color?>"></span><span class="legend-label"><?=e($d['label'])?></span><span class="legend-count"><?=$d['count']?></span><span class="legend-pct"><?=$pct?>%</span></div><?php endforeach; ?></div></div><?php endif; ?></div>

<section class="card" style="margin-top:18px"><div class="section-head"><h3>Requests by Status</h3></div>
<?php $statusColors=['Pending'=>'#ffbf45','Scheduled'=>'#6DA41B','Processing'=>'#f59e0b','Completed'=>'#20a05a','Released'=>'#17b8a0','Rejected'=>'#e45555']; $statusMax=max(1,max($statusData)); ?>
<div class="bar-chart" style="height:170px" aria-label="Requests by status"><?php foreach($statusData as $label=>$count): $height=$count?max(12,round(($count/$statusMax)*130)):6; ?><div class="bar-col"><div class="bar-value"><?=$count?></div><div class="bar" style="height:<?=$height?>px;background:<?=$statusColors[$label]?>"></div><div class="bar-label"><?=e($label)?></div></div><?php endforeach;?></div>
</section>

<section class="card" style="margin-top:18px"><div class="section-head"><h3>Monthly Request Trend</h3><span class="muted small">Requests submitted per month in range</span></div>
<?php if(!$monthData):?><div class="empty muted">No requests in this date range.</div><?php else:?>
<div class="bar-chart" style="height:190px" aria-label="Monthly request trend"><?php foreach($monthData as $m): $height=$m['count']?max(12,round(($m['count']/$monthMax)*150)):6; ?><div class="bar-col"><div class="bar-value"><?=$m['count']?></div><div class="bar" style="height:<?=$height?>px"></div><div class="bar-label"><?=e($m['label'])?></div></div><?php endforeach;?></div>
<?php endif;?>
</section>

<section class="card" style="margin-top:18px"><div class="section-head"><h3>Request Highlights</h3></div>
<div class="stat-grid" style="margin-top:0">
<div class="stat-card"><div><small>Most Requested Document</small><strong style="font-size:18px"><?=e($mostRequested['label']??'N/A')?></strong><span class="muted small"><?=($mostRequested['count']??0)?> request<?=($mostRequested['count']??0)==1?'':'s'?></span></div></div>
<div class="stat-card"><div><small>Least Requested Document</small><strong style="font-size:18px"><?=e($leastRequested['label']??'N/A')?></strong><span class="muted small"><?=($leastRequested['count']??0)?> request<?=($leastRequested['count']??0)==1?'':'s'?></span></div></div>
</div></section>

<section class="card" style="margin-top:18px"><div class="section-head"><h3>Daily Request Statistics</h3><span class="muted small">Requests submitted per day</span></div>
<?php if(!$dailyData):?><div class="empty muted">No requests in this date range.</div><?php else:?><div class="bar-chart" style="height:190px;overflow-x:auto" aria-label="Daily request statistics"><?php foreach($dailyData as $d): $height=$d['count']?max(12,round(($d['count']/$dailyMax)*150)):6; ?><div class="bar-col" title="<?=$d['label']?>: <?=$d['count']?>"><div class="bar-value"><?=$d['count']?></div><div class="bar" style="height:<?=$height?>px"></div><div class="bar-label"><?=e($d['label'])?></div></div><?php endforeach;?></div><?php endif;?>
</section>

<section class="card" style="margin-top:18px"><div class="section-head"><h3>Weekly Request Statistics</h3><span class="muted small">Requests grouped by ISO week</span></div>
<?php if(!$weeklyData):?><div class="empty muted">No requests in this date range.</div><?php else:?><div class="bar-chart" style="height:190px;overflow-x:auto" aria-label="Weekly request statistics"><?php foreach($weeklyData as $w): $height=$w['count']?max(12,round(($w['count']/$weeklyMax)*150)):6; ?><div class="bar-col" title="<?=$w['range']?>: <?=$w['count']?>"><div class="bar-value"><?=$w['count']?></div><div class="bar" style="height:<?=$height?>px"></div><div class="bar-label"><?=e($w['label'])?></div></div><?php endforeach;?></div><?php endif;?>
</section>

<section class="card" style="margin-top:18px"><div class="section-head"><h3>Yearly Request Statistics</h3><span class="muted small">Requests submitted per year</span></div>
<?php if(!$yearlyData):?><div class="empty muted">No requests in this date range.</div><?php else:?><div class="bar-chart" style="height:190px" aria-label="Yearly request statistics"><?php foreach($yearlyData as $y): $height=$y['count']?max(12,round(($y['count']/$yearlyMax)*150)):6; ?><div class="bar-col"><div class="bar-value"><?=$y['count']?></div><div class="bar" style="height:<?=$height?>px"></div><div class="bar-label"><?=e($y['label'])?></div></div><?php endforeach;?></div><?php endif;?>
</section>

<section class="card" style="margin-top:18px"><div class="section-head"><h3>Document Type Breakdown</h3></div>
<?php if(!$typeData):?><div class="empty muted">No requests in this date range.</div><?php else:?>
<div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>Document Type</th><th>Request Count</th><th>Share</th></tr></thead><tbody>
<?php foreach($typeData as $i=>$d): $pct=$typeTotal?round(($d['count']/$typeTotal)*100):0; ?><tr><td><?=$i+1?></td><td><strong><?=e($d['label'])?></strong></td><td><?=$d['count']?></td><td><?=$pct?>%</td></tr><?php endforeach;?>
</tbody></table></div>
<?php endif;?>
</section>

</div>
<?php include '../includes/footer.php'; ?>
