<?php
require '../includes/config.php';
require_admin();
require_once '../includes/notifications.php';

$pageTitle = 'Manage Request';
$error = '';
$msg = '';
$id = (int)($_GET['id'] ?? $_POST['request_id'] ?? 0);
if (!$id) {
    header('Location: dashboard.php');
    exit;
}
$allowed = ['Pending', 'Scheduled', 'Processing', 'Completed', 'Released', 'Rejected'];
$back = $_GET['back'] ?? ($_POST['back'] ?? 'dashboard.php');
$back = (strpos($back, 'dashboard.php') === 0) ? $back : 'dashboard.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $status  = $_POST['status'] ?? '';
    $remarks = trim($_POST['remarks'] ?? '');
    $date    = $_POST['scheduled_date'] ?? '';
    $time    = $_POST['scheduled_time'] ?? '';
    $sig     = trim($_POST['personnel_signature'] ?? '');

    $currentQ = $conn->prepare('SELECT status FROM tblrequests WHERE request_id=?');
    $currentQ->bind_param('i', $id);
    $currentQ->execute();
    $currentStatus = $currentQ->get_result()->fetch_assoc()['status'] ?? '';

    $validTransition = ($status === $currentStatus)
        || ($status === 'Rejected' && in_array($currentStatus, ['Pending', 'Scheduled', 'Processing'], true))
        || ($currentStatus === 'Pending' && $status === 'Scheduled')
        || ($currentStatus === 'Scheduled' && $status === 'Processing')
        || ($currentStatus === 'Processing' && $status === 'Completed')
        || ($currentStatus === 'Completed' && $status === 'Released');

    if (!in_array($status, $allowed, true)) {
        $error = 'Invalid status.';
    } elseif (!$validTransition) {
        $error = 'Invalid workflow transition. Follow Pending → Scheduled → Processing → Completed → Released.';
    } elseif ($status === 'Scheduled' && (!$date || !$time)) {
        $error = 'Scheduled requests require date and time.';
    } else {
        // Stronger conflict checking: also of ±30 minutes around the chosen slot
        if (!$error && $status === 'Scheduled') {
            if (strtotime($date) < strtotime(date('Y-m-d'))) {
                $error = 'Schedule date cannot be in the past.';
            } else {
                $cq = $conn->prepare("
                    SELECT request_id FROM tblrequests
                    WHERE scheduled_date = ?
                      AND ABS(TIME_TO_SEC(scheduled_time) - TIME_TO_SEC(?)) < 1800
                      AND request_id <> ?
                      AND status IN ('Scheduled','Processing')
                    LIMIT 1
                ");
                $cq->bind_param('ssi', $date, $time, $id);
                $cq->execute();
                if ($cq->get_result()->fetch_assoc()) {
                    $error = 'That date and time slot (or a nearby 30-minute window) is already assigned to another request.';
                }
            }
        }

        if (!$error) {
            if ($status === 'Rejected' || $status === 'Pending') {
                $date = null;
                $time = null;
            }
            $sql = "UPDATE tblrequests SET status=?, remarks=?, scheduled_date=NULLIF(?,''), scheduled_time=NULLIF(?,'')";
            if ($sig) {
                $sql .= ", personnel_signature=?, personnel_signed_at=NOW()";
            } elseif (in_array($status, ['Pending', 'Rejected'], true)) {
                $sql .= ", personnel_signature=NULL, personnel_signed_at=NULL";
            }
            $sql .= " WHERE request_id=?";
            $st = $conn->prepare($sql);
            if ($sig) {
                $st->bind_param('sssssi', $status, $remarks, $date, $time, $sig, $id);
            } else {
                $st->bind_param('ssssi', $status, $remarks, $date, $time, $id);
            }

            if ($st->execute()) {
                // Keep dedicated schedule table in sync
                if ($date && $time && in_array($status, ['Scheduled', 'Processing', 'Completed', 'Released'], true)) {
                    $schedStatus = in_array($status, ['Completed', 'Released'], true) ? 'Completed' : 'Scheduled';
                    $su = $conn->prepare("INSERT INTO tblschedules(request_id,scheduled_date,scheduled_time,status,remarks) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE scheduled_date=VALUES(scheduled_date),scheduled_time=VALUES(scheduled_time),status=VALUES(status),remarks=VALUES(remarks)");
                    $su->bind_param('issss', $id, $date, $time, $schedStatus, $remarks);
                    $su->execute();
                    $su->close();
                } else {
                    $sd = $conn->prepare('DELETE FROM tblschedules WHERE request_id=?');
                    $sd->bind_param('i', $id);
                    $sd->execute();
                    $sd->close();
                }

                log_audit($conn, 'admin', $_SESSION['admin_id'], $_SESSION['admin_name'] ?? 'Admin', $currentStatus . ' -> ' . $status, 'tblrequests', $id, $remarks ? trim($remarks) : null);

                // Automated email notification on status change
                if ($status !== $currentStatus) {
                    notify_request_status_change($conn, $id, $status);
                }

                header('Location: ' . $back . (strpos($back, '?') === false ? '?' : '&') . 'updated=1');
                exit;
            } else {
                $error = 'Unable to update request.';
            }
        }
    }
}

$rq = $conn->prepare("SELECT r.*,s.service_name,CONCAT(r.request_first_name,' ',COALESCE(r.request_middle_name,''),' ',r.request_last_name) resident_name FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE r.request_id=?");
$rq->bind_param('i', $id);
$rq->execute();
$r = $rq->get_result()->fetch_assoc();
if (!$r) {
    http_response_code(404);
    die('Request not found.');
}
include '../includes/header.php';
?>
<div class="page-head">
  <div>
    <h1>Manage Request</h1>
    <div class="muted">Update status, schedule, signature, and remarks for a single request.</div>
  </div>
  <a class="btn btn-outline" href="<?= e($back) ?>"><i class="bi bi-arrow-left"></i> Back to Dashboard</a>
</div>
<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<div class="dashboard-two" style="grid-template-columns:.9fr 1.4fr">
  <section class="card">
    <h3>Request Details</h3>
    <div class="summary-list">
      <div class="summary-row"><span>Queue Number</span><strong><?= e(queue_number($r['request_id'])) ?></strong></div>
      <div class="summary-row"><span>Resident</span><strong><?= e(preg_replace('/\s+/', ' ', trim($r['resident_name']))) ?></strong></div>
      <div class="summary-row"><span>Contact</span><strong><?= e($r['request_contact'] ?: 'No contact') ?></strong></div>
      <div class="summary-row"><span>Email</span><strong><?= e($r['request_email'] ?: 'No email') ?></strong></div>
      <div class="summary-row"><span>Document</span><strong><?= e($r['service_name']) ?></strong></div>
      <div class="summary-row"><span>Purpose</span><strong><?= e($r['purpose']) ?></strong></div>
      <div class="summary-row"><span>Current Status</span><span class="badge badge-<?= strtolower($r['status']) ?>"><?= e($r['status']) ?></span></div>
    </div>
    <a class="btn btn-outline btn-small" style="width:100%;text-align:center;margin-top:14px" href="schedule.php?id=<?= $r['request_id'] ?>">Assign Schedule</a>
    <a class="btn btn-outline btn-small" style="width:100%;text-align:center;margin-top:8px" href="../request_slip.php?id=<?= $r['request_id'] ?>">Print Request Slip</a>
    <?php if (in_array($r['status'], ['Completed', 'Released'], true)): ?>
      <a class="btn btn-primary btn-small" style="width:100%;text-align:center;margin-top:8px" href="../generate_certificate.php?id=<?= $r['request_id'] ?>" target="_blank">
        <i class="bi bi-file-earmark-pdf"></i> Download Official Certificate (PDF)
      </a>
    <?php endif; ?>
  </section>
  <section class="card">
    <h3>Update Request</h3>
    <form method="post" id="manageForm">
      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="request_id" value="<?= $r['request_id'] ?>">
      <input type="hidden" name="back" value="<?= e($back) ?>">
      <div class="form-group">
        <label>Status</label>
        <select class="form-select" name="status">
          <?php foreach ($allowed as $x): ?>
            <option <?= $x === $r['status'] ? 'selected' : '' ?>><?= $x ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <br>
      <div class="form-grid">
        <div class="form-group">
          <label>Assigned Date</label>
          <input type="date" class="form-control" name="scheduled_date" value="<?= e($r['scheduled_date']) ?>">
        </div>
        <div class="form-group">
          <label>Assigned Time</label>
          <input type="time" class="form-control" name="scheduled_time" value="<?= e($r['scheduled_time']) ?>">
        </div>
        <div class="form-group full">
          <label>Personnel Signature <span class="muted">(Optional)</span></label>
          <div class="signature-pad-wrap">
            <canvas id="personnelPad" class="signature-pad"></canvas>
          </div>
          <input type="hidden" name="personnel_signature" id="personnelSignature" value="<?= e($r['personnel_signature']) ?>">
          <button type="button" class="btn btn-outline btn-small" style="margin-top:6px" id="clearPersonnel">Clear Signature</button>
          <?php if ($r['personnel_signature']): ?>
            <div class="small muted" style="margin-top:6px">Current signature:</div>
            <img src="<?= e($r['personnel_signature']) ?>" class="signature-preview" alt="Current personnel signature">
          <?php endif; ?>
        </div>
        <div class="form-group full">
          <label>Remarks</label>
          <textarea class="form-control" name="remarks" rows="3"><?= e($r['remarks']) ?></textarea>
        </div>
      </div>
      <br>
      <button class="btn btn-primary">Save Update</button>
    </form>
  </section>
</div>
<script src="../assets/js/signature.js"></script>
<script>
const personnelPad = setupSignaturePad(document.getElementById('personnelPad'), document.getElementById('personnelSignature'));
document.getElementById('clearPersonnel').onclick = () => { personnelPad.clear(); };
</script>
<?php include '../includes/footer.php'; ?>
