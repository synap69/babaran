<?php
require '../includes/config.php';require_admin();$pageTitle='Resident Management';$q=trim($_GET['q']??'');
$sql="SELECT r.*,
 (SELECT COUNT(*) FROM tblrequests req WHERE req.resident_id=r.resident_id AND req.status<>'Draft') AS total_requests,
 (SELECT COUNT(*) FROM tblrequests req WHERE req.resident_id=r.resident_id AND req.status='Pending') AS pending_requests,
 (SELECT COUNT(*) FROM tblrequests req WHERE req.resident_id=r.resident_id AND req.status='Completed') AS completed_requests
 FROM tblresidents r";
if($q!==''){ $esc=$conn->real_escape_string($q); $sql.=" WHERE CONCAT(r.first_name,' ',COALESCE(r.middle_name,''),' ',r.last_name) LIKE '%$esc%' OR r.contact_no LIKE '%$esc%' OR r.email LIKE '%$esc%' OR r.address LIKE '%$esc%'"; }
$sql.=' ORDER BY r.date_registered DESC';
$residents=$conn->query($sql);
$totalResidentsRow=$conn->query('SELECT COUNT(*) c FROM tblresidents')->fetch_assoc();$totalResidents=(int)($totalResidentsRow['c']??0);
include '../includes/header.php';
?>
<div class="dashboard-grid">
<div class="page-head"><div><h1>Resident Management</h1><div class="muted">All registered residents and their document request activity.</div></div><a class="btn btn-outline" href="dashboard.php"><i class="bi bi-arrow-left"></i> Back to Dashboard</a></div>
<div class="stat-grid" style="grid-template-columns:repeat(3,1fr)">
  <div class="stat-card"><div><small>Registered Residents</small><strong><?=$totalResidents?></strong></div><div class="stat-icon blue"><i class="bi bi-people"></i></div></div>
  <div class="stat-card"><div><small>Search Results</small><strong><?=$residents->num_rows?></strong></div><div class="stat-icon yellow"><i class="bi bi-search"></i></div></div>
  <div class="stat-card"><div><small>Filter</small><strong><?=$q!==''?'Active':'None'?></strong></div><div class="stat-icon purple"><i class="bi bi-funnel"></i></div></div>
</div>
<section class="card"><form method="get" class="form-grid" style="align-items:end"><div class="form-group full"><label>Search Resident (Name, Email, Contact, or Address)</label><input class="form-control" name="q" value="<?=e($q)?>" placeholder="Search residents..."></div><div class="form-group"><button class="btn btn-primary">Search</button> <?php if($q!==''):?><a class="btn btn-outline" href="residents.php">Clear</a><?php endif;?></div></form></section>
<section class="card"><div class="section-head"><h3>Registered Residents</h3><span class="muted"><?=$residents->num_rows?> record(s)</span></div>
<?php if(!$residents->num_rows):?><div class="empty muted">No residents found.</div><?php else:?>
<div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>Full Name</th><th>Contact / Email</th><th>Address</th><th>Date Registered</th><th>Requests</th><th>Action</th></tr></thead><tbody>
<?php $n=1;while($r=$residents->fetch_assoc()):$fullName=preg_replace('/\s+/',' ',trim($r['first_name'].' '.($r['middle_name']??'').' '.$r['last_name']));?>
<tr><td><?=$n++?></td><td><strong><?=e($fullName)?></strong></td><td><?=e($r['contact_no']?:'—')?><br><span class="small muted"><?=e($r['email']?:'—')?></span></td><td><?=e($r['address'])?></td><td><?=date('M d, Y',strtotime($r['date_registered']))?></td><td><strong><?=(int)$r['total_requests']?></strong><br><span class="small muted"><?=(int)$r['pending_requests']?> pending · <?=(int)$r['completed_requests']?> completed</span></td>
<td><details><summary class="btn btn-outline btn-small">View Requests</summary>
<div class="card" style="margin-top:8px;padding:12px">
<?php
$st=$conn->prepare("SELECT req.*,s.service_name FROM tblrequests req JOIN tblservices s ON s.service_id=req.service_id WHERE req.resident_id=? AND req.status<>'Draft' ORDER BY req.date_requested DESC LIMIT 10");
$st->bind_param('i',$r['resident_id']);$st->execute();$reqs=$st->get_result();
if(!$reqs->num_rows):?><div class="empty muted small">No document requests yet.</div><?php else:?>
<table class="table"><thead><tr><th>Queue No.</th><th>Document Type</th><th>Date Requested</th><th>Status</th></tr></thead><tbody>
<?php while($rq=$reqs->fetch_assoc()):?><tr><td><strong><?=e(queue_number($rq['request_id']))?></strong></td><td><?=e($rq['service_name'])?></td><td><?=date('M d, Y',strtotime($rq['date_requested']))?></td><td><span class="badge badge-<?=strtolower($rq['status'])?>"><?=e($rq['status'])?></span></td></tr><?php endwhile;?>
</tbody></table>
<?php endif; ?>
</div>
</details></td></tr>
<?php endwhile;?>
</tbody></table></div>
<?php endif;?>
</section>
</div>
<?php include '../includes/footer.php'; ?>
