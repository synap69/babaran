<?php
require '../includes/config.php';require_admin();require_role(['Punong Barangay']);$pageTitle='Audit Log';$q=trim($_GET['q']??'');$actorFilter=$_GET['actor']??'';$tableFilter=$_GET['table']??'';
$sql="SELECT * FROM tbl_audit_log WHERE 1=1";
if($q!==''){ $esc=$conn->real_escape_string($q); $sql.=" AND (actor_name LIKE '%$esc%' OR action LIKE '%$esc%' OR details LIKE '%$esc%')"; }
if($actorFilter!==''&&in_array($actorFilter,['admin','resident','system'],true)){ $sql.=" AND actor_type='".$conn->real_escape_string($actorFilter)."'"; }
if($tableFilter!==''){ $sql.=" AND target_table='".$conn->real_escape_string($tableFilter)."'"; }
$sql.=' ORDER BY created_at DESC LIMIT 300';
$logs=$conn->query($sql);
$tables=$conn->query("SELECT DISTINCT target_table FROM tbl_audit_log ORDER BY target_table");
$totalRow=$conn->query("SELECT COUNT(*) c FROM tbl_audit_log")->fetch_assoc();$total=(int)($totalRow['c']??0);
$todayRow=$conn->query("SELECT COUNT(*) c FROM tbl_audit_log WHERE DATE(created_at)=CURDATE()")->fetch_assoc();$today=(int)($todayRow['c']??0);
include '../includes/header.php';?>
<div class="dashboard-grid"><div class="page-head"><div><h1>Audit Log</h1><div class="muted">Permanent record of approvals, rejections, edits, and management actions.</div></div><a class="btn btn-outline" href="dashboard.php"><i class="bi bi-arrow-left"></i> Back to Dashboard</a></div>
<div class="stat-grid" style="margin-bottom:16px"><div class="stat-card"><div><small>Total Logged Actions</small><strong><?=$total?></strong><small>All recorded activity</small></div><div class="stat-icon blue"><i class="bi bi-list-check"></i></div></div><div class="stat-card"><div><small>Actions Today</small><strong><?=$today?></strong><small>Since midnight</small></div><div class="stat-icon green"><i class="bi bi-calendar-check"></i></div></div></div>
<section class="card"><form method="get" class="form-grid" style="align-items:end">
<div class="form-group full"><label>Search Actor, Action, or Details</label><input class="form-control" name="q" value="<?=e($q)?>" placeholder="Search audit log..."></div>
<div class="form-group"><label>Actor Type</label><select class="form-select" name="actor"><option value="">All</option><option value="admin" <?=$actorFilter==='admin'?'selected':''?>>Admin</option><option value="resident" <?=$actorFilter==='resident'?'selected':''?>>Resident</option><option value="system" <?=$actorFilter==='system'?'selected':''?>>System</option></select></div>
<div class="form-group"><label>Affected Table</label><select class="form-select" name="table"><option value="">All</option><?php while($t=$tables->fetch_assoc()):?><option value="<?=e($t['target_table'])?>" <?=$tableFilter===$t['target_table']?'selected':''?>><?=e($t['target_table'])?></option><?php endwhile;?></select></div>
<div class="form-group"><button class="btn btn-primary">Filter</button> <?php if($q!==''||$actorFilter!==''||$tableFilter!==''):?><a class="btn btn-outline" href="audit_log.php">Clear</a><?php endif;?></div>
</form></section>
<section class="card"><div class="section-head"><h3>Audit Records</h3><span class="muted">Latest 300 records</span></div>
<?php if(!$logs || !$logs->num_rows):?><div class="empty muted">No audit records found.</div><?php else:?>
<div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>Date</th><th>Time</th><th>Actor</th><th>Role</th><th>Action</th><th>Affected Record</th><th>Details</th><th>IP Address</th></tr></thead><tbody>
<?php $n=1;while($l=$logs->fetch_assoc()):?>
<tr><td><?=$n++?></td><td><?=date('M d, Y',strtotime($l['created_at']))?></td><td><?=date('h:i A',strtotime($l['created_at']))?></td><td><strong><?=e($l['actor_name'])?></strong></td><td><?=e(ucfirst($l['actor_type']))?></td><td><?=e($l['action'])?></td><td><?=e($l['target_table'])?><?=$l['target_id']?' #'.$l['target_id']:''?></td><td class="small muted"><?=e($l['details']?:'—')?></td><td><?=e($l['ip_address']?:'N/A')?></td></tr>
<?php endwhile;?>
</tbody></table></div>
<?php endif;?>
</section></div>
<?php include '../includes/footer.php';?>
