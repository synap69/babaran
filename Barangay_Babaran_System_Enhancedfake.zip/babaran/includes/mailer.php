<?php
require_once __DIR__ . '/mail_config.php';
require_once __DIR__ . '/../assets/libs/PHPMailer/src/Exception.php';
require_once __DIR__ . '/../assets/libs/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../assets/libs/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

/**
 * Sends a plain-text email via Gmail SMTP (settings in includes/mail_config.php).
 *
 * @return array{ok: bool, error: string} ok=true on success; on failure, ok=false
 *         and error contains a short reason (also logged to PHP's error log).
 */
function send_email(string $toEmail, string $toName, string $subject, string $body): array
{
    if (SMTP_USERNAME === '' || SMTP_PASSWORD === '') {
        $msg = 'Email is not configured yet: set SMTP_USERNAME and SMTP_PASSWORD in includes/mail_config.php.';
        error_log('[mailer] ' . $msg);
        return ['ok' => false, 'error' => $msg];
    }

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_SECURE === 'ssl' ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;

        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($toEmail, $toName);

        $mail->isHTML(false);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();
        return ['ok' => true, 'error' => ''];
    } catch (PHPMailerException $e) {
        $reason = $mail->ErrorInfo ?: $e->getMessage();
        error_log('[mailer] Send failed: ' . $reason);
        return ['ok' => false, 'error' => $reason];
    }
}
