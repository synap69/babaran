<?php
// Secure session configuration and inactivity timeout (30 minutes).
define('APP_ENV', 'local');
$sessionLifetime = 1800;
if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');
    $secureCookie = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secureCookie,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

if (isset($_SESSION['last_activity']) && (time() - (int)$_SESSION['last_activity']) > $sessionLifetime) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'] ?? '', (bool)$params['secure'], (bool)$params['httponly']);
    }
    session_destroy();
    session_start();
}
$_SESSION['last_activity'] = time();

// Prevent authenticated pages from being restored from browser cache after logout.
if (isset($_SESSION['resident_id']) || isset($_SESSION['admin_id'])) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
}

$host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'babaran_db';

$conn = new mysqli($host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die('Database connection failed: ' . htmlspecialchars($conn->connect_error));
}
$conn->set_charset('utf8mb4');

// Database schema is managed by database.sql.
// Do not run ALTER TABLE / CREATE TABLE migrations on every page load.
// This keeps the application idempotent and prevents duplicate-key / duplicate-FK errors.

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function verify_csrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf_token'] ?? '';
        if (!$token || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
            http_response_code(419);
            exit('Security token expired. Please go back and try again.');
        }
    }
}
function login_session($type, $id, $name = '', $role = null) {
    session_regenerate_id(true);
    $_SESSION['last_activity'] = time();
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    if ($type === 'resident') {
        $_SESSION['resident_id'] = (int)$id;
        $_SESSION['first_name'] = $name;
    } else {
        $_SESSION['admin_id'] = (int)$id;
        $_SESSION['admin_name'] = $name;
        $_SESSION['admin_role'] = $role ?: 'Secretary';
    }
}
function require_resident() {
    if (!isset($_SESSION['resident_id'])) { header('Location: login.php'); exit; }
    $_SESSION['last_activity'] = time();
}
function require_admin() {
    if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
    $_SESSION['last_activity'] = time();
}

// Restricts a page to specific admin roles. Call after require_admin().
// Example: require_role(['Punong Barangay']); // only the Punong Barangay can access
function require_role($allowedRoles) {
    $role = $_SESSION['admin_role'] ?? '';
    if (!in_array($role, $allowedRoles, true)) {
        http_response_code(403);
        include __DIR__ . '/../includes/header.php';
        echo '<div class="dashboard-grid"><section class="card"><h2>Access Restricted</h2><p class="muted">This page is only available to: ' . e(implode(', ', $allowedRoles)) . '. Your account role is: ' . e($role) . '.</p><a class="btn btn-outline" href="dashboard.php"><i class="bi bi-arrow-left"></i> Back to Dashboard</a></section></div>';
        include __DIR__ . '/../includes/footer.php';
        exit;
    }
}

function resident_profile_photo_file($residentId) {
    $residentId = (int)$residentId;
    if ($residentId <= 0) return null;
    $dir = dirname(__DIR__) . '/uploads/profile';
    foreach (glob($dir . '/resident_' . $residentId . '_*') ?: [] as $file) {
        if (is_file($file)) return $file;
    }
    return null;
}
function resident_profile_photo_url($residentId, $basePath = '') {
    $file = resident_profile_photo_file($residentId);
    if (!$file) return null;
    return $basePath . 'uploads/profile/' . rawurlencode(basename($file)) . '?v=' . filemtime($file);
}

function queue_number($request_id) { return 'BB-' . str_pad((string)$request_id, 5, '0', STR_PAD_LEFT); }

// Records an entry in the audit trail. Call this right after any create/update/
// approve/reject/delete action so there is a permanent record of who did what.
// actor_type: 'admin' | 'resident' | 'system'
// action: short label e.g. 'Approved Request', 'Rejected Request', 'Assigned Schedule'
// target_table / target_id: which record was affected (e.g. 'tblrequests', 15)
// details: optional human-readable extra info (e.g. old status -> new status)
function log_audit($conn, $actorType, $actorId, $actorName, $action, $targetTable, $targetId, $details = null) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? null;
    $st = $conn->prepare("INSERT INTO tbl_audit_log(actor_type,actor_id,actor_name,action,target_table,target_id,details,ip_address) VALUES(?,?,?,?,?,?,?,?)");
    $st->bind_param('sisssiss', $actorType, $actorId, $actorName, $action, $targetTable, $targetId, $details, $ip);
    return $st->execute();
}
?>
