<?php
$basePath = (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? '../' : '';
$loggedIn = isset($_SESSION['resident_id']) || isset($_SESSION['admin_id']);
$isAdmin = isset($_SESSION['admin_id']);
$isResident = isset($_SESSION['resident_id']);

$navPendingCount = 0; $navPriorityCount = 0;
if ($isAdmin && isset($conn)) {
    $navPendingCount = (int)($conn->query("SELECT COUNT(*) c FROM tblrequests WHERE status='Pending'")->fetch_assoc()['c'] ?? 0);
    $navPriorityCount = (int)($conn->query("SELECT COUNT(*) c FROM tblrequests WHERE status='Pending' AND date_requested < DATE_SUB(NOW(), INTERVAL 3 DAY)")->fetch_assoc()['c'] ?? 0);
} elseif ($isResident && isset($conn)) {
    $rid = (int)($_SESSION['resident_id'] ?? 0);
    $st = $conn->prepare("SELECT COUNT(*) c FROM tblrequests WHERE resident_id=? AND status='Pending'");
    $st->bind_param('i', $rid); $st->execute();
    $navPendingCount = (int)($st->get_result()->fetch_assoc()['c'] ?? 0);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? e($pageTitle).' | ' : '' ?>Barangay Babaran Document Request and Scheduling System</title>
<link rel="stylesheet" href="<?= $basePath ?>assets/css/style.css?v=<?= @filemtime(__DIR__.'/../assets/css/style.css') ?: time() ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="<?= $loggedIn ? 'app-body' : 'public-body' ?>">
<?php if($loggedIn): ?>
<aside class="sidebar">
  <a class="side-brand" href="<?= $basePath ?><?= $isAdmin ? 'admin/dashboard.php' : 'dashboard.php' ?>">
    <img src="<?= $basePath ?>assets/img/barangay-babaran-logo.png" alt="Barangay Babaran Logo">
    <strong>BARANGAY BABARAN</strong><span>Document Request and<br>Scheduling System</span>
  </a>
  <nav class="side-nav">
    <?php if($isAdmin): $isPB = ($_SESSION['admin_role'] ?? '') === 'Punong Barangay'; $reqStatuses=['Pending','Scheduled','Completed','Released']; $requestsOpen=in_array($_GET['status'] ?? '',$reqStatuses,true); ?>
      <span class="side-nav-label">Menu</span>
      <a class="<?= ($pageTitle==='Personnel Dashboard' && !isset($_GET['status']))?'active':'' ?>" href="<?= $basePath ?>admin/dashboard.php"><i class="bi bi-grid-1x2"></i> <span>Dashboard</span></a>
      <div class="side-nav-group">
        <a href="<?= $basePath ?>admin/dashboard.php?status=Pending" class="side-nav-toggle" aria-expanded="<?= $requestsOpen?'true':'false' ?>" aria-controls="admin-requests-sub" data-target="admin-requests-sub"><i class="bi bi-file-earmark-text"></i> <span>Requests</span><?php if($navPendingCount>0): ?><span class="nav-badge"><?=$navPendingCount?></span><?php endif; ?><?php if($navPriorityCount>0): ?><span class="nav-priority-pill">Priority</span><?php endif; ?><i class="bi bi-chevron-down side-nav-chevron<?= $requestsOpen?' rotated':'' ?>" role="button" tabindex="0" aria-label="Expand Requests"></i></a>
        <div class="side-nav-sub <?= $requestsOpen?'open':'' ?>" id="admin-requests-sub">
          <a class="<?= (($_GET['status'] ?? '')==='Pending')?'active':'' ?>" href="<?= $basePath ?>admin/dashboard.php?status=Pending"><i class="bi bi-hourglass-split"></i> <span>Pending Requests</span></a>
          <a class="<?= (($_GET['status'] ?? '')==='Scheduled')?'active':'' ?>" href="<?= $basePath ?>admin/dashboard.php?status=Scheduled"><i class="bi bi-calendar3"></i> <span>Scheduled Requests</span></a>
          <a class="<?= (($_GET['status'] ?? '')==='Completed')?'active':'' ?>" href="<?= $basePath ?>admin/dashboard.php?status=Completed"><i class="bi bi-check-circle"></i> <span>Completed Requests</span></a>
          <a class="<?= (($_GET['status'] ?? '')==='Released')?'active':'' ?>" href="<?= $basePath ?>admin/dashboard.php?status=Released"><i class="bi bi-file-earmark-check"></i> <span>Released Documents</span></a>
        </div>
      </div>
      <div class="side-nav-group">
        <span class="side-nav-label">General</span>
        <a class="<?= $pageTitle==='Reports & Analysis'?'active':'' ?>" href="<?= $basePath ?>admin/reports.php"><i class="bi bi-bar-chart"></i> <span>Reports</span></a>
        <?php if($isPB): ?>
        <a class="<?= $pageTitle==='Audit Log'?'active':'' ?>" href="<?= $basePath ?>admin/audit_log.php"><i class="bi bi-list-check"></i> <span>Audit Log</span></a>
        <a class="<?= in_array($pageTitle,['Document Management'],true)?'active':'' ?>" href="<?= $basePath ?>admin/documents.php"><i class="bi bi-file-earmark-text"></i> <span>Documents</span></a>
        <?php endif; ?>
      </div>
      <div class="side-nav-group">
        <span class="side-nav-label">Administration</span>
        <?php if($isPB): ?>
        <a class="<?= $pageTitle==='Personnel Accounts'?'active':'' ?>" href="<?= $basePath ?>admin/accounts.php"><i class="bi bi-person-badge"></i> <span>Personnel Accounts</span></a>
        <?php endif; ?>
        <a class="<?= in_array($pageTitle,['Resident Management','Resident Profile'],true)?'active':'' ?>" href="<?= $basePath ?>admin/residents.php"><i class="bi bi-people"></i> <span>Users</span></a>
      </div>
      <a class="logout-link" href="<?= $basePath ?>admin/logout.php"><i class="bi bi-box-arrow-right"></i> <span>Logout</span></a>
    <?php else: $reqStatuses=['Pending','Scheduled','Completed','Released']; $requestsOpen=in_array($_GET['status'] ?? '',$reqStatuses,true); ?>
      <span class="side-nav-label">Menu</span>
      <a class="<?= $pageTitle==='Resident Dashboard'?'active':'' ?>" href="<?= $basePath ?>dashboard.php"><i class="bi bi-grid-1x2"></i> <span>Dashboard</span></a>
      <a class="<?= in_array($pageTitle,['New Document Request','Edit Document Request'],true)?'active':'' ?>" href="<?= $basePath ?>new_request.php"><i class="bi bi-file-earmark-plus"></i> <span>New Document Request</span></a>
      <div class="side-nav-group">
        <a href="<?= $basePath ?>requests.php?status=Pending" class="side-nav-toggle" aria-expanded="<?= $requestsOpen?'true':'false' ?>" aria-controls="resident-requests-sub" data-target="resident-requests-sub"><i class="bi bi-file-earmark-text"></i> <span>My Requests</span><?php if($navPendingCount>0): ?><span class="nav-badge"><?=$navPendingCount?></span><?php endif; ?><i class="bi bi-chevron-down side-nav-chevron<?= $requestsOpen?' rotated':'' ?>" role="button" tabindex="0" aria-label="Expand My Requests"></i></a>
        <div class="side-nav-sub <?= $requestsOpen?'open':'' ?>" id="resident-requests-sub">
          <a class="<?= (($_GET['status'] ?? '')==='Pending')?'active':'' ?>" href="<?= $basePath ?>requests.php?status=Pending"><i class="bi bi-hourglass-split"></i> <span>Pending Requests</span></a>
          <a class="<?= (($_GET['status'] ?? '')==='Scheduled')?'active':'' ?>" href="<?= $basePath ?>requests.php?status=Scheduled"><i class="bi bi-calendar3"></i> <span>Scheduled Requests</span></a>
          <a class="<?= (($_GET['status'] ?? '')==='Completed')?'active':'' ?>" href="<?= $basePath ?>requests.php?status=Completed"><i class="bi bi-check-circle"></i> <span>Completed Requests</span></a>
          <a class="<?= (($_GET['status'] ?? '')==='Released')?'active':'' ?>" href="<?= $basePath ?>requests.php?status=Released"><i class="bi bi-file-earmark-check"></i> <span>Released Documents</span></a>
        </div>
      </div>
      <div class="side-nav-group">
        <span class="side-nav-label">General</span>
        <a class="<?= $pageTitle==='Resident Profile'?'active':'' ?>" href="<?= $basePath ?>profile.php"><i class="bi bi-gear"></i> <span>Profile & Settings</span></a>
      </div>
      <a class="logout-link" href="<?= $basePath ?>logout.php"><i class="bi bi-box-arrow-right"></i> <span>Logout</span></a>
    <?php endif; ?>
  </nav>
</aside>
<?php $topResidentPhoto = (!$isAdmin && isset($_SESSION['resident_id'])) ? resident_profile_photo_url((int)$_SESSION['resident_id'], $basePath) : null; ?>
<header class="app-topbar"><div class="top-title"><strong><?= e($pageTitle ?? 'Dashboard') ?></strong><span><?= $isAdmin ? 'Barangay Personnel Management' : 'Resident Service Portal' ?></span></div><div class="top-user"><?php if ($topResidentPhoto): ?><img class="avatar avatar-photo" src="<?=e($topResidentPhoto)?>" alt="Profile photo"><?php else: ?><span class="avatar"><i class="bi bi-person"></i></span><?php endif; ?><span><strong><?= e($isAdmin ? $_SESSION['admin_name'] : $_SESSION['first_name']) ?></strong><small><?= $isAdmin ? e($_SESSION['admin_role'] ?? 'Personnel') : 'Resident' ?></small></span><?php if($isAdmin): ?><a class="btn btn-outline btn-small" href="<?= $basePath ?>admin/logout.php" title="Logout"><i class="bi bi-box-arrow-right"></i> Logout</a><?php else: ?><i class="bi bi-chevron-down" style="font-size:11px;color:var(--muted)"></i><?php endif; ?></div></header>
<main class="app-main">
<?php else: ?>
<header class="public-topbar"><div class="public-wrap"><a class="public-brand" href="<?= $basePath ?>index.php"><img src="<?= $basePath ?>assets/img/barangay-babaran-logo.png" alt="Barangay Babaran"><span><strong>BARANGAY BABARAN</strong><small>Document Request and Scheduling System</small></span></a></div></header>
<main class="public-main">
<?php endif; ?>
