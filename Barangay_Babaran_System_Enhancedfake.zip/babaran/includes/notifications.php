<?php
/**
 * Email notification helpers for request status changes.
 * Uses existing PHPMailer setup in includes/mailer.php.
 */
require_once __DIR__ . '/mailer.php';

/**
 * Send status-change email to resident if they have a valid email.
 *
 * @param mysqli $conn
 * @param int    $requestId
 * @param string $newStatus  Scheduled|Processing|Completed|Released|Rejected
 * @return array{ok:bool,error:string,skipped:bool}
 */
function notify_request_status_change(mysqli $conn, int $requestId, string $newStatus): array
{
    $allowed = ['Scheduled', 'Processing', 'Completed', 'Released', 'Rejected'];
    if (!in_array($newStatus, $allowed, true)) {
        return ['ok' => false, 'error' => 'Status not eligible for notification.', 'skipped' => true];
    }

    $st = $conn->prepare("
        SELECT r.request_id, r.request_first_name, r.request_middle_name, r.request_last_name,
               r.request_email, r.scheduled_date, r.scheduled_time, r.remarks,
               s.service_name
        FROM tblrequests r
        JOIN tblservices s ON s.service_id = r.service_id
        WHERE r.request_id = ?
        LIMIT 1
    ");
    $st->bind_param('i', $requestId);
    $st->execute();
    $row = $st->get_result()->fetch_assoc();
    $st->close();

    if (!$row) {
        return ['ok' => false, 'error' => 'Request not found.', 'skipped' => true];
    }

    $email = trim((string)($row['request_email'] ?? ''));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'error' => 'No valid resident email.', 'skipped' => true];
    }

    $fullName = trim(preg_replace('/\s+/', ' ',
        ($row['request_first_name'] ?? '') . ' ' .
        ($row['request_middle_name'] ?? '') . ' ' .
        ($row['request_last_name'] ?? '')
    ));
    $queueNo   = queue_number($row['request_id']);
    $docType   = $row['service_name'] ?? 'Document';
    $schedText = '';
    if (!empty($row['scheduled_date']) && !empty($row['scheduled_time'])) {
        $schedText = date('F d, Y', strtotime($row['scheduled_date'])) . ' at ' .
                     date('h:i A', strtotime($row['scheduled_time']));
    }

    $statusMessages = [
        'Scheduled'  => 'Your document request has been scheduled. Please come to the Barangay Hall on the assigned date and time.',
        'Processing' => 'Your document request is now being processed by barangay personnel.',
        'Completed'  => 'Your document is ready. You may claim it at the Barangay Hall during office hours.',
        'Released'   => 'Your document has been released. Thank you for using the Barangay Babaran Document Request System.',
        'Rejected'   => 'Your document request was not approved. Please see the remarks below or visit the Barangay Hall for more information.',
    ];

    $bodyLines = [
        'Dear ' . $fullName . ',',
        '',
        $statusMessages[$newStatus] ?? ('Your request status is now: ' . $newStatus),
        '',
        'Reference / Queue Number : ' . $queueNo,
        'Document Type            : ' . $docType,
        'New Status               : ' . $newStatus,
    ];
    if ($schedText !== '') {
        $bodyLines[] = 'Scheduled Date & Time    : ' . $schedText;
    }
    if (!empty($row['remarks']) && $newStatus === 'Rejected') {
        $bodyLines[] = 'Remarks                  : ' . $row['remarks'];
    }
    $bodyLines[] = '';
    $bodyLines[] = 'You may log in to the system anytime to track your request.';
    $bodyLines[] = '';
    $bodyLines[] = 'Barangay Babaran';
    $bodyLines[] = 'Echague, Isabela';
    $bodyLines[] = 'This is an automated message. Please do not reply.';

    $subject = '[Barangay Babaran] Request ' . $queueNo . ' — ' . $newStatus;
    $body    = implode("\n", $bodyLines);

    $result = send_email($email, $fullName, $subject, $body);
    return [
        'ok'      => $result['ok'],
        'error'   => $result['error'] ?? '',
        'skipped' => false,
    ];
}
