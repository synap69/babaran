<?php
/**
 * SMTP settings for outgoing email (used by forgot_password.php via PHPMailer).
 *
 * SETUP STEPS (Gmail):
 * 1. Turn on 2-Step Verification on the Gmail account you want to send from:
 *    https://myaccount.google.com/security
 * 2. Create an "App Password":
 *    https://myaccount.google.com/apppasswords
 *    (Choose "Mail" as the app. Google gives you a 16-character password.)
 * 3. Paste that Gmail address and 16-character App Password below.
 *    Do NOT use your normal Gmail login password — it will not work.
 * 4. Do not commit/share this file publicly once filled in.
 */

define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);                 // 587 = TLS (recommended), 465 = SSL
define('SMTP_SECURE', 'tls');             // 'tls' for port 587, 'ssl' for port 465
define('SMTP_USERNAME', '');              // <-- put your full Gmail address here, e.g. 'yourbarangay@gmail.com'
define('SMTP_PASSWORD', '');              // <-- put your 16-character Gmail App Password here (no spaces)
define('SMTP_FROM_EMAIL', SMTP_USERNAME); // the "from" address shown to recipients
define('SMTP_FROM_NAME', 'Barangay Babaran');
