</main>
<?php if(!isset($_SESSION['resident_id']) && !isset($_SESSION['admin_id'])): ?><footer class="public-footer">© <?=date('Y')?> Barangay Babaran, Echague, Isabela. All rights reserved.</footer><?php endif; ?>
<script src="<?= $basePath ?? '' ?>assets/js/password-toggle.js?v=<?= @filemtime(__DIR__.'/../assets/js/password-toggle.js') ?: time() ?>"></script>
<script src="<?= $basePath ?? '' ?>assets/js/sidebar-toggle.js?v=<?= @filemtime(__DIR__.'/../assets/js/sidebar-toggle.js') ?: time() ?>"></script>
</body></html>
