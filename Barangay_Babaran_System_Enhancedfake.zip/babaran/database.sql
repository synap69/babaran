CREATE DATABASE IF NOT EXISTS babaran_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE babaran_db;

DROP TRIGGER IF EXISTS trg_requests_schedule_after_insert;
DROP TRIGGER IF EXISTS trg_requests_schedule_after_update;
DROP TABLE IF EXISTS tbl_audit_log;
DROP TABLE IF EXISTS tbl_password_resets;
DROP TABLE IF EXISTS tblschedules;
DROP TABLE IF EXISTS tbl_login_history;
DROP TABLE IF EXISTS tblrequests;
DROP TABLE IF EXISTS tblservices;
DROP TABLE IF EXISTS tblresidents;
DROP TABLE IF EXISTS tbladmin;

CREATE TABLE tbladmin (
  admin_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  role ENUM('Punong Barangay','Secretary') NOT NULL DEFAULT 'Secretary',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  password_plain VARCHAR(255) NULL COMMENT 'DEMO ONLY: original personnel password; do not use in production',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE tblresidents (
  resident_id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(50) NOT NULL,
  middle_name VARCHAR(50) NULL,
  last_name VARCHAR(50) NOT NULL,
  age TINYINT UNSIGNED NULL,
  address VARCHAR(200) NOT NULL,
  contact_no VARCHAR(30) NULL UNIQUE,
  email VARCHAR(120) NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  password_plain VARCHAR(255) NULL COMMENT 'DEMO ONLY: original password; do not use in production',
  date_registered DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE tblservices (
  service_id INT AUTO_INCREMENT PRIMARY KEY,
  service_name VARCHAR(120) NOT NULL UNIQUE,
  description VARCHAR(255) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE tblrequests (
  request_id INT AUTO_INCREMENT PRIMARY KEY,
  resident_id INT NOT NULL,
  service_id INT NOT NULL,
  request_first_name VARCHAR(50) NOT NULL,
  request_middle_name VARCHAR(50) NULL,
  request_last_name VARCHAR(50) NOT NULL,
  request_address VARCHAR(200) NOT NULL,
  request_contact VARCHAR(30) NULL,
  request_email VARCHAR(120) NULL,
  purpose VARCHAR(255) NOT NULL,
  preferred_date DATE NOT NULL,
  preferred_time TIME NOT NULL,
  scheduled_date DATE NULL,
  scheduled_time TIME NULL,
  status ENUM('Draft','Pending','Scheduled','Processing','Completed','Released','Rejected') NOT NULL DEFAULT 'Draft',
  remarks VARCHAR(500) NULL,
  resident_signature LONGTEXT NULL,
  resident_signed_at DATETIME NULL,
  personnel_signature LONGTEXT NULL,
  personnel_signed_at DATETIME NULL,
  date_requested DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_requests_resident FOREIGN KEY (resident_id) REFERENCES tblresidents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_requests_service FOREIGN KEY (service_id) REFERENCES tblservices(service_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX idx_requests_status(status),
  INDEX idx_requests_schedule(scheduled_date, scheduled_time)
 ) ENGINE=InnoDB;

CREATE TABLE tblschedules (
  schedule_id INT AUTO_INCREMENT PRIMARY KEY,
  request_id INT NOT NULL UNIQUE,
  scheduled_date DATE NOT NULL,
  scheduled_time TIME NOT NULL,
  status ENUM('Scheduled','Completed','Cancelled') NOT NULL DEFAULT 'Scheduled',
  remarks VARCHAR(500) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_schedules_request FOREIGN KEY (request_id) REFERENCES tblrequests(request_id) ON DELETE CASCADE ON UPDATE CASCADE,
  INDEX idx_schedules_date_time(scheduled_date, scheduled_time)
) ENGINE=InnoDB;

CREATE TABLE tbl_login_history (
  login_history_id INT AUTO_INCREMENT PRIMARY KEY,
  actor_type ENUM('resident','admin') NOT NULL DEFAULT 'resident',
  resident_id INT NULL,
  admin_id INT NULL,
  login_identifier VARCHAR(120) NOT NULL,
  login_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ip_address VARCHAR(45) NULL,
  user_agent VARCHAR(255) NULL,
  CONSTRAINT fk_login_history_resident FOREIGN KEY (resident_id) REFERENCES tblresidents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_login_history_admin FOREIGN KEY (admin_id) REFERENCES tbladmin(admin_id) ON DELETE CASCADE ON UPDATE CASCADE,
  INDEX idx_login_history_resident(resident_id),
  INDEX idx_login_history_login_at(login_at)
) ENGINE=InnoDB;

-- Keep the dedicated schedule table synchronized with request scheduling fields.
DELIMITER $$
CREATE TRIGGER trg_requests_schedule_after_insert
AFTER INSERT ON tblrequests
FOR EACH ROW
BEGIN
  IF NEW.scheduled_date IS NOT NULL AND NEW.scheduled_time IS NOT NULL THEN
    INSERT INTO tblschedules(request_id,scheduled_date,scheduled_time,status,remarks)
    VALUES(NEW.request_id,NEW.scheduled_date,NEW.scheduled_time,
      CASE WHEN NEW.status='Completed' THEN 'Completed' ELSE 'Scheduled' END,NEW.remarks);
  END IF;
END$$
CREATE TRIGGER trg_requests_schedule_after_update
AFTER UPDATE ON tblrequests
FOR EACH ROW
BEGIN
  IF NEW.scheduled_date IS NULL OR NEW.scheduled_time IS NULL THEN
    DELETE FROM tblschedules WHERE request_id=NEW.request_id;
  ELSE
    INSERT INTO tblschedules(request_id,scheduled_date,scheduled_time,status,remarks)
    VALUES(NEW.request_id,NEW.scheduled_date,NEW.scheduled_time,
      CASE WHEN NEW.status IN ('Completed','Released') THEN 'Completed' WHEN NEW.status='Rejected' THEN 'Cancelled' ELSE 'Scheduled' END,NEW.remarks)
    ON DUPLICATE KEY UPDATE scheduled_date=VALUES(scheduled_date),scheduled_time=VALUES(scheduled_time),status=VALUES(status),remarks=VALUES(remarks);
  END IF;
END$$
DELIMITER ;

CREATE TABLE tbl_password_resets (
  reset_id INT AUTO_INCREMENT PRIMARY KEY,
  resident_id INT NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_reset_resident FOREIGN KEY (resident_id) REFERENCES tblresidents(resident_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE tbl_audit_log (
  audit_id INT AUTO_INCREMENT PRIMARY KEY,
  actor_type ENUM('admin','resident','system') NOT NULL DEFAULT 'admin',
  actor_id INT NULL,
  actor_name VARCHAR(150) NOT NULL,
  action VARCHAR(100) NOT NULL,
  target_table VARCHAR(60) NOT NULL,
  target_id INT NULL,
  details VARCHAR(500) NULL,
  ip_address VARCHAR(45) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_target (target_table, target_id),
  INDEX idx_audit_created (created_at)
) ENGINE=InnoDB;

INSERT INTO tbladmin (username,password,full_name,role,password_plain) VALUES
('admin','$2y$12$6UsROVyZYgH0m/E/rSBLs.NSf/7tuW3V0LS9M7g5JIPrmaWkSUH3i','Barangay Administrator','Punong Barangay','admin1234'),
('secretary','$2y$12$6UsROVyZYgH0m/E/rSBLs.NSf/7tuW3V0LS9M7g5JIPrmaWkSUH3i','Barangay Secretary','Secretary','admin1234');

INSERT INTO tblservices (service_name,description) VALUES
('Barangay Clearance','Certification issued by the barangay for official and personal purposes.'),
('Certificate of Indigency','Certification for qualified residents who need proof of indigency.'),
('Certificate of Residency','Proof that the requester is a resident of Barangay Babaran.'),
('Business Permit Endorsement','Barangay endorsement related to business permit processing.'),
('Cedula (Community Tax Certificate)','Required for notarial acts, court appearances, and many government transactions. Issued yearly.'),
('Certificate of Good Moral Character','Verifies good standing in the community for job, school, and visa applications.'),
('Sangguniang Kabataan (SK) Certification','Youth-related certifications for residents aged 15-30, issued through the SK Chairperson.'),
('Other Special Permit','Other barangay-issued permit subject to local requirements.');

-- No payment/fee/QR/GCash tables or fields are included in this database.
