// Collapsible sidebar nav groups (e.g. "Requests" -> Pending/Scheduled/Completed/Released).
// Event delegation so it works for every .side-nav-toggle, present or future, admin or resident.
//
// Clicking (or pressing Enter/Space on) the chevron only expands/collapses the sub-list,
// it does not navigate. The chevron rotates: pointing down when closed, up when open
// (driven directly here via a "rotated" class, and set server-side on page load too).
// Clicking the rest of the "Requests" label navigates to Pending Requests as normal,
// and the sub-list + chevron auto-open on that page load (server-side, via $requestsOpen).
function toggleSideNavGroup(chevron) {
  var toggle = chevron.closest('.side-nav-toggle');
  if (!toggle) return;
  var targetId = toggle.getAttribute('data-target');
  var sub = targetId ? document.getElementById(targetId) : null;
  if (!sub) return;
  var isOpen = toggle.getAttribute('aria-expanded') === 'true';
  var willOpen = !isOpen;
  toggle.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
  sub.classList.toggle('open', willOpen);
  chevron.classList.toggle('rotated', willOpen);
}

document.addEventListener('click', function (e) {
  var chevron = e.target.closest('.side-nav-chevron');
  if (!chevron) return;
  e.preventDefault();
  e.stopPropagation();
  toggleSideNavGroup(chevron);
});

document.addEventListener('keydown', function (e) {
  if (e.key !== 'Enter' && e.key !== ' ' && e.key !== 'Spacebar') return;
  var chevron = e.target.closest && e.target.closest('.side-nav-chevron');
  if (!chevron) return;
  e.preventDefault();
  toggleSideNavGroup(chevron);
});
