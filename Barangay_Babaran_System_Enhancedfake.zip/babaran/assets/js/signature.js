function setupSignaturePad(canvas, hidden){
  const ctx=canvas.getContext('2d'); let drawing=false;
  function resize(){const saved=hidden.value||null;const ratio=Math.max(window.devicePixelRatio||1,1);const rect=canvas.getBoundingClientRect();canvas.width=rect.width*ratio;canvas.height=rect.height*ratio;ctx.scale(ratio,ratio);ctx.lineWidth=2;ctx.lineCap='round';ctx.strokeStyle='#111';if(saved){const img=new Image();img.onload=function(){ctx.drawImage(img,0,0,rect.width,rect.height);};img.src=saved;}}
  resize(); window.addEventListener('resize',resize);
  function pos(e){const r=canvas.getBoundingClientRect();const p=e.touches?e.touches[0]:e;return {x:p.clientX-r.left,y:p.clientY-r.top};}
  function start(e){drawing=true;const p=pos(e);ctx.beginPath();ctx.moveTo(p.x,p.y);e.preventDefault();}
  function move(e){if(!drawing)return;const p=pos(e);ctx.lineTo(p.x,p.y);ctx.stroke();e.preventDefault();}
  function end(){if(!drawing)return;drawing=false;hidden.value=canvas.toDataURL('image/png');}
  canvas.addEventListener('mousedown',start);canvas.addEventListener('mousemove',move);canvas.addEventListener('mouseup',end);canvas.addEventListener('mouseleave',end);
  canvas.addEventListener('touchstart',start,{passive:false});canvas.addEventListener('touchmove',move,{passive:false});canvas.addEventListener('touchend',end);
  function clear(){ctx.clearRect(0,0,canvas.clientWidth,canvas.clientHeight);hidden.value='';} return {canvas,ctx,hidden,resize,clear};
}
function clearPad(pad, hiddenId){const rect=pad.canvas.getBoundingClientRect();pad.ctx.clearRect(0,0,rect.width,rect.height);document.getElementById(hiddenId).value='';}
