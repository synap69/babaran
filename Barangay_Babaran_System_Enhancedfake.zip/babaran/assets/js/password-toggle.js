// Site-wide password show/hide toggle.
// Works for any button with class="password-toggle" and data-toggle-target="<input id>".
// Uses event delegation so it only needs to be loaded once (see includes/footer.php)
// and automatically applies to every password field across the app, present or future.
document.addEventListener('click', function (e) {
  var btn = e.target.closest('.password-toggle');
  if (!btn) return;

  var input = document.getElementById(btn.getAttribute('data-toggle-target'));
  var icon = btn.querySelector('.password-eye-icon');
  if (!input || !icon) return;

  var willShow = input.type === 'password';
  input.type = willShow ? 'text' : 'password';

  icon.classList.toggle('bi-eye', !willShow);
  icon.classList.toggle('bi-eye-slash', willShow);

  btn.setAttribute('aria-label', willShow ? 'Hide password' : 'Show password');
  btn.setAttribute('title', willShow ? 'Hide password' : 'Show password');
});
