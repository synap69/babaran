<?php
require 'includes/config.php';
require 'includes/mailer.php';
$pageTitle='Forgot Password'; $error=''; $success=''; $resetMode=false; $token=$_GET['token']??'';
if($token){
  $hash=hash('sha256',$token); $st=$conn->prepare("SELECT pr.reset_id,pr.resident_id FROM tbl_password_resets pr WHERE pr.token_hash=? AND pr.used_at IS NULL AND pr.expires_at>NOW() LIMIT 1");$st->bind_param('s',$hash);$st->execute();$reset=$st->get_result()->fetch_assoc();$resetMode=(bool)$reset;if(!$reset)$error='This password reset link is invalid or has expired. Please request a new one.';
}
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf(); $action=$_POST['action']??'';
 if($action==='request'){
  $identifier=trim($_POST['identifier']??'');
  if($identifier===''){$error='Please enter your registered email address.';} else {
   $st=$conn->prepare("SELECT resident_id,email,first_name FROM tblresidents WHERE email=? LIMIT 1");$st->bind_param('s',$identifier);$st->execute();$row=$st->get_result()->fetch_assoc();
   // Always return the same public response to avoid account enumeration.
   $success='If an account is registered with that email, a password reset link has been sent. The link expires in 15 minutes.';
   if($row && filter_var($row['email'],FILTER_VALIDATE_EMAIL)){
    $raw=bin2hex(random_bytes(32));$hash=hash('sha256',$raw);$exp=date('Y-m-d H:i:s',time()+900);
    $conn->query('DELETE FROM tbl_password_resets WHERE resident_id='.(int)$row['resident_id'].' OR expires_at<NOW()');
    $ins=$conn->prepare('INSERT INTO tbl_password_resets(resident_id,token_hash,expires_at) VALUES(?,?,?)');$ins->bind_param('iss',$row['resident_id'],$hash,$exp);$ins->execute();
    $base=(isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'?'https':'http').'://'.($_SERVER['HTTP_HOST']??'localhost').rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
    $link=$base.'/forgot_password.php?token='.urlencode($raw);
    $subject='Barangay Babaran Password Reset';$body="Good day {$row['first_name']},\n\nUse this link to reset your Barangay Babaran account password:\n{$link}\n\nThis link expires in 15 minutes and can only be used once.\n\nIf you did not request this, ignore this message.";
    $mailResult = send_email($row['email'], $row['first_name'], $subject, $body);
    // Localhost testing mode: surface delivery status / a manual link only when
    // APP_ENV is explicitly local, so production never leaks this to end users.
    if(defined('APP_ENV') && APP_ENV==='local'){
        $success.= $mailResult['ok']
            ? ' (Email sent successfully.)'
            : ' [DEV NOTE: email not sent — '.e($mailResult['error']).'] Local testing link: '.$link;
    }
   }
  }
 } elseif($action==='reset'){
  $postedToken=$_POST['token']??'';$hash=hash('sha256',$postedToken);$st=$conn->prepare("SELECT reset_id,resident_id FROM tbl_password_resets WHERE token_hash=? AND used_at IS NULL AND expires_at>NOW() LIMIT 1");$st->bind_param('s',$hash);$st->execute();$reset=$st->get_result()->fetch_assoc();$new=$_POST['new_password']??'';$confirm=$_POST['confirm_password']??'';
  if(!$reset)$error='This reset link is invalid or expired.';elseif(strlen($new)<8)$error='Password must be at least 8 characters.';elseif($new!==$confirm)$error='Passwords do not match.';else{$pw=password_hash($new,PASSWORD_DEFAULT);$up=$conn->prepare('UPDATE tblresidents SET password=?, password_plain=? WHERE resident_id=?');$up->bind_param('ssi',$pw,$new,$reset['resident_id']);$up->execute();$done=$conn->prepare('UPDATE tbl_password_resets SET used_at=NOW() WHERE reset_id=?');$done->bind_param('i',$reset['reset_id']);$done->execute();$success='Password reset successful. You may now sign in.';$resetMode=false;}
 }
}
include 'includes/header.php';
?>
<div class="register-page">
<div class="login-layout">
<div class="login-box card register-card">
  <div class="register-card-toolbar">
    <a class="btn-back-in" href="login.php"><i class="bi bi-arrow-left"></i> Back</a>
  </div>
<h2 class="register-title">Forgot Password</h2>
<?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?>
<?php if($success):?><div class="alert alert-success" style="white-space:pre-line"><?=e($success)?></div><?php endif;?>
<?php if($resetMode):?>
<p class="muted">Create a new password. This one-time link expires after 15 minutes.</p><form method="post"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="reset"><input type="hidden" name="token" value="<?=e($token)?>"><div class="form-group"><label>New Password *</label><div class="password-wrap"><input type="password" id="resetNewPassword" class="form-control" name="new_password" minlength="8" required><button type="button" class="password-toggle" data-toggle-target="resetNewPassword" aria-label="Show password" title="Show password"><i class="bi bi-eye password-eye-icon"></i></button></div></div><br><div class="form-group"><label>Confirm Password *</label><div class="password-wrap"><input type="password" id="resetConfirmPassword" class="form-control" name="confirm_password" minlength="8" required><button type="button" class="password-toggle" data-toggle-target="resetConfirmPassword" aria-label="Show password" title="Show password"><i class="bi bi-eye password-eye-icon"></i></button></div></div><br><button class="btn btn-register" style="width:100%">Set New Password</button></form>
<?php elseif(!$success):?><p class="muted">Enter the email address registered to your account. A one-time reset link will be sent to it.</p><form method="post"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="request"><div class="form-group"><label>Registered Email *</label><input type="email" class="form-control" name="identifier" autocomplete="email" required></div><br><button class="btn btn-register" style="width:100%">Send Reset Link</button></form><?php endif;?><p class="small muted" style="margin-top:15px"><a href="login.php"><i class="bi bi-arrow-left"></i> Back to Sign In</a></p></div>
</div>
</div>
<?php include 'includes/footer.php'; ?>
