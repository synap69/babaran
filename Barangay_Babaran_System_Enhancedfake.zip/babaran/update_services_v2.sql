-- Update Barangay Babaran document services to match what the system actually processes.
-- Safe to re-run. Uses is_active=0 (soft-delete) instead of DELETE so no existing
-- requests referencing these services are ever affected (tblrequests.service_id
-- has an ON DELETE RESTRICT foreign key, so a hard DELETE could fail anyway if any
-- resident had already requested one of these).

-- 1) Turn off services that are no longer offered by this system
UPDATE tblservices SET is_active = 0
WHERE service_name IN ('Tree-Cutting Permit', 'Piggery Permit', 'Poultry Permit');

-- 2) Add the new services (safe to re-run: updates description/re-activates if it already exists)
INSERT INTO tblservices (service_name, description, is_active) VALUES
('Cedula (Community Tax Certificate)', 'Required for notarial acts, court appearances, and many government transactions. Issued yearly.', 1),
('Certificate of Good Moral Character', 'Verifies good standing in the community for job, school, and visa applications.', 1),
('Sangguniang Kabataan (SK) Certification', 'Youth-related certifications for residents aged 15-30, issued through the SK Chairperson.', 1)
ON DUPLICATE KEY UPDATE description = VALUES(description), is_active = 1;
