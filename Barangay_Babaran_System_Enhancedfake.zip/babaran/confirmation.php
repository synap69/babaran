<?php
require 'includes/config.php';
require_resident();
$pageTitle = 'Request Submitted';
$id = (int)($_GET['id'] ?? 0);
$st = $conn->prepare("SELECT r.*,s.service_name FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE r.request_id=? AND r.resident_id=?");
$st->bind_param('ii', $id, $_SESSION['resident_id']);
$st->execute();
$r = $st->get_result()->fetch_assoc();
if (!$r) {
    http_response_code(404);
    die('Request not found.');
}
$fullName = trim(preg_replace('/\s+/', ' ', $r['request_first_name'] . ' ' . $r['request_middle_name'] . ' ' . $r['request_last_name']));
$queueNo = queue_number($r['request_id']);
$statusOrder = ['Pending', 'Scheduled', 'Processing', 'Completed', 'Released'];
$currentIdx = array_search($r['status'], $statusOrder, true);
if ($r['status'] === 'Rejected') {
    $currentIdx = -1;
}
include 'includes/header.php';
?>
<div class="request-shell">
  <div class="stepper">
    <div class="step-item done"><div class="step-circle">✓</div><div><strong>Resident Information</strong><span>Completed</span></div></div>
    <div class="step-item done"><div class="step-circle">✓</div><div><strong>Document Type</strong><span>Completed</span></div></div>
    <div class="step-item done"><div class="step-circle">✓</div><div><strong>Review & Submit</strong><span>Completed</span></div></div>
    <div class="step-item active"><div class="step-circle">4</div><div><strong>Confirmation</strong><span>Track your request</span></div></div>
  </div>

  <div class="request-card">
    <div style="text-align:center;padding:20px 0 10px">
      <div style="width:64px;height:64px;border-radius:50%;background:linear-gradient(135deg,#1F7A3A,#2E9E4F);color:#fff;display:grid;place-items:center;margin:0 auto 14px;font-size:28px">
        <i class="bi bi-check-lg"></i>
      </div>
      <h2 style="color:#1F7A3A;margin:0 0 6px">Request Submitted Successfully!</h2>
      <p class="muted">Your document request has been received and is now pending review by barangay personnel.</p>
    </div>

    <div class="queue-banner" style="text-align:center;margin:18px 0">
      <div class="small muted" style="text-transform:uppercase;letter-spacing:1px">Your Queue / Reference Number</div>
      <div class="queue-number" style="font-size:28px;font-weight:800;color:#1F7A3A;letter-spacing:1px"><?= e($queueNo) ?></div>
    </div>

    <!-- Status Timeline -->
    <h3 style="margin:20px 0 8px;font-size:14px;color:#1F7A3A">Request Progress</h3>
    <?php if ($r['status'] === 'Rejected'): ?>
      <div class="alert alert-danger">This request was <strong>Rejected</strong>.<?= $r['remarks'] ? ' Remarks: ' . e($r['remarks']) : '' ?></div>
    <?php else: ?>
      <ul class="status-timeline">
        <?php foreach ($statusOrder as $i => $s): ?>
          <li class="<?= $i < $currentIdx ? 'done' : ($i === $currentIdx ? 'current' : '') ?>">
            <?php if ($i < $currentIdx): ?>✓<?php elseif ($i === $currentIdx): ?>●<?php else: ?>○<?php endif; ?>
            <span class="tl-label"><?= e($s) ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>

    <div class="card" style="margin-top:16px">
      <h3>Request Summary</h3>
      <div class="summary-list">
        <div class="summary-row"><span>Full Name</span><strong><?= e($fullName) ?></strong></div>
        <div class="summary-row"><span>Document</span><strong><?= e($r['service_name']) ?></strong></div>
        <div class="summary-row"><span>Purpose</span><strong><?= e($r['purpose']) ?></strong></div>
        <div class="summary-row"><span>Preferred Schedule</span><strong><?= date('M d, Y', strtotime($r['preferred_date'])) ?> · <?= date('h:i A', strtotime($r['preferred_time'])) ?></strong></div>
        <?php if ($r['scheduled_date']): ?>
          <div class="summary-row"><span>Assigned Schedule</span><strong><?= date('M d, Y', strtotime($r['scheduled_date'])) ?> · <?= date('h:i A', strtotime($r['scheduled_time'])) ?></strong></div>
        <?php endif; ?>
        <div class="summary-row"><span>Status</span><span class="badge badge-<?= strtolower($r['status']) ?>"><?= e($r['status']) ?></span></div>
      </div>
    </div>

    <div class="request-actions" style="margin-top:20px;display:flex;gap:10px;flex-wrap:wrap;justify-content:center">
      <a class="btn btn-primary" href="request_slip.php?id=<?= $id ?>"><i class="bi bi-printer"></i> Print Request Slip</a>
      <?php if (in_array($r['status'], ['Completed', 'Released'], true)): ?>
        <a class="btn btn-outline" href="generate_certificate.php?id=<?= $id ?>" target="_blank"><i class="bi bi-file-earmark-pdf"></i> Download Certificate</a>
      <?php endif; ?>
      <a class="btn btn-outline" href="requests.php">View All Requests</a>
      <a class="btn btn-outline" href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="info-banner" style="margin-top:18px">
      <strong>What happens next?</strong> Barangay personnel will review your request and assign an official schedule. You will receive an email notification (if you provided an email) when the status changes. You can also track progress anytime from <em>My Requests</em>.
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
