<?php
require 'includes/config.php';
require_resident();
$pageTitle = 'Review & Submit';
$id = (int)($_GET['id'] ?? 0);
$residentId = (int)$_SESSION['resident_id'];
$st = $conn->prepare("SELECT r.*,s.service_name,s.description FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE r.request_id=? AND r.resident_id=?");
$st->bind_param('ii', $id, $residentId);
$st->execute();
$r = $st->get_result()->fetch_assoc();
if (!$r) {
    http_response_code(404);
    die('Request not found.');
}
include 'includes/header.php';
?>
<div class="request-shell">
  <div class="stepper">
    <div class="step-item done"><div class="step-circle">✓</div><div><strong>Resident Information</strong><span>Completed</span></div></div>
    <div class="step-item done"><div class="step-circle">✓</div><div><strong>Document Type</strong><span>Completed</span></div></div>
    <div class="step-item active"><div class="step-circle">3</div><div><strong>Edit / Review</strong><span>Check request details</span></div></div>
    <div class="step-item"><div class="step-circle">4</div><div><strong>Confirm & Submit</strong><span>Optional e-signature</span></div></div>
  </div>

  <div class="request-card">
    <div class="request-section-title">Step 3 of 4</div>
    <h2>Review Request</h2>
    <p class="muted small">Review the information below before your request is processed. Electronic signature is <strong>optional</strong>.</p>

    <div class="review-grid">
      <div class="preview-doc">
        <div class="doc-header">
          <img src="assets/img/barangay-babaran-logo.png" width="58" height="58" style="border-radius:50%" alt="Logo">
          <p>REPUBLIC OF THE PHILIPPINES<br>PROVINCE OF ISABELA<br>MUNICIPALITY OF ECHAGUE</p>
          <h2>BARANGAY BABARAN</h2>
          <p>DOCUMENT REQUEST</p>
        </div>
        <p><strong>Queue Number:</strong> <?= e(queue_number($r['request_id'])) ?></p>
        <p><strong>Document Requested:</strong> <?= e($r['service_name']) ?></p>
        <p><strong>To Whom It May Concern:</strong></p>
        <p>This request is submitted by <strong><?= e(trim($r['request_first_name'] . ' ' . $r['request_middle_name'] . ' ' . $r['request_last_name'])) ?></strong>, a resident of Barangay Babaran, Echague, Isabela, for the purpose stated below.</p>
        <p><strong>Purpose:</strong> <?= e($r['purpose']) ?></p>
        <p><strong>Preferred Schedule:</strong> <?= date('F d, Y', strtotime($r['preferred_date'])) ?> at <?= date('h:i A', strtotime($r['preferred_time'])) ?></p>
        <div style="margin-top:35px">
          <strong>Resident Signature</strong><br>
          <?php if ($r['resident_signature']): ?>
            <img src="<?= e($r['resident_signature']) ?>" class="signature-preview" alt="Resident signature">
          <?php else: ?>
            <span class="muted small">(Optional — may be signed at the barangay hall)</span>
          <?php endif; ?>
        </div>
      </div>

      <div class="card">
        <h3>Request Summary</h3>
        <div class="summary-list">
          <div class="summary-row"><span>Full Name</span><strong><?= e(trim($r['request_first_name'] . ' ' . $r['request_middle_name'] . ' ' . $r['request_last_name'])) ?></strong></div>
          <div class="summary-row"><span>Address</span><strong><?= e($r['request_address']) ?></strong></div>
          <div class="summary-row"><span>Contact</span><strong><?= e($r['request_contact'] ?: 'Not provided') ?></strong></div>
          <div class="summary-row"><span>Document</span><strong><?= e($r['service_name']) ?></strong></div>
          <div class="summary-row"><span>Purpose</span><strong><?= e($r['purpose']) ?></strong></div>
          <div class="summary-row"><span>Preferred Date</span><strong><?= date('M d, Y', strtotime($r['preferred_date'])) ?></strong></div>
          <div class="summary-row"><span>Preferred Time</span><strong><?= date('h:i A', strtotime($r['preferred_time'])) ?></strong></div>
          <div class="summary-row"><span>Status</span><span class="badge badge-pending">Draft</span></div>
        </div>

        <a class="btn btn-outline" style="width:100%;text-align:center;margin-top:10px" href="edit_request.php?id=<?= $id ?>">✎ Edit Information</a>

        <form method="post" action="submit_request.php" style="margin-top:14px" id="submitForm">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="request_id" value="<?= $id ?>">

          <div class="form-group" style="margin-top:12px">
            <label><strong>Electronic Signature <span class="muted">(Optional)</span></strong></label>
            <div class="signature-pad-wrap">
              <canvas id="reviewSignaturePad" class="signature-pad"></canvas>
            </div>
            <input type="hidden" name="resident_signature" id="reviewSignature">
            <button type="button" class="btn btn-outline btn-small" style="margin-top:6px" onclick="clearPad(reviewPad,'reviewSignature')">Clear Signature</button>
            <div class="info-banner" style="margin-top:10px">
              <strong>Note:</strong> Electronic signature is optional. You may skip this step and sign physically at the barangay hall when you claim your document.
            </div>
          </div>

          <button class="btn btn-primary" style="width:100%;margin-top:12px" type="submit">✓ Confirm &amp; Submit Request</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="assets/js/signature.js"></script>
<script>
const reviewPad = setupSignaturePad(document.getElementById("reviewSignaturePad"), document.getElementById("reviewSignature"));
// Signature is optional — no forced validation on submit
</script>
<?php include 'includes/footer.php'; ?>
