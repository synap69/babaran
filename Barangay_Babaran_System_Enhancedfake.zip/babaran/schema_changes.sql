-- Barangay Babaran System: TWO schema changes for an existing babaran_db
-- Change 1: Role-based personnel access
-- Change 2: Audit trail
-- Run this file ONLY if you are upgrading an older database that does not
-- already contain these columns/table. If you import the current database.sql,
-- these changes are already included.

USE babaran_db;

SET @db := DATABASE();

-- Add tbladmin.role if missing
SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='tbladmin' AND COLUMN_NAME='role'),
    'SELECT 1',
    'ALTER TABLE tbladmin ADD COLUMN role ENUM(''Punong Barangay'',''Secretary'') NOT NULL DEFAULT ''Secretary'' AFTER full_name'
  )
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Add tbladmin.is_active if missing
SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='tbladmin' AND COLUMN_NAME='is_active'),
    'SELECT 1',
    'ALTER TABLE tbladmin ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER role'
  )
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Make the existing admin account full-access when that username exists.
UPDATE tbladmin SET role='Punong Barangay' WHERE username='admin';

-- Create audit trail table if missing.
CREATE TABLE IF NOT EXISTS tbl_audit_log (
  audit_id INT AUTO_INCREMENT PRIMARY KEY,
  actor_type ENUM('admin','resident','system') NOT NULL DEFAULT 'admin',
  actor_id INT NULL,
  actor_name VARCHAR(150) NOT NULL,
  action VARCHAR(100) NOT NULL,
  target_table VARCHAR(60) NOT NULL,
  target_id INT NULL,
  details VARCHAR(500) NULL,
  ip_address VARCHAR(45) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_target (target_table, target_id),
  INDEX idx_audit_created (created_at)
) ENGINE=InnoDB;




-- Change 4: Make the schedule table and automatic request/schedule synchronization
-- available when upgrading an existing database.
CREATE TABLE IF NOT EXISTS tblschedules (
  schedule_id INT AUTO_INCREMENT PRIMARY KEY,
  request_id INT NOT NULL UNIQUE,
  scheduled_date DATE NOT NULL,
  scheduled_time TIME NOT NULL,
  status ENUM('Scheduled','Completed','Cancelled') NOT NULL DEFAULT 'Scheduled',
  remarks VARCHAR(500) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_schedules_request FOREIGN KEY (request_id) REFERENCES tblrequests(request_id) ON DELETE CASCADE ON UPDATE CASCADE,
  INDEX idx_schedules_date_time(scheduled_date, scheduled_time)
) ENGINE=InnoDB;

DROP TRIGGER IF EXISTS trg_requests_schedule_after_insert;
DROP TRIGGER IF EXISTS trg_requests_schedule_after_update;

DELIMITER $$
CREATE TRIGGER trg_requests_schedule_after_insert
AFTER INSERT ON tblrequests
FOR EACH ROW
BEGIN
  IF NEW.scheduled_date IS NOT NULL AND NEW.scheduled_time IS NOT NULL THEN
    INSERT INTO tblschedules(request_id,scheduled_date,scheduled_time,status,remarks)
    VALUES(NEW.request_id,NEW.scheduled_date,NEW.scheduled_time,
      CASE WHEN NEW.status IN ('Completed','Released') THEN 'Completed' WHEN NEW.status='Rejected' THEN 'Cancelled' ELSE 'Scheduled' END,
      NEW.remarks);
  END IF;
END$$

CREATE TRIGGER trg_requests_schedule_after_update
AFTER UPDATE ON tblrequests
FOR EACH ROW
BEGIN
  IF NEW.scheduled_date IS NULL OR NEW.scheduled_time IS NULL THEN
    DELETE FROM tblschedules WHERE request_id=NEW.request_id;
  ELSE
    INSERT INTO tblschedules(request_id,scheduled_date,scheduled_time,status,remarks)
    VALUES(NEW.request_id,NEW.scheduled_date,NEW.scheduled_time,
      CASE WHEN NEW.status IN ('Completed','Released') THEN 'Completed' WHEN NEW.status='Rejected' THEN 'Cancelled' ELSE 'Scheduled' END,
      NEW.remarks)
    ON DUPLICATE KEY UPDATE
      scheduled_date=VALUES(scheduled_date),
      scheduled_time=VALUES(scheduled_time),
      status=VALUES(status),
      remarks=VALUES(remarks);
  END IF;
END$$
DELIMITER ;

-- Backfill schedule records for requests that were already scheduled before the migration.
INSERT INTO tblschedules(request_id,scheduled_date,scheduled_time,status,remarks)
SELECT r.request_id,r.scheduled_date,r.scheduled_time,
       CASE WHEN r.status IN ('Completed','Released') THEN 'Completed' WHEN r.status='Rejected' THEN 'Cancelled' ELSE 'Scheduled' END,
       r.remarks
FROM tblrequests r
LEFT JOIN tblschedules s ON s.request_id=r.request_id
WHERE r.scheduled_date IS NOT NULL
  AND r.scheduled_time IS NOT NULL
  AND s.request_id IS NULL;


-- DEMO ONLY: store the original password so it can be viewed in phpMyAdmin.
-- Keep the hashed password for authentication. Do NOT use this in production.
SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='tblresidents' AND COLUMN_NAME='password_plain'),
    'SELECT 1',
    'ALTER TABLE tblresidents ADD COLUMN password_plain VARCHAR(255) NULL COMMENT ''DEMO ONLY: original password; do not use in production'' AFTER password'
  )
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;


-- Change 3: Shared personnel demo password for Punong Barangay and Secretary.
-- Both seeded personnel accounts use the same password: admin1234.
-- DEMO ONLY: password_plain is intentionally visible for the school/demo requirement.
SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='tbladmin' AND COLUMN_NAME='password_plain'),
    'SELECT 1',
    'ALTER TABLE tbladmin ADD COLUMN password_plain VARCHAR(255) NULL COMMENT ''DEMO ONLY: original personnel password; do not use in production'' AFTER is_active'
  )
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Keep the two standard personnel accounts available and synchronized.
INSERT INTO tbladmin (username,password,full_name,role,is_active,password_plain)
SELECT 'secretary', '$2y$12$6UsROVyZYgH0m/E/rSBLs.NSf/7tuW3V0LS9M7g5JIPrmaWkSUH3i', 'Barangay Secretary', 'Secretary', 1, 'admin1234'
WHERE NOT EXISTS (SELECT 1 FROM tbladmin WHERE username='secretary');

UPDATE tbladmin
SET password='$2y$12$6UsROVyZYgH0m/E/rSBLs.NSf/7tuW3V0LS9M7g5JIPrmaWkSUH3i', password_plain='admin1234'
WHERE username IN ('admin','secretary');
UPDATE tbladmin SET role='Punong Barangay' WHERE username='admin';
UPDATE tbladmin SET role='Secretary' WHERE username='secretary';


-- Change 5: Remove the signatory feature entirely (drop FKs/columns/table
-- from an existing database that still has them from an earlier version).
SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='tblrequests' AND CONSTRAINT_NAME='fk_requests_signatory'),
    'ALTER TABLE tblrequests DROP FOREIGN KEY fk_requests_signatory',
    'SELECT 1'
  )
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='tblschedules' AND CONSTRAINT_NAME='fk_schedules_signatory'),
    'ALTER TABLE tblschedules DROP FOREIGN KEY fk_schedules_signatory',
    'SELECT 1'
  )
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='tblrequests' AND COLUMN_NAME='signatory_id'),
    'ALTER TABLE tblrequests DROP COLUMN signatory_id',
    'SELECT 1'
  )
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='tblrequests' AND COLUMN_NAME='signatory'),
    'ALTER TABLE tblrequests DROP COLUMN signatory',
    'SELECT 1'
  )
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='tblschedules' AND COLUMN_NAME='signatory_id'),
    'ALTER TABLE tblschedules DROP COLUMN signatory_id',
    'SELECT 1'
  )
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

DROP TABLE IF EXISTS tbl_signatories;


-- Change 6: Remove the SMS/resident-notification feature entirely (drop the
-- notifications table from an existing database that still has it).
DROP TABLE IF EXISTS tblnotifications;
