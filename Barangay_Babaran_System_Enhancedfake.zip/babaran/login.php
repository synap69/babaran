<?php
require 'includes/config.php';
$pageTitle = 'Sign In';
$error = '';
$validRoles = ['Resident','Personnel','Punong Barangay','Secretary'];

$requestedRole = trim($_GET['role'] ?? '');
if (!in_array($requestedRole, $validRoles, true)) {
    $requestedRole = 'Resident';
}
$selectedRole = $_SERVER['REQUEST_METHOD'] === 'POST'
    ? trim($_POST['role'] ?? $requestedRole)
    : $requestedRole;

if (!in_array($selectedRole, $validRoles, true)) {
    $selectedRole = 'Resident';
}

// Personnel is a combined portal for the Punong Barangay and Barangay Secretary.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $selectedRole === 'Personnel') {
    $selectedRole = trim($_POST['personnel_role'] ?? '');
    if (!in_array($selectedRole, ['Punong Barangay','Secretary'], true)) {
        $selectedRole = 'Personnel';
    }
}

if (isset($_SESSION['resident_id'])) {
    header('Location: dashboard.php');
    exit;
}
if (isset($_SESSION['admin_id'])) {
    header('Location: admin/dashboard.php');
    exit;
}

$registered = isset($_GET['registered'])
    ? 'Account created successfully. You can now sign in.'
    : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $identifier = trim($_POST['identifier'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($identifier === '' || $password === '') {
        $error = 'Please enter your login identifier and password.';
    } elseif ($selectedRole === 'Resident') {
        $st = $conn->prepare(
            'SELECT resident_id,first_name,password FROM tblresidents
             WHERE email=? OR contact_no=? LIMIT 1'
        );
        $st->bind_param('ss', $identifier, $identifier);
        $st->execute();
        $row = $st->get_result()->fetch_assoc();
        $st->close();

        if ($row && password_verify($password, $row['password'])) {
            login_session('resident', $row['resident_id'], $row['first_name']);

            $ip = $_SERVER['REMOTE_ADDR'] ?? null;
            $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);
            $lh = $conn->prepare(
                "INSERT INTO tbl_login_history
                (actor_type,resident_id,login_identifier,ip_address,user_agent)
                VALUES('resident',?,?,?,?)"
            );
            $lh->bind_param('isss', $row['resident_id'], $identifier, $ip, $ua);
            $lh->execute();
            $lh->close();

            header('Location: dashboard.php');
            exit;
        }

        $error = 'Invalid resident email/contact number or password.';
    } else {
        $st = $conn->prepare(
            'SELECT admin_id,username,password,full_name,role,is_active
             FROM tbladmin WHERE username=? AND role=? LIMIT 1'
        );
        $st->bind_param('ss', $identifier, $selectedRole);
        $st->execute();
        $row = $st->get_result()->fetch_assoc();
        $st->close();

        if ($row && !(int)$row['is_active']) {
            $error = 'This account is inactive. Contact the Punong Barangay.';
        } elseif ($row && password_verify($password, $row['password'])) {
            login_session('admin', $row['admin_id'], $row['full_name'], $row['role']);

            $ip = $_SERVER['REMOTE_ADDR'] ?? null;
            $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);
            $lh = $conn->prepare(
                "INSERT INTO tbl_login_history
                (actor_type,admin_id,login_identifier,ip_address,user_agent)
                VALUES('admin',?,?,?,?)"
            );
            $lh->bind_param('isss', $row['admin_id'], $identifier, $ip, $ua);
            $lh->execute();
            $lh->close();

            header('Location: admin/dashboard.php');
            exit;
        }

        $error = 'Invalid ' . $selectedRole . ' username or password.';
    }
}

include 'includes/header.php';

$roleTitle = $selectedRole === 'Resident'
    ? 'Resident'
    : ($selectedRole === 'Personnel' ? 'Barangay Personnel' : ($selectedRole === 'Punong Barangay' ? 'Punong Barangay' : 'Barangay Secretary'));

$roleIcon = $selectedRole === 'Resident'
    ? 'bi-person'
    : ($selectedRole === 'Personnel' ? 'bi-people' : ($selectedRole === 'Punong Barangay' ? 'bi-person-badge' : 'bi-person-workspace'));

$identifierLabel = $selectedRole === 'Resident'
    ? 'Email or Contact Number'
    : 'Username';

$identifierPlaceholder = $selectedRole === 'Resident'
    ? 'Enter your email or contact number'
    : 'Enter your personnel username';
?>
<div class="register-page">
<div class="login-layout">
  <div class="login-card login-card-solo">
    <section class="login-form">
      <div class="register-card-toolbar">
        <a class="btn-back-in" href="index.php"><i class="bi bi-arrow-left"></i> Back</a>
      </div>
      <div class="login-icon"><i class="bi <?=e($roleIcon)?>"></i></div>
      <h2><?=e($roleTitle)?> Sign In</h2>
      <p>Sign in using your <?=e(strtolower($roleTitle))?> account.</p>

      <?php if ($registered): ?>
        <div class="alert alert-success"><?=e($registered)?></div>
      <?php endif; ?>

      <?php if ($error): ?>
        <div class="alert alert-danger"><?=e($error)?></div>
      <?php endif; ?>

      <form method="post" autocomplete="on"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
        <input type="hidden" name="role" value="<?=e($selectedRole)?>">

        <div class="selected-role-box">
          <span><i class="bi <?=e($roleIcon)?>"></i> Selected User Type</span>
          <strong><?=e($roleTitle)?></strong>
        </div>

        <?php if ($requestedRole === 'Personnel' || $selectedRole === 'Personnel'): ?>
          <div class="form-group">
            <label for="personnelRole">Personnel Role</label>
            <select class="form-select" name="personnel_role" id="personnelRole" required>
              <option value="">Select your role</option>
              <option value="Punong Barangay" <?=($_POST['personnel_role'] ?? '')==='Punong Barangay'?'selected':''?>>Punong Barangay</option>
              <option value="Secretary" <?=($_POST['personnel_role'] ?? '')==='Secretary'?'selected':''?>>Barangay Secretary</option>
            </select>
          </div><br>
        <?php endif; ?>

        <div class="form-group">
          <label for="loginIdentifier"><?=e($identifierLabel)?></label>
          <input
            class="form-control"
            name="identifier"
            id="loginIdentifier"
            placeholder="<?=e($identifierPlaceholder)?>"
            autocomplete="username"
            value="<?=e($_POST['identifier'] ?? '')?>"
            required>
        </div><br>

        <div class="form-group">
          <label for="loginPassword">Password</label>
          <div class="password-wrap">
            <input
              type="password"
              id="loginPassword"
              class="form-control"
              name="password"
              placeholder="Enter your password"
              autocomplete="current-password"
              required>
            <button type="button" class="password-toggle"
                    data-toggle-target="loginPassword"
                    aria-label="Show password"
                    title="Show password">
              <i class="bi bi-eye password-eye-icon"></i>
            </button>
          </div>
        </div>

        <div class="login-actions">
          <span></span>
          <?php if ($selectedRole === 'Resident'): ?>
            <a href="forgot_password.php">Forgot password?</a>
          <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-primary" style="width:100%">
          <i class="bi bi-box-arrow-in-right"></i> &nbsp; SIGN IN
        </button>
      </form>

      <?php if ($selectedRole === 'Resident'): ?>
        <div class="login-bottom">
          Don't have an account?
          <a href="register.php" style="color:var(--blue);font-weight:700">Create Resident Account</a>
        </div>
      <?php endif; ?>

      <div class="login-bottom">© <?=date('Y')?> Barangay Babaran. All rights reserved.</div>
    </section>
  </div>
</div>
</div>
<?php include 'includes/footer.php'; ?>
