<?php
require 'includes/config.php';
$pageTitle = 'Welcome';
$servicesList = [];
$svcRes = $conn->query("SELECT service_name, description FROM tblservices WHERE is_active=1 ORDER BY service_name");
if ($svcRes) {
    while ($row = $svcRes->fetch_assoc()) {
        $servicesList[] = $row;
    }
}
$serviceIcons = [
    'Barangay Clearance' => ['bi-person-vcard-fill', '#0D6A36'],
    'Certificate of Indigency' => ['bi-cash-coin', '#ffbf45'],
    'Certificate of Residency' => ['bi-house-door-fill', '#20a05a'],
    'Business Permit Endorsement' => ['bi-briefcase-fill', '#6DA41B'],
    'Cedula (Community Tax Certificate)' => ['bi-bank2', '#0B5C32'],
    'Certificate of Good Moral Character' => ['bi-patch-check-fill', '#20a05a'],
    'Sangguniang Kabataan (SK) Certification' => ['bi-mortarboard-fill', '#6DA41B'],
    'Other Special Permit' => ['bi-file-earmark-text-fill', '#637A6B'],
];
include 'includes/header.php';
?>
<style>
/* ===== HERO ===== */
.bb-hero{position:relative;background:#0B5C32;padding:0 0 100px;overflow:hidden}
.bb-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 70% 10%,rgba(255,255,255,.12),transparent 60%);pointer-events:none}
.bb-hero-nav{max-width:1140px;margin:0 auto;padding:18px 24px;display:flex;align-items:center;justify-content:space-between;position:relative;z-index:2}
.bb-hero-brand{display:flex;align-items:center;gap:12px;color:#fff;text-decoration:none}
.bb-hero-brand img{height:40px;width:40px;border-radius:10px;background:#fff;object-fit:contain;padding:3px;box-shadow:0 2px 8px rgba(0,0,0,.15)}
.bb-hero-brand strong{font-size:15px;letter-spacing:.4px;font-weight:800}
.bb-hero-links{display:flex;align-items:center;gap:22px}
.bb-hero-links a{color:#E8F5E9;font-size:13px;font-weight:600;text-decoration:none;opacity:.9;transition:opacity .15s}
.bb-hero-links a:hover{opacity:1;text-decoration:underline}
.bb-hero-links .btn-login{background:#fff;color:#0B5C32;padding:9px 18px;border-radius:999px;font-weight:800;box-shadow:none}
.bb-hero-links .btn-login:hover{text-decoration:none;background:#F2F4EF}
.bb-hero-body{max-width:720px;margin:48px auto 0;padding:0 24px;text-align:center;position:relative;z-index:2;color:#fff}
.bb-hero-kicker{font-size:11px;letter-spacing:2.2px;font-weight:800;color:#D4EDDA;text-transform:uppercase;margin-bottom:12px}
.bb-hero-body h1{font-size:32px;margin:0 0 14px;font-weight:800;line-height:1.25;text-shadow:0 2px 12px rgba(0,0,0,.15)}
.bb-hero-body p{font-size:14.5px;color:#E0F2E0;margin:0 auto 28px;line-height:1.7;max-width:560px}
.bb-hero-ctas{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.bb-hero-ctas .btn-cta{display:inline-flex;align-items:center;gap:8px;padding:13px 26px;border-radius:999px;font-weight:800;font-size:14px;text-decoration:none;transition:transform .15s,box-shadow .15s}
.bb-hero-ctas .btn-cta-primary{background:#fff;color:#0B5C32;box-shadow:0 4px 16px rgba(0,0,0,.12)}
.bb-hero-ctas .btn-cta-primary:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(0,0,0,.16)}
.bb-hero-ctas .btn-cta-secondary{background:rgba(255,255,255,.15);color:#fff;border:1.5px solid rgba(255,255,255,.4);backdrop-filter:blur(4px)}
.bb-hero-ctas .btn-cta-secondary:hover{background:rgba(255,255,255,.25);transform:translateY(-2px)}

/* ===== ROLE CARDS ===== */
.bb-role-grid{max-width:960px;margin:-56px auto 0;padding:0 24px;position:relative;z-index:3;display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.bb-role-card{background:#fff;border-radius:16px;padding:28px 22px 24px;text-align:center;box-shadow:0 16px 40px rgba(36,143,71,.14);border:1px solid #E8F5E9;text-decoration:none;color:inherit;transition:transform .2s ease,box-shadow .2s ease;display:block}
.bb-role-card:hover{transform:translateY(-6px);box-shadow:0 22px 50px rgba(36,143,71,.22)}
.bb-role-icon{width:60px;height:60px;border-radius:16px;display:grid;place-items:center;margin:0 auto 14px;font-size:26px;color:#fff}
.bb-role-card h3{margin:0 0 8px;font-size:16px;color:#0B5C32;font-weight:800}
.bb-role-card p{margin:0;font-size:12.5px;color:#5A7A66;line-height:1.55}
.bb-role-card .role-cta{display:inline-block;margin-top:14px;font-size:12px;font-weight:700;color:#0D6A36}

.bb-note{max-width:960px;margin:22px auto 0;padding:0 24px;text-align:center;color:#718B7A;font-size:12px;display:flex;align-items:center;justify-content:center;gap:8px}

/* ===== SECTIONS ===== */
.bb-section{max-width:1080px;margin:0 auto;padding:60px 24px}
.bb-section.alt{max-width:none;background:#F6FBF6;border-top:1px solid #E8F5E9;border-bottom:1px solid #E8F5E9}
.bb-section.alt>.bb-inner{max-width:1080px;margin:0 auto}
.bb-section-head{text-align:center;margin-bottom:36px}
.bb-section-head .kicker{font-size:11px;letter-spacing:2px;font-weight:800;color:#0D6A36;text-transform:uppercase}
.bb-section-head h2{font-size:24px;margin:8px 0 10px;color:#0B5C32;font-weight:800}
.bb-section-head p{color:#5A7A66;font-size:13.5px;max-width:520px;margin:0 auto;line-height:1.6}

/* How it Works */
.bb-how-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;margin-top:8px}
.bb-how-card{background:#fff;border:1px solid #E8F5E9;border-radius:14px;padding:24px 18px;text-align:center;position:relative}
.bb-how-card .step-num{width:36px;height:36px;border-radius:50%;background:#0B5C32;color:#fff;font-weight:800;font-size:15px;display:grid;place-items:center;margin:0 auto 12px;box-shadow:0 4px 12px rgba(31,122,58,.25)}
.bb-how-card h4{margin:0 0 6px;font-size:14px;color:#1C3A26;font-weight:700}
.bb-how-card p{margin:0;font-size:12px;color:#5A7A66;line-height:1.5}

/* Services */
.bb-services-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px;margin-top:8px}
.bb-service-row{background:#fff;border:1px solid #E8F5E9;border-radius:12px;padding:16px 18px;display:flex;gap:14px;align-items:flex-start;transition:transform .15s,box-shadow .15s;cursor:default}
.bb-service-row:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(36,143,71,.1)}
.bb-service-row .ic{width:40px;height:40px;border-radius:10px;display:grid;place-items:center;color:#fff;font-size:17px;flex-shrink:0}
.bb-service-row h4{margin:0 0 4px;font-size:13.5px;color:#1C3A26;font-weight:700}
.bb-service-row p{margin:0;font-size:12px;color:#5A7A66;line-height:1.5}

/* History / Vision */
.bb-history{background:#fff;border:1px solid #E8F5E9;border-radius:16px;padding:32px;display:grid;grid-template-columns:100px 1fr;gap:28px;align-items:center;box-shadow:0 8px 24px rgba(36,143,71,.05)}
.bb-history img{width:90px;height:90px;object-fit:contain}
.bb-history p{color:#336945;font-size:13.5px;line-height:1.85;margin:0}
.bb-vm-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:22px}
.bb-vm-card{color:#fff;border-radius:14px;padding:26px}
.bb-vm-card.vision{background:#0B5C32}
.bb-vm-card.mission{background:#0D6A36}
.bb-vm-card h3{margin:0 0 12px;font-size:12px;letter-spacing:1.5px;text-transform:uppercase;opacity:.9;display:flex;align-items:center;gap:8px}
.bb-vm-card p{margin:0;font-size:13px;line-height:1.8;font-style:italic}
.bb-vm-card .tag{display:block;margin-top:12px;font-size:11px;font-style:normal;opacity:.8;font-weight:700}

/* Stats */
.bb-stat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-top:8px}
.bb-stat-box{background:#fff;border:1px solid #E8F5E9;border-radius:12px;padding:18px 12px;text-align:center}
.bb-stat-box i{font-size:20px;color:#0D6A36;margin-bottom:8px;display:block}
.bb-stat-box .val{font-size:16px;font-weight:800;color:#0B5C32}
.bb-stat-box .lbl{font-size:10px;color:#718B7A;text-transform:uppercase;letter-spacing:.4px;margin-top:3px}

/* Officials */
.bb-official-lead{text-align:center;margin-bottom:28px}
.bb-official-avatar{width:84px;height:84px;border-radius:50%;background:#0B5C32;display:grid;place-items:center;color:#fff;font-size:28px;margin:0 auto 12px;box-shadow:0 10px 24px rgba(36,143,71,.3)}
.bb-official-lead h3{margin:4px 0 2px;font-size:16px;color:#0B5C32}
.bb-official-lead .role{font-size:10.5px;color:#0D6A36;text-transform:uppercase;letter-spacing:.5px;font-weight:800}
.bb-official-lead .term{font-size:11px;color:#718B7A;margin-top:2px}
.bb-official-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:24px}
.bb-official-card{background:#fff;border:1px solid #E8F5E9;border-radius:12px;padding:18px;text-align:center}
.bb-official-card i{font-size:18px;color:#6DA41B;margin-bottom:8px;display:block}
.bb-official-card .role{font-size:10px;color:#718B7A;text-transform:uppercase;font-weight:800;letter-spacing:.4px}
.bb-official-card .name{font-size:12.5px;font-weight:700;color:#1C3A26;margin-top:4px}
.bb-kagawad-box{background:#fff;border:1px solid #E8F5E9;border-radius:14px;padding:22px}
.bb-kagawad-box h4{margin:0 0 12px;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:#0B5C32}
.bb-kagawad-list{display:grid;grid-template-columns:repeat(2,1fr);gap:9px 20px;list-style:none;margin:0;padding:0}
.bb-kagawad-list li{font-size:12.5px;color:#336945;padding-left:16px;position:relative}
.bb-kagawad-list li::before{content:'';width:5px;height:5px;border-radius:50%;background:#0D6A36;position:absolute;left:0;top:8px}

/* Contact */
.bb-contact-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:8px}
.bb-contact-card{background:#fff;border:1px solid #E8F5E9;border-radius:14px;padding:20px;display:flex;gap:14px;align-items:center}
.bb-contact-card i{font-size:19px;color:#0D6A36;width:44px;height:44px;background:#F0F9F0;border-radius:10px;display:grid;place-items:center;flex-shrink:0}
.bb-contact-card .lbl{font-size:10px;color:#718B7A;text-transform:uppercase;letter-spacing:.4px}
.bb-contact-card .val{font-size:13px;font-weight:700;color:#1C3A26}

/* Footer strip */
.bb-footer-strip{background:#0B5C32;color:#C8E6C9;text-align:center;padding:22px 20px;font-size:12px}
.bb-footer-strip strong{color:#fff}

/* Responsive */
@media(max-width:900px){
  .bb-role-grid{grid-template-columns:1fr;max-width:400px}
  .bb-how-grid{grid-template-columns:1fr 1fr}
  .bb-hero-body h1{font-size:26px}
  .bb-hero-links a:not(.btn-login){display:none}
}
@media(max-width:640px){
  .bb-hero-body h1{font-size:22px}
  .bb-hero-ctas{flex-direction:column;align-items:center}
  .bb-how-grid,.bb-services-grid,.bb-vm-grid,.bb-official-grid,.bb-contact-grid{grid-template-columns:1fr}
  .bb-stat-grid{grid-template-columns:repeat(2,1fr)}
  .bb-history{grid-template-columns:1fr;text-align:center}
  .bb-kagawad-list{grid-template-columns:1fr}
  .bb-section{padding:44px 18px}
}
</style>

<!-- HERO -->
<section class="bb-hero">
  <div class="bb-hero-nav">
    <a class="bb-hero-brand" href="index.php">
      <img src="assets/img/barangay-babaran-logo.png" alt="Barangay Babaran">
      <strong>BARANGAY BABARAN</strong>
    </a>
    <nav class="bb-hero-links">
      <a href="index.php">Home</a>
      <a href="#how">How it Works</a>
      <a href="#services">Services</a>
      <a href="#about">About</a>
      <a href="#contact">Contact</a>
      <a class="btn-login" href="login.php?role=Personnel">Personnel Login</a>
    </nav>
  </div>
  <div class="bb-hero-body">
    <div class="bb-hero-kicker">REPUBLIC OF THE PHILIPPINES · ECHAGUE, ISABELA</div>
    <h1>Barangay Babaran Document Request &amp;<br>Scheduling System</h1>
    <p>Request official barangay documents online, book your pickup appointment, and track every request — no more long waits at the hall.</p>
    <div class="bb-hero-ctas">
      <a class="btn-cta btn-cta-primary" href="login.php?role=Resident"><i class="bi bi-file-earmark-plus-fill"></i> Request a Document</a>
    </div>
  </div>
</section>

<!-- ROLE SELECTION -->
<div class="bb-role-grid" id="portal">
  <a class="bb-role-card" href="login.php?role=Resident">
    <div class="bb-role-icon" style="background:#0B5C32"><i class="bi bi-person-vcard-fill"></i></div>
    <h3>Resident</h3>
    <p>Register or log in to request Barangay Clearance, Certificate of Indigency, Residency, and more.</p>
    <span class="role-cta">Continue as Resident →</span>
  </a>
  <a class="bb-role-card" href="login.php?role=Punong Barangay">
    <div class="bb-role-icon" style="background:#0D6A36"><i class="bi bi-shield-fill-check"></i></div>
    <h3>Punong Barangay</h3>
    <p>Full access to manage requests, approve documents, view reports, and oversee barangay operations.</p>
    <span class="role-cta">Personnel Login →</span>
  </a>
  <a class="bb-role-card" href="login.php?role=Secretary">
    <div class="bb-role-icon" style="background:#148044"><i class="bi bi-person-badge-fill"></i></div>
    <h3>Barangay Secretary</h3>
    <p>Process document requests, assign schedules, update statuses, and assist residents daily.</p>
    <span class="role-cta">Personnel Login →</span>
  </a>
</div>

<div class="bb-note"><i class="bi bi-shield-check"></i><span>Secure role-based access. Your selected account type is verified before you can enter the system.</span></div>

<!-- HOW IT WORKS -->
<section class="bb-section" id="how">
  <div class="bb-section-head">
    <div class="kicker">Simple Process</div>
    <h2>How It Works</h2>
    <p>Four easy steps from request to released document.</p>
  </div>
  <div class="bb-how-grid">
    <div class="bb-how-card">
      <div class="step-num">1</div>
      <h4>Register / Login</h4>
      <p>Create a resident account or sign in with your email or contact number.</p>
    </div>
    <div class="bb-how-card">
      <div class="step-num">2</div>
      <h4>Submit Request</h4>
      <p>Choose the document type, fill in details, and pick your preferred schedule.</p>
    </div>
    <div class="bb-how-card">
      <div class="step-num">3</div>
      <h4>Get Scheduled</h4>
      <p>Barangay personnel reviews and assigns an official pickup date and time.</p>
    </div>
    <div class="bb-how-card">
      <div class="step-num">4</div>
      <h4>Claim Document</h4>
      <p>Visit the hall on your scheduled slot and receive your official document.</p>
    </div>
  </div>
</section>

<!-- SERVICES -->
<section class="bb-section alt" id="services">
  <div class="bb-inner">
    <div class="bb-section-head">
      <div class="kicker">Available Documents</div>
      <h2>Services We Offer</h2>
      <p>Official barangay documents you can request online.</p>
    </div>
    <div class="bb-services-grid">
      <?php foreach ($servicesList as $svc):
        $icon = $serviceIcons[$svc['service_name']] ?? ['bi-file-earmark-text-fill', '#637A6B'];
      ?>
      <div class="bb-service-row">
        <div class="ic" style="background:<?= htmlspecialchars($icon[1]) ?>"><i class="bi <?= htmlspecialchars($icon[0]) ?>"></i></div>
        <div>
          <h4><?= htmlspecialchars($svc['service_name']) ?></h4>
          <p><?= htmlspecialchars($svc['description'] ?: 'Official barangay document') ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ABOUT -->
<section class="bb-section" id="about">
  <div class="bb-section-head">
    <div class="kicker">About Us</div>
    <h2>Our History, Vision &amp; Mission</h2>
  </div>
  <div class="bb-history">
    <img src="assets/img/barangay-babaran-logo.png" alt="Barangay Babaran Seal">
    <p>Years ago Barangay Babaran was still occupied by Barangay Sta. Cruz. But since the 1950&rsquo;s, when the first Municipal Councilor named <strong>Eusebio Babaran</strong> visited Barangay Sta. Cruz, he found out that most of the residents of Barangay Sta. Cruz were living in their homestead &mdash; and that is Barangay Babaran now. The late Municipal Councilor united all the people in this place, conducted a meeting, and requested them that it would be better to make this place its own Barangay. The people agreed to become a Barangay, and they called it <strong>Barangay Babaran, Echague, Isabela</strong>.</p>
  </div>
  <div class="bb-vm-grid">
    <div class="bb-vm-card vision">
      <h3><i class="bi bi-eye-fill"></i> Vision</h3>
      <p>&ldquo;Barangay Babaran as leading producer of sugarcane in the Municipality of Echague with a progressive economy and resilient infrastructure with morally upright, healthy and God-fearing citizens living in a safe and environment-friendly community under a transparent and reliable governance.&rdquo;</p>
    </div>
    <div class="bb-vm-card mission">
      <h3><i class="bi bi-flag-fill"></i> Mission</h3>
      <p>&ldquo;To promote peace and order and actively implement priority projects.&rdquo;</p>
      <span class="tag">Barangay Babaran, Echague, Isabela</span>
    </div>
  </div>
</section>

<!-- PROFILE -->
<section class="bb-section alt">
  <div class="bb-inner">
    <div class="bb-section-head">
      <div class="kicker">Barangay Profile</div>
      <h2>At a Glance</h2>
    </div>
    <div class="bb-stat-grid">
      <div class="bb-stat-box"><i class="bi bi-people-fill"></i><div class="val">1,761</div><div class="lbl">Population (2024)</div></div>
      <div class="bb-stat-box"><i class="bi bi-house-fill"></i><div class="val">Rural</div><div class="lbl">Classification</div></div>
      <div class="bb-stat-box"><i class="bi bi-bank2"></i><div class="val">Echague</div><div class="lbl">Municipality</div></div>
      <div class="bb-stat-box"><i class="bi bi-geo-alt-fill"></i><div class="val">Isabela</div><div class="lbl">Province</div></div>
      <div class="bb-stat-box"><i class="bi bi-map-fill"></i><div class="val">Cagayan Valley</div><div class="lbl">Region</div></div>
      <div class="bb-stat-box"><i class="bi bi-envelope-fill"></i><div class="val">3309</div><div class="lbl">ZIP Code</div></div>
      <div class="bb-stat-box"><i class="bi bi-person-badge-fill"></i><div class="val">2023–2026</div><div class="lbl">Current Term</div></div>
      <div class="bb-stat-box"><i class="bi bi-calendar-event-fill"></i><div class="val">Nov 2, 2026</div><div class="lbl">Next BSKE</div></div>
    </div>
  </div>
</section>

<!-- OFFICIALS (kept from original structure) -->
<section class="bb-section" id="officials">
  <div class="bb-section-head">
    <div class="kicker">Leadership</div>
    <h2>Barangay Officials</h2>
    <p>Serving the community for the term 2023–2026.</p>
  </div>
  <div class="bb-official-lead">
    <div class="bb-official-avatar"><i class="bi bi-person-fill"></i></div>
    <h3>Hon. Punong Barangay</h3>
    <div class="role">Punong Barangay</div>
    <div class="term">Term 2023 – 2026</div>
  </div>
  <div class="bb-official-grid">
    <div class="bb-official-card"><i class="bi bi-person-badge"></i><div class="role">Barangay Secretary</div><div class="name">Barangay Secretary</div></div>
    <div class="bb-official-card"><i class="bi bi-cash-stack"></i><div class="role">Barangay Treasurer</div><div class="name">Barangay Treasurer</div></div>
    <div class="bb-official-card"><i class="bi bi-shield"></i><div class="role">SK Chairperson</div><div class="name">SK Chairperson</div></div>
  </div>
  <div class="bb-kagawad-box">
    <h4>Sangguniang Barangay Members (Kagawad)</h4>
    <ul class="bb-kagawad-list">
      <li>Kagawad 1</li>
      <li>Kagawad 2</li>
      <li>Kagawad 3</li>
      <li>Kagawad 4</li>
      <li>Kagawad 5</li>
      <li>Kagawad 6</li>
      <li>Kagawad 7</li>
    </ul>
  </div>
</section>

<!-- CONTACT -->
<section class="bb-section alt" id="contact">
  <div class="bb-inner">
    <div class="bb-section-head">
      <div class="kicker">Get in Touch</div>
      <h2>Contact Us</h2>
    </div>
    <div class="bb-contact-grid">
      <div class="bb-contact-card">
        <i class="bi bi-geo-alt-fill"></i>
        <div><div class="lbl">Address</div><div class="val">Barangay Babaran, Echague, Isabela 3309</div></div>
      </div>
      <div class="bb-contact-card">
        <i class="bi bi-clock-fill"></i>
        <div><div class="lbl">Office Hours</div><div class="val">Monday – Friday, 8:00 AM – 5:00 PM</div></div>
      </div>
      <div class="bb-contact-card">
        <i class="bi bi-telephone-fill"></i>
        <div><div class="lbl">Contact</div><div class="val">Visit the Barangay Hall</div></div>
      </div>
      <div class="bb-contact-card">
        <i class="bi bi-envelope-fill"></i>
        <div><div class="lbl">Email</div><div class="val">barangaybabaran@local.gov.ph</div></div>
      </div>
    </div>
  </div>
</section>

<div class="bb-footer-strip">
  <strong>Barangay Babaran</strong> Document Request &amp; Scheduling System &copy; <?= date('Y') ?> · Echague, Isabela
</div>

<?php include 'includes/footer.php'; ?>
