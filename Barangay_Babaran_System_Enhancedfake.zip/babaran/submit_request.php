<?php
require 'includes/config.php';
require_resident();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: dashboard.php');
    exit;
}
verify_csrf();

$id = (int)($_POST['request_id'] ?? 0);
$signature = trim($_POST['resident_signature'] ?? '');
// Electronic signature is OPTIONAL — practical for barangays where mobile signing is difficult.
$residentId = (int)$_SESSION['resident_id'];

if ($signature !== '') {
    $st = $conn->prepare("UPDATE tblrequests SET status='Pending', resident_signature=?, resident_signed_at=NOW(), remarks=NULL WHERE request_id=? AND resident_id=? AND status='Draft'");
    $st->bind_param('sii', $signature, $id, $residentId);
} else {
    $st = $conn->prepare("UPDATE tblrequests SET status='Pending', resident_signature=NULL, resident_signed_at=NULL, remarks=NULL WHERE request_id=? AND resident_id=? AND status='Draft'");
    $st->bind_param('ii', $id, $residentId);
}

if (!$st->execute() || $st->affected_rows !== 1) {
    http_response_code(422);
    exit('Unable to submit this request. It may already have been submitted or is no longer editable.');
}

log_audit($conn, 'resident', $residentId, $_SESSION['first_name'] ?? 'Resident', 'Submitted Request', 'tblrequests', $id, $signature ? 'With e-signature' : 'Without e-signature');
$st->close();

header('Location: confirmation.php?id=' . $id);
exit;
?>
