# Barangay Babaran Document Request and Scheduling System

PHP + MySQL local system for XAMPP/SQLyog.

## Main flow
Resident Information -> Document Type -> Review & Submit -> Confirmation

## Personnel flow
Pending Request -> Assign Schedule -> Schedule Saved -> Complete/Release

## Included
- Barangay Babaran logo
- Email OR Contact Number login
- Show/Hide password
- Forgot password
- Resident registration with optional email
- Editable request form before final submission
- Resident electronic signature
- Document request and queue number
- Personnel dashboard
- Schedule assignment
- Personnel electronic signature for completion
- Printable Document Request Slip
- Personnel dashboard donut chart of requests by document type
- Most requested document highlight
- Resident Management (admin/residents.php)
- Reports & Analysis with date-range filter (admin/reports.php)
- MySQL database for XAMPP and SQLyog

## Database
Database name: babaran_db
Import database.sql in phpMyAdmin or SQLyog.

## Local URL
http://localhost/Barangay_Babaran_System/

## Personnel login
Username: admin
Password: admin123


## Resident Dashboard
The resident dashboard includes database-driven statistics, a 7-day request activity graph, request status summary, and recent requests. No payment transaction module is included.

## Personnel Dashboard Charts
The personnel dashboard shows a 7-day request activity bar chart and a donut chart of requests grouped by document type (with counts, percentages, and the most-requested document highlighted), both computed live from tblrequests/tblservices.

## Resident Management (admin/residents.php)
Lists all registered residents with search (name/contact/email/address), request counts (total/pending/completed), and an expandable panel showing each resident's document request history.

## Reports & Analysis (admin/reports.php)
Date-range filterable report showing: total/completed/pending counts, completion rate, most requested document, a donut chart of requests by document type, a bar chart of requests by status, a monthly request trend chart, and a document type breakdown table.

## Added security and management modules
- Admin Document Management: `admin/documents.php`
- Secure one-time Forgot Password links with 15-minute expiry and single-use reset tokens
- Advanced session management: HttpOnly/SameSite cookies, strict session mode, 30-minute inactivity timeout, and session ID regeneration after login
- CSRF protection added to the new management/security forms and key admin update flows

### Forgot Password on localhost
`includes/config.php` uses `APP_ENV = 'local'` so the generated reset link is shown for testing on localhost. For production, change it to `production` and configure PHP mail/SMTP so the link is delivered by email instead of displayed.


## Updated login flow
The public landing page now shows only three user types:
- Resident
- Punong Barangay
- Barangay Secretary

Selecting a user type opens its dedicated sign-in screen. The submitted role is validated against the database account role before login. The admin dashboard also retains functional Logout controls.


See `FUNCTIONALITY_CHECKLIST.txt` for the latest QA checks and XAMPP setup.
