<?php
require 'includes/config.php'; require_resident(); $pageTitle='Resident Dashboard';
$residentId=(int)$_SESSION['resident_id'];
$st=$conn->prepare("SELECT COUNT(*) c FROM tblrequests WHERE resident_id=? AND status='Pending'");$st->bind_param('i',$residentId);$st->execute();$pending=(int)$st->get_result()->fetch_assoc()['c'];
$st=$conn->prepare("SELECT COUNT(*) c FROM tblrequests WHERE resident_id=? AND status='Scheduled'");$st->bind_param('i',$residentId);$st->execute();$scheduled=(int)$st->get_result()->fetch_assoc()['c'];
$st=$conn->prepare("SELECT COUNT(*) c FROM tblrequests WHERE resident_id=? AND status IN ('Completed','Released')");$st->bind_param('i',$residentId);$st->execute();$completed=(int)$st->get_result()->fetch_assoc()['c'];
$st=$conn->prepare("SELECT COUNT(*) c FROM tblrequests WHERE resident_id=? AND status='Released' AND DATE(updated_at)=CURDATE()");$st->bind_param('i',$residentId);$st->execute();$released=(int)$st->get_result()->fetch_assoc()['c'];
$st=$conn->prepare("SELECT r.*,s.service_name FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE r.resident_id=? ORDER BY r.date_requested DESC LIMIT 6");$st->bind_param('i',$residentId);$st->execute();$requests=$st->get_result();
$st=$conn->prepare("SELECT r.*,s.service_name FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE r.resident_id=? AND r.status='Scheduled' ORDER BY r.scheduled_date,r.scheduled_time LIMIT 4");$st->bind_param('i',$residentId);$st->execute();$schedules=$st->get_result();

$processingQ=$conn->prepare("SELECT COUNT(*) c FROM tblrequests WHERE resident_id=? AND status='Processing'");$processingQ->bind_param('i',$residentId);$processingQ->execute();$processing=(int)$processingQ->get_result()->fetch_assoc()['c'];
$releasedQ=$conn->prepare("SELECT COUNT(*) c FROM tblrequests WHERE resident_id=? AND status='Released'");$releasedQ->bind_param('i',$residentId);$releasedQ->execute();$releasedCount=(int)$releasedQ->get_result()->fetch_assoc()['c'];
$q=$conn->prepare("SELECT COUNT(*) c FROM tblrequests WHERE resident_id=? AND status='Rejected'");$q->bind_param('i',$residentId);$q->execute();$rejectedCount=(int)($q->get_result()->fetch_assoc()['c']??0);
$statusCounts=['Pending'=>$pending,'Scheduled'=>$scheduled,'Processing'=>$processing,'Completed'=>$completed,'Released'=>$releasedCount,'Rejected'=>$rejectedCount];
$totalRequests=array_sum($statusCounts);

// Next action: soonest upcoming scheduled appointment, else the most recently rejected request.
$nextAction=null;
$naQ=$conn->prepare("SELECT r.request_id,r.scheduled_date,r.scheduled_time,s.service_name FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE r.resident_id=? AND r.status='Scheduled' AND r.scheduled_date>=CURDATE() ORDER BY r.scheduled_date,r.scheduled_time LIMIT 1");
$naQ->bind_param('i',$residentId); $naQ->execute(); $naRow=$naQ->get_result()->fetch_assoc();
if($naRow){
  $days=(int)floor((strtotime($naRow['scheduled_date'])-strtotime(date('Y-m-d')))/86400);
  $when=$days<=0?'today':($days===1?'tomorrow':'in '.$days.' days');
  $nextAction=['type'=>'scheduled','text'=>'Your appointment for '.$naRow['service_name'].' is '.$when.' ('.date('M d, Y',strtotime($naRow['scheduled_date'])).' at '.date('h:i A',strtotime($naRow['scheduled_time'])).').','id'=>$naRow['request_id']];
} else {
  $rjQ=$conn->prepare("SELECT r.request_id,r.remarks,s.service_name FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE r.resident_id=? AND r.status='Rejected' ORDER BY r.updated_at DESC LIMIT 1");
  $rjQ->bind_param('i',$residentId); $rjQ->execute(); $rjRow=$rjQ->get_result()->fetch_assoc();
  if($rjRow){
    $nextAction=['type'=>'rejected','text'=>'Your request for '.$rjRow['service_name'].' was rejected.'.($rjRow['remarks']?' Remarks: '.$rjRow['remarks']:' Please edit and resubmit for review.'),'id'=>$rjRow['request_id']];
  }
}

$requestTypeChart=[];
$q=$conn->prepare("SELECT s.service_name, COUNT(*) AS total FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE r.resident_id=? AND r.status<>'Draft' GROUP BY r.service_id,s.service_name ORDER BY total DESC,s.service_name ASC");
$q->bind_param('i',$residentId); $q->execute();
$typeResult=$q->get_result();
while($row=$typeResult->fetch_assoc()){ $requestTypeChart[]=['label'=>$row['service_name'],'count'=>(int)$row['total']]; }
$typeMax=max(1, $requestTypeChart ? max(array_column($requestTypeChart,'count')) : 1);

include 'includes/header.php';
?>
<div class="dashboard-grid">
<div class="hero-banner"><div class="hero-left"><div class="hero-icon"><i class="bi bi-bank"></i></div><div><div class="hero-eyebrow">Republic of the Philippines</div><div class="hero-title">Barangay Babaran</div><div class="hero-sub">Resident Document Request & Tracking Portal</div></div></div><div class="hero-date"><i class="bi bi-calendar-event"></i> <?=date('l, F j, Y')?></div></div>
<?php if(isset($_GET['updated'])):?><div class="alert alert-success">Your corrected request has been submitted again for barangay review.</div><?php endif;?>
<?php if($nextAction):?><div class="alert <?=$nextAction['type']==='rejected'?'alert-danger':'alert-info'?>" style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap"><span><i class="bi <?=$nextAction['type']==='rejected'?'bi-exclamation-circle':'bi-calendar-check'?>"></i> <?=e($nextAction['text'])?></span><a class="btn btn-small btn-outline" href="request_slip.php?id=<?=$nextAction['id']?>">View Request</a></div><?php endif;?>
<div class="page-head"><div><h1>Dashboard</h1><div class="muted">Welcome back, <?=e($_SESSION['first_name'])?>!</div></div><a class="btn btn-primary" href="new_request.php"><i class="bi bi-plus-lg"></i> New Document Request</a></div>
<div class="stat-grid">
<a class="stat-card stat-card-featured" href="requests.php?status=Pending"><div><small>Pending Requests</small><strong><?=$pending?></strong><small>View all →</small></div><div class="stat-icon"><i class="bi bi-arrow-up-right"></i></div></a>
<a class="stat-card" href="requests.php?status=Scheduled"><div><small>Scheduled Requests</small><strong><?=$scheduled?></strong><small>View all →</small></div><div class="stat-icon"><i class="bi bi-arrow-up-right"></i></div></a>
<a class="stat-card" href="requests.php?status=Completed"><div><small>Completed Requests</small><strong><?=$completed?></strong><small>View all →</small></div><div class="stat-icon"><i class="bi bi-arrow-up-right"></i></div></a>
<a class="stat-card" href="requests.php?status=Released"><div><small>Released Today</small><strong><?=$released?></strong><small>View all →</small></div><div class="stat-icon"><i class="bi bi-arrow-up-right"></i></div></a>
</div>
<?php if(!$totalRequests):?>
<div class="card" style="text-align:center;padding:40px 20px;margin-top:18px">
  <div class="stat-icon blue" style="margin:0 auto 14px;width:56px;height:56px;font-size:26px"><i class="bi bi-file-earmark-plus"></i></div>
  <h3 style="margin:0 0 6px">You haven't submitted a request yet</h3>
  <p class="muted small" style="margin:0 0 16px">Start your first barangay document request — it only takes a few minutes.</p>
  <a class="btn btn-primary" href="new_request.php"><i class="bi bi-plus-lg"></i> Submit Your First Request</a>
</div>
<?php else: ?>
<div class="dashboard-two resident-insights">
<section class="card">
  <div class="section-head"><h3>Request Status Summary</h3></div>
  <?php $statusTotal=max(1,array_sum($statusCounts)); foreach($statusCounts as $label=>$count): $pct=round(($count/$statusTotal)*100); $cls=strtolower($label); ?>
  <div class="status-summary-row">
    <div class="status-summary-top"><span><span class="status-dot <?=$cls?>"></span><?=e($label)?></span><strong><?=$count?></strong></div>
    <div class="status-track"><div class="status-fill <?=$cls?>" style="width:<?=$pct?>%"></div></div>
  </div>
  <?php endforeach;?>
</section>
<section class="card request-type-card">
  <div class="section-head"><div><h3>Document Request Type</h3><p class="muted">How many times you requested each document</p></div></div>
  <?php if(!$requestTypeChart): ?>
    <div class="empty muted">No submitted document requests yet.</div>
  <?php else: ?>
    <div class="horizontal-chart" aria-label="Document request types and counts">
      <?php foreach($requestTypeChart as $type): $width=max(4,round(($type['count']/$typeMax)*100)); ?>
        <div class="hbar-row"><div class="hbar-label" title="<?=e($type['label'])?>"><?=e($type['label'])?></div><div class="hbar-track"><div class="hbar-fill" style="width:<?=$width?>%"></div></div><strong class="hbar-count"><?=$type['count']?></strong></div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>
</div>
<div class="dashboard-two">
<section class="card"><div class="section-head"><h3>Recent Requests</h3><a href="requests.php">View All ›</a></div>
<?php if(!$requests->num_rows):?><div class="empty muted">No requests yet. Click New Document Request to begin.</div><?php else:?><div class="table-wrap"><table class="table"><thead><tr><th>Queue No.</th><th>Document Type</th><th>Date Requested</th><th>Status</th><th>Action</th></tr></thead><tbody><?php while($r=$requests->fetch_assoc()):?><tr><td><strong><?=e(queue_number($r['request_id']))?></strong></td><td><?=e($r['service_name'])?></td><td><?=date('M d, Y',strtotime($r['date_requested']))?><br><?=date('h:i A',strtotime($r['date_requested']))?></td><td><span class="badge badge-<?=strtolower($r['status'])?>"><?=e($r['status'])?></span></td><td><?php if(in_array($r['status'],['Pending','Rejected'],true)):?><a class="btn btn-outline btn-small" href="edit_request.php?id=<?=$r['request_id']?>">Edit</a><?php endif;?> <a class="btn btn-outline btn-small" href="request_slip.php?id=<?=$r['request_id']?>">View</a></td></tr><?php endwhile;?></tbody></table></div><?php endif;?></section>
<section class="card"><div class="section-head"><h3>My Schedule</h3><a href="requests.php?status=Scheduled">View All ›</a></div><?php if(!$schedules->num_rows):?><div class="empty muted">No scheduled requests.</div><?php else:?><div class="schedule-list"><?php while($s=$schedules->fetch_assoc()):?><div class="schedule-item"><div class="schedule-time"><?=date('h:i A',strtotime($s['scheduled_time']))?></div><div><strong><?=e($s['service_name'])?></strong><span><?=date('M d, Y',strtotime($s['scheduled_date']))?></span></div></div><?php endwhile;?></div><?php endif;?></section>
</div>
<?php endif; ?>
<div class="dashboard-two" style="grid-template-columns:1fr 1fr">
<section class="card"><div class="section-head"><h3>Quick Actions</h3></div><div class="quick-actions">
<a class="quick-action" href="new_request.php"><div class="quick-icon blue"><i class="bi bi-file-earmark-plus"></i></div><div class="quick-body">New Document Request<span>Start a new barangay document request</span></div><i class="bi bi-chevron-right quick-chevron"></i></a>
<a class="quick-action" href="requests.php"><div class="quick-icon teal"><i class="bi bi-search"></i></div><div class="quick-body">Track Request<span>Check the status of your requests</span></div><i class="bi bi-chevron-right quick-chevron"></i></a>
<a class="quick-action" href="requests.php?status=Scheduled"><div class="quick-icon purple"><i class="bi bi-calendar3"></i></div><div class="quick-body">View Scheduled Appointments<span>See your upcoming barangay visits</span></div><i class="bi bi-chevron-right quick-chevron"></i></a>
</div></section>
<section class="card"><div class="section-head"><h3>Important Reminders</h3></div><div class="activity-list"><div class="activity-item"><span><i class="bi bi-info-circle"></i></span><div><strong>Check your information</strong><span>Review your request before submitting.</span></div></div><div class="activity-item"><span><i class="bi bi-check-circle"></i></span><div><strong>Bring valid identification</strong><span>Bring required documents when visiting the barangay office.</span></div></div><div class="activity-item"><span><i class="bi bi-clock"></i></span><div><strong>Watch your schedule</strong><span>Check the dashboard for schedule changes.</span></div></div></div></section>
</div></div>
<?php include 'includes/footer.php'; ?>
