-- Barangay Babaran System: adds tblresidents.age for existing databases.
-- Run this ONLY if you are upgrading an older database that does not already
-- have this column. If you import the current database.sql, it is already included.

USE babaran_db;

SET @db := DATABASE();

SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='tblresidents' AND COLUMN_NAME='age'),
    'SELECT 1',
    'ALTER TABLE tblresidents ADD COLUMN age TINYINT UNSIGNED NULL AFTER last_name'
  )
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
