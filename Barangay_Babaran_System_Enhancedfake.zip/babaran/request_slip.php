<?php
require 'includes/config.php';

$isAdmin = isset($_SESSION['admin_id']);
$isResident = isset($_SESSION['resident_id']);
if (!$isAdmin && !$isResident) {
    header('Location: login.php');
    exit;
}

$id = (int)($_GET['id'] ?? 0);
$sql = "SELECT r.*, s.service_name FROM tblrequests r JOIN tblservices s ON s.service_id=r.service_id WHERE r.request_id=?";
if ($isResident && !$isAdmin) {
    $sql .= " AND r.resident_id=" . (int)$_SESSION['resident_id'];
}
$st = $conn->prepare($sql);
$st->bind_param('i', $id);
$st->execute();
$r = $st->get_result()->fetch_assoc();
if (!$r) {
    http_response_code(404);
    die('Request not found.');
}

$fullName = trim(preg_replace('/\s+/', ' ', $r['request_first_name'] . ' ' . $r['request_middle_name'] . ' ' . $r['request_last_name']));
$queueNo = queue_number($r['request_id']);

// QR payload for request slip (Level Q)
$qrPayload = json_encode([
    'type'       => 'BB_SLIP',
    'queue'      => $queueNo,
    'request_id' => (int)$r['request_id'],
    'document'   => $r['service_name'],
    'name'       => $fullName,
    'status'     => $r['status'],
    'barangay'   => 'Barangay Babaran',
], JSON_UNESCAPED_UNICODE);

// Simple pure-PHP QR using Google Chart API as fallback image (works offline-print via data if needed)
// For print reliability we embed a TCPDF-generated PNG when possible; otherwise show text code.
$qrImgData = null;
$tcpdfBarcode = __DIR__ . '/assets/libs/tcpdf/tcpdf_barcodes_2d.php';
if (is_file($tcpdfBarcode)) {
    require_once $tcpdfBarcode;
    try {
        $barcode = new TCPDF2DBarcode($qrPayload, 'QRCODE,Q');
        $qrImgData = $barcode->getBarcodePngData(4, 4, [31, 122, 58]);
    } catch (Throwable $e) {
        $qrImgData = null;
    }
}

$pageTitle = 'Request Slip — ' . $queueNo;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', system-ui, sans-serif; background: #f0f4f0; color: #1c3a26; padding: 20px; }
  .slip { max-width: 480px; margin: 0 auto; background: #fff; border: 2px solid #1F7A3A; border-radius: 12px; overflow: hidden; box-shadow: 0 8px 30px rgba(31,122,58,.12); }
  .slip-header { background: linear-gradient(120deg, #1F7A3A, #2E9E4F); color: #fff; padding: 18px 20px; text-align: center; }
  .slip-header img { width: 48px; height: 48px; border-radius: 50%; background: #fff; padding: 3px; margin-bottom: 8px; }
  .slip-header h1 { font-size: 15px; letter-spacing: .5px; margin-bottom: 2px; }
  .slip-header p { font-size: 11px; opacity: .9; }
  .slip-body { padding: 20px; }
  .queue-big { text-align: center; margin-bottom: 16px; }
  .queue-big .label { font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: #718B7A; }
  .queue-big .num { font-size: 28px; font-weight: 800; color: #1F7A3A; letter-spacing: 1px; }
  .row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dashed #e0ebe0; font-size: 13px; }
  .row:last-child { border-bottom: none; }
  .row .lbl { color: #718B7A; }
  .row .val { font-weight: 600; text-align: right; max-width: 60%; }
  .badge { display: inline-block; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; }
  .badge-pending { background: #fff3cd; color: #856404; }
  .badge-scheduled { background: #cce5ff; color: #004085; }
  .badge-processing { background: #e2d5f1; color: #4a2c7a; }
  .badge-completed, .badge-released { background: #d4edda; color: #155724; }
  .badge-rejected { background: #f8d7da; color: #721c24; }
  .badge-draft { background: #e9ecef; color: #495057; }
  .qr-box { text-align: center; margin-top: 18px; padding-top: 14px; border-top: 1px solid #e0ebe0; }
  .qr-box img { width: 110px; height: 110px; }
  .qr-box .hint { font-size: 10px; color: #718B7A; margin-top: 4px; }
  .actions { text-align: center; margin-top: 18px; }
  .btn { display: inline-block; padding: 10px 20px; background: #1F7A3A; color: #fff; border: none; border-radius: 8px; font-weight: 700; cursor: pointer; text-decoration: none; font-size: 13px; }
  .btn:hover { background: #166433; }
  .btn-outline { background: #fff; color: #1F7A3A; border: 1.5px solid #1F7A3A; margin-left: 8px; }
  @media print {
    body { background: #fff; padding: 0; }
    .actions { display: none; }
    .slip { box-shadow: none; border-radius: 0; max-width: 100%; }
  }
</style>
</head>
<body>
<div class="slip">
  <div class="slip-header">
    <img src="assets/img/barangay-babaran-logo.png" alt="Logo">
    <h1>BARANGAY BABARAN</h1>
    <p>Document Request Slip · Echague, Isabela</p>
  </div>
  <div class="slip-body">
    <div class="queue-big">
      <div class="label">Queue / Reference Number</div>
      <div class="num"><?= htmlspecialchars($queueNo) ?></div>
    </div>

    <div class="row"><span class="lbl">Resident Name</span><span class="val"><?= htmlspecialchars($fullName) ?></span></div>
    <div class="row"><span class="lbl">Address</span><span class="val"><?= htmlspecialchars($r['request_address']) ?></span></div>
    <div class="row"><span class="lbl">Contact</span><span class="val"><?= htmlspecialchars($r['request_contact'] ?: '—') ?></span></div>
    <div class="row"><span class="lbl">Document</span><span class="val"><?= htmlspecialchars($r['service_name']) ?></span></div>
    <div class="row"><span class="lbl">Purpose</span><span class="val"><?= htmlspecialchars($r['purpose']) ?></span></div>
    <div class="row"><span class="lbl">Preferred Schedule</span><span class="val"><?= date('M d, Y', strtotime($r['preferred_date'])) ?> · <?= date('h:i A', strtotime($r['preferred_time'])) ?></span></div>
    <?php if ($r['scheduled_date']): ?>
    <div class="row"><span class="lbl">Assigned Schedule</span><span class="val"><?= date('M d, Y', strtotime($r['scheduled_date'])) ?> · <?= date('h:i A', strtotime($r['scheduled_time'])) ?></span></div>
    <?php endif; ?>
    <div class="row">
      <span class="lbl">Status</span>
      <span class="val"><span class="badge badge-<?= strtolower($r['status']) ?>"><?= htmlspecialchars($r['status']) ?></span></span>
    </div>
    <div class="row"><span class="lbl">Date Requested</span><span class="val"><?= date('M d, Y h:i A', strtotime($r['date_requested'])) ?></span></div>

    <div class="qr-box">
      <?php if ($qrImgData): ?>
        <img src="data:image/png;base64,<?= base64_encode($qrImgData) ?>" alt="QR Code">
      <?php else: ?>
        <div style="font-size:11px;color:#718B7A;padding:12px;border:1px dashed #ccc;border-radius:8px">QR: <?= htmlspecialchars($queueNo) ?></div>
      <?php endif; ?>
      <div class="hint">Scan to verify request · Error Correction Level Q</div>
    </div>
  </div>
</div>

<div class="actions">
  <button class="btn" onclick="window.print()"><i class="bi bi-printer"></i> Print Slip</button>
  <?php if (in_array($r['status'], ['Completed', 'Released'], true)): ?>
    <a class="btn btn-outline" href="generate_certificate.php?id=<?= $id ?>">Download Certificate (PDF)</a>
  <?php endif; ?>
  <a class="btn btn-outline" href="<?= $isAdmin ? 'admin/dashboard.php' : 'requests.php' ?>">Back</a>
</div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
</body>
</html>
