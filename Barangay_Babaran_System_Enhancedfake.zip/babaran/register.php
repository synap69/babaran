<?php
require 'includes/config.php';
$pageTitle = 'Resident Registration';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $first   = trim($_POST['first_name'] ?? '');
    $middle  = trim($_POST['middle_name'] ?? '');
    $last    = trim($_POST['last_name'] ?? '');
    $age     = trim($_POST['age'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $contact = trim($_POST['contact_no'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Empty optional values must be stored as SQL NULL, not as an empty string.
    // This is important because email/contact_no are UNIQUE nullable columns.
    $email = ($email === '') ? null : strtolower($email);
    $contact = ($contact === '') ? null : $contact;

    if ($first === '' || $last === '' || $address === '' || strlen($password) < 6) {
        $error = 'Please complete all required fields. Password must be at least 6 characters.';
    } elseif ($age === '' || !ctype_digit($age) || (int)$age < 1 || (int)$age > 120) {
        $error = 'Please enter a valid age (1–120).';
    } elseif ($contact === null && $email === null) {
        $error = 'Please provide at least one account identifier: contact number or email address.';
    } elseif ($email !== null && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        // Check each supplied identifier separately so the user gets a precise message.
        if ($email !== null) {
            $check = $conn->prepare('SELECT resident_id FROM tblresidents WHERE email = ? LIMIT 1');
            $check->bind_param('s', $email);
            $check->execute();
            if ($check->get_result()->num_rows > 0) {
                $error = 'That email address is already registered. Please use another email or sign in.';
            }
            $check->close();
        }

        if ($error === '' && $contact !== null) {
            $check = $conn->prepare('SELECT resident_id FROM tblresidents WHERE contact_no = ? LIMIT 1');
            $check->bind_param('s', $contact);
            $check->execute();
            if ($check->get_result()->num_rows > 0) {
                $error = 'That contact number is already registered. Please use another contact number or sign in.';
            }
            $check->close();
        }

        if ($error === '') {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $ageInt = (int)$age;
            // Bind NULL values as NULL to MySQL instead of saving empty strings.
            $st = $conn->prepare(
                'INSERT INTO tblresidents
                (first_name, middle_name, last_name, age, address, contact_no, email, password, password_plain)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $st->bind_param('sssisssss', $first, $middle, $last, $ageInt, $address, $contact, $email, $hash, $password);

            if ($st->execute()) {
                $st->close();
                header('Location: login.php?registered=1');
                exit;
            }

            // Friendly fallback for a race condition where another account was created
            // between the duplicate check and INSERT.
            if ($conn->errno === 1062) {
                $error = 'The email or contact number is already registered. Please use another one.';
            } else {
                $error = 'Registration failed. Please try again.';
            }
            $st->close();
        }
    }
}
include 'includes/header.php';
?>
<div class="register-page">
<div class="login-layout">
<div class="login-box card register-card">
  <div class="register-card-toolbar">
    <a class="btn-back-in" href="index.php"><i class="bi bi-arrow-left"></i> Back</a>
  </div>
  <h2 class="register-title">Create Account</h2>
  <?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?>
  <form method="post" class="form-grid" id="registerForm"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
    <div class="form-group"><label>First Name *</label><input class="form-control" name="first_name" value="<?=e($_POST['first_name']??'')?>" placeholder="Enter your first name" required></div>
    <div class="form-group"><label>Last Name *</label><input class="form-control" name="last_name" value="<?=e($_POST['last_name']??'')?>" placeholder="Enter your last name" required></div>
    <div class="form-group"><label>Middle Name</label><input class="form-control" name="middle_name" value="<?=e($_POST['middle_name']??'')?>" placeholder="Enter your middle name (optional)"></div>
    <div class="form-group"><label>Age *</label><input type="number" class="form-control" name="age" min="1" max="120" value="<?=e($_POST['age']??'')?>" placeholder="Enter your age" required></div>
    <div class="form-group"><label>Email Address</label><input type="email" class="form-control" name="email" value="<?=e($_POST['email']??'')?>" placeholder="Enter your email"></div>
    <div class="form-group"><label>Phone Number</label><input type="tel" class="form-control" name="contact_no" value="<?=e($_POST['contact_no']??'')?>" placeholder="09XXXXXXXXX"></div>
    <div class="form-group full"><label>Complete Address *</label><input class="form-control" name="address" value="<?=e($_POST['address']??'')?>" placeholder="Enter your complete address" required></div>
    <div class="form-group full"><div class="small muted">* At least <strong>one</strong> of Contact Number or Email Address is required.</div></div>
    <div class="form-group"><label>Password *</label><div class="password-wrap"><input type="password" id="registerPassword" class="form-control" name="password" minlength="6" autocomplete="new-password" placeholder="Enter your password" required><button type="button" class="password-toggle" data-toggle-target="registerPassword" aria-label="Show password" title="Show password"><i class="bi bi-eye password-eye-icon"></i></button></div></div>
    <div class="form-group"><label>Confirm Password *</label><div class="password-wrap"><input type="password" id="registerConfirmPassword" class="form-control" placeholder="Confirm your password" minlength="6" autocomplete="new-password" required><button type="button" class="password-toggle" data-toggle-target="registerConfirmPassword" aria-label="Show password" title="Show password"><i class="bi bi-eye password-eye-icon"></i></button></div><small class="field-error" id="confirmPasswordError" hidden>Passwords do not match.</small></div>
    <div class="full"><button class="btn btn-register" type="submit">Create</button></div>
  </form>
  <p class="small muted">Already registered? <a href="login.php">Sign in here</a>.</p>
</div>
</div>
</div>
<script>
(function(){
  var form = document.getElementById('registerForm');
  var pw = document.getElementById('registerPassword');
  var confirm = document.getElementById('registerConfirmPassword');
  var err = document.getElementById('confirmPasswordError');
  form.addEventListener('submit', function(e){
    if (pw.value !== confirm.value) {
      e.preventDefault();
      err.hidden = false;
      confirm.focus();
    } else {
      err.hidden = true;
    }
  });
})();
</script>
<?php include 'includes/footer.php'; ?>
