# Barangay Babaran System — High-Impact Improvements (2025)

## Implemented Changes

### 1. Homepage (index.php) — HIGH
- Cleaner, professional hero with clear primary CTA (“Request a Document”) and secondary “Resident Login”
- Prominent role selection cards: Resident / Punong Barangay / Barangay Secretary
- New “How It Works” section (4 steps for residents)
- Improved services cards with hover effects
- Better mobile responsiveness and visual hierarchy
- Kept Barangay Babaran logo and green color scheme

### 2. Electronic Signature — HIGH (Practicality)
- Resident e-signature is now **optional**
- Updated: `submit_request.php`, `request_review.php`, `admin/request_manage.php`
- Residents can skip signing on mobile and sign physically at the hall
- Personnel signature also optional

### 3. PDF Official Certificates (TCPDF) — HIGH
- New file: `generate_certificate.php`
- Only available for **Completed** / **Released** requests
- Pulls data from `tblrequests` + `tblservices` + resident fields
- QR Code with **Error Correction Level H**
- Official layout with logo, green border, Punong Barangay signature area
- Downloadable from Manage Request, Request Slip, My Requests, and Confirmation page

### 4. Request Slip with QR — HIGH
- Redesigned `request_slip.php` (print-friendly)
- QR Code with **Error Correction Level Q**
- Clear queue number, status badge, schedule info
- Link to PDF certificate when status allows

### 5. Automated Email Notifications — HIGH
- New helper: `includes/notifications.php`
- Sends email via existing PHPMailer (`includes/mailer.php`) when status changes to:
  Scheduled | Processing | Completed | Released | Rejected
- Includes: full name, document type, queue number, new status, scheduled date/time
- Only sent if resident has a valid email address
- Hooked into `admin/request_manage.php`

### 6. Scheduling Improvements — MEDIUM-HIGH
- Stronger conflict checking: blocks slots within ±30 minutes of an existing Scheduled/Processing request
- Clearer feedback messages

### 7. UI / UX Polish — MEDIUM-HIGH
- Status timeline on confirmation page
- Mobile-friendly CSS enhancements
- Cleaner cards, buttons, badges
- Certificate download buttons where appropriate

## Libraries Added
- TCPDF 6.7.5 → `assets/libs/tcpdf/` (built-in QR via `write2DBarcode` / `TCPDF2DBarcode`)

## Database
No schema migration required. Existing tables already support all features.

## Configuration Notes
1. Configure SMTP in `includes/mail_config.php` for email notifications.
2. Ensure `assets/libs/tcpdf/` is present (already included).
3. PHP 8.x + MySQL (XAMPP) compatible.

## Files Changed / Added
- index.php (overhauled)
- submit_request.php (optional signature)
- request_review.php (optional signature UI)
- confirmation.php (status timeline)
- request_slip.php (QR Level Q + design)
- generate_certificate.php (NEW — PDF + QR Level H)
- admin/request_manage.php (email + conflict + optional sig + PDF link)
- requests.php (PDF link)
- includes/notifications.php (NEW)
- assets/css/style.css (enhancements appended)
- assets/libs/tcpdf/ (NEW library)

## How to Test
1. Resident: New Request → Review (skip signature) → Submit → Confirmation
2. Personnel: Manage Request → change status to Scheduled → check email (if SMTP configured)
3. Complete a request → Download PDF Certificate → verify QR
4. Print Request Slip → verify QR and layout
5. View homepage on mobile and desktop
