-- Barangay Babaran System role-access migration
-- Use schema_changes.sql for existing databases.
-- Current database.sql already includes these changes.
USE babaran_db;

SET @db := DATABASE();
SET @sql := (SELECT IF(EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='tbladmin' AND COLUMN_NAME='role'),'SELECT 1','ALTER TABLE tbladmin ADD COLUMN role ENUM(\'Punong Barangay\',\'Secretary\') NOT NULL DEFAULT \'Secretary\' AFTER full_name'));
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (SELECT IF(EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='tbladmin' AND COLUMN_NAME='is_active'),'SELECT 1','ALTER TABLE tbladmin ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER role'));
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

UPDATE tbladmin SET role='Punong Barangay' WHERE username='admin';
